"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCRIPT_DIRS = void 0;
exports.mergeChunkScript = mergeChunkScript;
exports.rebundleModule = rebundleModule;
const fs_1 = require("fs");
const path_1 = require("path");
const parser_1 = require("@pgpmjs/ast/files/plan/parser");
const package_1 = require("../packaging/package");
const slice_1 = require("@pgpmjs/slice");
const rebundle_1 = require("./rebundle");
exports.SCRIPT_DIRS = ['deploy', 'revert', 'verify'];
/**
 * Wrap a merged chunk body in a single transaction. Deploy/revert commit;
 * verify rolls back (a verify script must leave no trace). The individual
 * member files' own BEGIN/COMMIT were stripped during the merge, so each
 * rebundled chunk deploys as exactly one transaction.
 */
function wrapTransaction(body, scriptType) {
    const trimmed = body.trim();
    const tail = scriptType === 'verify' ? 'ROLLBACK;' : 'COMMIT;';
    return `BEGIN;\n\n${trimmed}\n\n${tail}\n`;
}
/**
 * Merge one chunk's member scripts (in the correct order per direction) into a
 * single deparsed, single-transaction migration string. Shared by the
 * single-module (`rebundleModule`) and workspace (`rebundleWorkspace`) emitters.
 */
async function mergeChunkScript(sourceDir, chunk, scriptType, opts = {}) {
    const merged = await (0, package_1.mergeSqlStatements)((0, rebundle_1.assembleChunkSql)(sourceDir, chunk, scriptType), {
        stripTransactions: true,
        pretty: opts.pretty ?? true,
        functionDelimiter: opts.functionDelimiter ?? '$EOFCODE$',
    });
    return wrapTransaction(merged.sql, scriptType);
}
/**
 * Copy any top-level files (control, Makefile, package.json, README, ...) from
 * the source module, excluding the plan and the per-change script directories
 * which are regenerated. The rebundled module stays the same extension — same
 * name, same control `requires` — only its internal change set collapses.
 */
function copyModuleMetadata(sourceDir, outputDir) {
    for (const entry of (0, fs_1.readdirSync)(sourceDir, { withFileTypes: true })) {
        if (entry.isDirectory())
            continue;
        if (entry.name === 'pgpm.plan')
            continue;
        (0, fs_1.copyFileSync)((0, path_1.join)(sourceDir, entry.name), (0, path_1.join)(outputDir, entry.name));
    }
}
/**
 * Materialize a rebundled module: merge each chunk's member scripts into a
 * single deparsed migration (reusing `packageModule`'s merge engine), write the
 * chunk-quotient plan, and verify the result is byte-identical when packaged.
 *
 * Reuses existing plumbing throughout — `rebundlePlan` for the chunk model,
 * `mergeSqlStatements`/`packageModule` for statement merging and the gate,
 * `generatePlanContent` for the chunk plan, and the source control/Makefile
 * verbatim.
 */
async function rebundleModule(sourceDir, options) {
    const { outputDir, overwrite = false, pretty = true, functionDelimiter = '$EOFCODE$', ...strategy } = options;
    if ((0, fs_1.existsSync)(outputDir) && (0, fs_1.readdirSync)(outputDir).length > 0 && !overwrite) {
        throw new Error(`Output directory is not empty: ${outputDir}. Pass overwrite: true to replace.`);
    }
    const plan = (0, rebundle_1.rebundlePlan)(sourceDir, strategy);
    // Tags anchor on the last member of the chunk that sealed at them; remap each
    // to its chunk name so `deploy --to @tag` still lands on a real change.
    const parsed = (0, parser_1.parsePlanFile)((0, path_1.join)(sourceDir, 'pgpm.plan'));
    const sourceTags = parsed.data?.tags ?? [];
    const memberToChunk = new Map();
    for (const chunk of plan.chunks) {
        for (const member of chunk.deploy)
            memberToChunk.set(member, chunk.name);
    }
    const remappedTags = sourceTags.map(tag => ({
        ...tag,
        change: memberToChunk.get(tag.change) ?? tag.change,
    }));
    (0, fs_1.mkdirSync)(outputDir, { recursive: true });
    for (const dir of exports.SCRIPT_DIRS)
        (0, fs_1.mkdirSync)((0, path_1.join)(outputDir, dir), { recursive: true });
    copyModuleMetadata(sourceDir, outputDir);
    const written = [];
    for (const chunk of plan.chunks) {
        const paths = { chunk: chunk.name };
        for (const dir of exports.SCRIPT_DIRS) {
            const merged = await (0, package_1.mergeSqlStatements)((0, rebundle_1.assembleChunkSql)(sourceDir, chunk, dir), {
                stripTransactions: true,
                pretty,
                functionDelimiter,
            });
            const rel = (0, path_1.join)(dir, `${chunk.name}.sql`);
            (0, fs_1.writeFileSync)((0, path_1.join)(outputDir, rel), wrapTransaction(merged.sql, dir));
            paths[dir] = rel;
        }
        written.push(paths);
    }
    // Chunk-quotient plan: one change per chunk, deps are earlier chunk names.
    const planEntries = plan.chunks.map(chunk => ({
        name: chunk.name,
        dependencies: chunk.dependencies,
    }));
    (0, fs_1.writeFileSync)((0, path_1.join)(outputDir, 'pgpm.plan'), (0, slice_1.generatePlanContent)(plan.project, planEntries, remappedTags));
    // Byte-identical gate: packaging the source and the rebundled module must
    // produce the same consolidated extension SQL.
    const sourcePkg = await (0, package_1.packageModule)(sourceDir, { pretty, functionDelimiter });
    const outputPkg = await (0, package_1.packageModule)(outputDir, { pretty, functionDelimiter });
    const invariant = {
        ok: sourcePkg.sql === outputPkg.sql,
        sourceDiff: !!sourcePkg.diff,
        outputDiff: !!outputPkg.diff,
    };
    return { ...plan, outputDir, written, invariant };
}
