import { PgpmModuleAst } from '@pgpmjs/ast/module/types';
import { CreateBundleOptions } from './create';
import { MigrationBundle } from './types';
/** Default file name for a serialized bundle artifact. */
export declare const BUNDLE_FILE_NAME = "pgpm-bundle.json";
/** The single entry name inside a `.bundle.tar.gz` archive. */
export declare const BUNDLE_ARCHIVE_ENTRY = "pgpm-bundle.json";
/** Suffix of the stored bundle artifact: `sql/<name>--<version>.bundle.tar.gz`. */
export declare const BUNDLE_ARCHIVE_EXTENSION = ".bundle.tar.gz";
/**
 * Build a bundle straight from a module directory on disk (readModule → createBundle).
 */
export declare function bundleFromModule(moduleDir: string, options?: CreateBundleOptions): MigrationBundle;
/**
 * Serialize a bundle to a single JSON artifact file (stable 2-space formatting).
 */
export declare function writeBundleFile(bundle: MigrationBundle, filePath: string): void;
/** Stable JSON serialization of a bundle (2-space formatting, trailing newline). */
export declare function serializeBundle(bundle: MigrationBundle): string;
/**
 * Read a bundle artifact JSON file back into memory.
 */
export declare function readBundleFile(filePath: string): MigrationBundle;
/** Serialize a bundle to the stored artifact form: gzipped tar of the JSON bundle. */
export declare function packBundle(bundle: MigrationBundle): Buffer;
/**
 * Read a stored bundle artifact (gzipped tar) back into memory. Throws when the
 * archive or its JSON payload is unreadable.
 */
export declare function unpackBundle(archive: Buffer): MigrationBundle;
/** Write the stored `.bundle.tar.gz` artifact for a bundle. */
export declare function writeBundleArchiveFile(bundle: MigrationBundle, filePath: string): void;
/** Read a stored `.bundle.tar.gz` artifact from disk. */
export declare function readBundleArchiveFile(filePath: string): MigrationBundle;
/**
 * Hydrate a bundle back into a {@link PgpmModuleAst} — the inverse of
 * `createBundle`. Composes the existing plan/control/SQL-header parsers over
 * the bundle's byte-exact contents; every leaf keeps the bundle text as its
 * `raw`, so `writeModule` reproduces the bundle losslessly.
 */
export declare function moduleFromBundle(bundle: MigrationBundle, dir?: string): PgpmModuleAst;
/**
 * Materialize a bundle back into a real, deployable pgpm module directory:
 * `pgpm.plan`, the `.control` file (when present), and each change's
 * deploy/revert/verify script at its `deploy/<change>.sql` path.
 *
 * The inverse of {@link bundleFromModule}; the emitted directory can be read
 * back with `readModule` or deployed with `PgpmMigrate`. Implemented as
 * {@link moduleFromBundle} → `writeModule` (byte-exact `raw` leaves), so the
 * bundle write path is the module AST writer — not a parallel one.
 */
export declare function materializeBundle(bundle: MigrationBundle, outDir: string): void;
