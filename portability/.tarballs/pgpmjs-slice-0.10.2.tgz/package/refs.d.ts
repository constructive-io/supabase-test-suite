/**
 * The parser runs on a WASM build of the real PostgreSQL parser; callers must
 * `await loadModule()` once before any synchronous extraction/slicing call.
 */
export { loadModule } from 'plpgsql-parser';
/**
 * A (possibly schema-qualified) database object name extracted from SQL.
 */
export interface SqlObjectRef {
    schema: string | null;
    name: string;
}
/**
 * AST-derived facts about a change's deploy SQL, used to discover
 * dependencies that are not declared in plan `requires` headers.
 */
export interface ChangeSqlFacts {
    /** Objects the SQL creates (tables, views, functions, types, triggers, ...). */
    creates: SqlObjectRef[];
    /**
     * Schema-qualified objects the SQL references — tables, functions and types
     * reached anywhere in the statements, including PL/pgSQL function bodies.
     * Unqualified references are omitted (they resolve via search_path and
     * cannot be mapped to a producer without catalog knowledge).
     */
    references: SqlObjectRef[];
    /**
     * True when a PL/pgSQL body executes dynamic SQL (EXECUTE ...). References
     * inside the dynamic string are invisible to the AST, so the extracted
     * references are incomplete for this change.
     */
    dynamicSql: boolean;
}
/**
 * Extract created objects and schema-qualified references from a SQL script,
 * including references reached inside PL/pgSQL function bodies (which are
 * opaque strings in `CREATE FUNCTION` and invisible to a plain SQL parse).
 *
 * Aggregates `@pgsql/transform`'s per-statement `classifyStatements` facts to
 * the change level: references satisfied by objects the same change creates
 * (in any statement) are dropped.
 */
export declare function extractSqlFacts(sql: string): ChangeSqlFacts;
