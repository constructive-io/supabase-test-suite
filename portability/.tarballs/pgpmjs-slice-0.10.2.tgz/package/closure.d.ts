import { ClosureReport, DependencyGraph, PatternStrategy } from './types';
/**
 * AST-discovered dependency edges between plan changes.
 */
export interface AstEdges {
    /** change -> (dependency change -> the referenced object that links them) */
    edges: Map<string, Map<string, string>>;
    /** Changes whose PL/pgSQL bodies execute dynamic SQL (edges incomplete). */
    dynamicSqlChanges: string[];
    /** Schema-qualified references no change in the plan produces. */
    unresolvedReferences: {
        change: string;
        ref: string;
    }[];
}
/**
 * Parse each change's deploy SQL and derive dependency edges from the
 * schema-qualified objects it references, mapped back to the plan change that
 * creates each object. Only edges between plan-known changes are produced —
 * references to objects created outside the plan (installed modules,
 * extensions) are reported as unresolved instead.
 */
export declare function buildAstEdges(graph: DependencyGraph, moduleDir: string): AstEdges;
/**
 * Expand the packages of closure-enabled pattern slices to cover the
 * transitive dependency closure of their seed changes.
 *
 * The closure follows declared plan `requires` edges plus AST-discovered
 * edges. Only changes currently assigned to the default package are pulled in
 * — a dependency that another explicit slice claimed stays where it is and
 * remains an ordinary cross-package dependency. Mutates `assignments` in
 * place and returns a report of every auto-included change and why.
 */
export declare function expandClosures(assignments: Map<string, Set<string>>, graph: DependencyGraph, astEdges: AstEdges, strategy: PatternStrategy, defaultPackage: string): ClosureReport;
