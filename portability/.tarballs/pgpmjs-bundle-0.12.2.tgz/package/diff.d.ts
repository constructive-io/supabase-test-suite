import { PgpmScriptKind } from '@pgpmjs/ast/module/types';
import { MigrationBundle } from './types';
/** Per-script disposition between two revisions of the same change. */
export type ScriptDiff = 'added' | 'removed' | 'modified' | 'unchanged';
/** How a single change differs between two bundles. */
export interface ChangeDiff {
    name: string;
    kind: 'added' | 'removed' | 'modified';
    /** Per-script detail (only populated for `modified`). */
    scripts?: Record<PgpmScriptKind, ScriptDiff>;
}
/**
 * A structural diff between two bundles — the substrate for drift reconciliation
 * (`reconcileSchemaDrift` / `reconcileServicesCatalogDrift`) and apply diff
 * previews. Compares by content digest, so it is immune to formatting noise.
 */
export interface BundleDiff {
    /** True when both bundles have the same content digest. */
    identical: boolean;
    /** Change names present only in `to`. */
    added: string[];
    /** Change names present only in `from`. */
    removed: string[];
    /** Changes present in both whose content differs. */
    modified: ChangeDiff[];
    /** Same change set, but a different deploy order. */
    reordered: boolean;
    /** All differing changes in `to`-then-removed order, for display. */
    changes: ChangeDiff[];
}
/**
 * Diff two migration bundles by content digest.
 *
 * Pure and deterministic. `added`/`removed`/`modified` are keyed on change name;
 * a change in both bundles is `modified` when its change digest differs, with
 * per-script detail. `reordered` flags a pure deploy-order change over an
 * otherwise identical change set.
 */
export declare function diffBundles(from: MigrationBundle, to: MigrationBundle): BundleDiff;
