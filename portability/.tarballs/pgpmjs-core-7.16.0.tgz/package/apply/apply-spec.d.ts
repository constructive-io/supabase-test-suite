import { ResolvedApplySpec } from './types';
/** Whether a module directory is an apply-spec proxy module. */
export declare function hasApplySpec(moduleDir: string): boolean;
/**
 * Read, validate, and normalize a proxy module's `pgpm.apply.json`.
 *
 * Normalizations: `source` is expanded to its object form and `name` defaults
 * to the proxy directory's name.
 *
 * @throws when the file is missing, unparsable, or structurally invalid.
 */
export declare function readApplySpec(moduleDir: string): ResolvedApplySpec;
/** In-memory core of {@link readApplySpec}. */
export declare function parseApplySpec(content: string, specPath: string): ResolvedApplySpec;
