"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PgpmPackage = exports.PackageContext = void 0;
const env_1 = require("@pgpmjs/env");
const logger_1 = require("@pgpmjs/logger");
const types_1 = require("@pgpmjs/types");
const child_process_1 = require("child_process");
const fs_1 = __importDefault(require("fs"));
const glob = __importStar(require("glob"));
const os_1 = __importDefault(require("os"));
const parse_package_name_1 = require("parse-package-name");
const path_1 = __importStar(require("path"));
const pg_cache_1 = require("pg-cache");
const yanse_1 = __importDefault(require("yanse"));
const materialize_1 = require("../../apply/materialize");
const apply_spec_1 = require("../../apply/apply-spec");
const reuse_1 = require("../../apply/reuse");
const types_2 = require("../../apply/types");
const extensions_1 = require("../../extensions/extensions");
const files_1 = require("@pgpmjs/ast/files");
const files_2 = require("@pgpmjs/ast/files");
const writer_1 = require("@pgpmjs/ast/files/extension/writer");
const generator_1 = require("@pgpmjs/ast/files/plan/generator");
const parser_1 = require("@pgpmjs/ast/files/plan/parser");
const validators_1 = require("@pgpmjs/ast/files/plan/validators");
const client_1 = require("../../migrate/client");
const modules_1 = require("../../modules/modules");
const deploy_bundled_1 = require("../../bundle/deploy-bundled");
const sync_versions_1 = require("../../packaging/sync-versions");
const resolve_install_1 = require("../../extensions/resolve-install");
const deps_1 = require("../../resolution/deps");
const fs_2 = require("../../utils/fs");
const glob_1 = require("../../utils/glob");
const target_utils_1 = require("../../utils/target-utils");
const template_scaffold_1 = require("../template-scaffold");
const logger = new logger_1.Logger('pgpm');
function sortObjectByKey(obj) {
    return Object.fromEntries(Object.entries(obj).sort(([a], [b]) => a.localeCompare(b)));
}
/**
 * Truncates workspace extensions to include only modules from the target onwards.
 * This prevents processing unnecessary modules that come before the target in dependency order.
 *
 * @param workspaceExtensions - The full workspace extension dependencies
 * @param targetName - The target module name to truncate from
 * @returns Truncated extensions starting from the target module
 */
const truncateExtensionsToTarget = (workspaceExtensions, targetName) => {
    const targetIndex = workspaceExtensions.resolved.indexOf(targetName);
    if (targetIndex === -1) {
        return workspaceExtensions;
    }
    return {
        resolved: workspaceExtensions.resolved.slice(targetIndex),
        external: workspaceExtensions.external
    };
};
var PackageContext;
(function (PackageContext) {
    PackageContext["Outside"] = "outside";
    PackageContext["Workspace"] = "workspace-root";
    PackageContext["Module"] = "module";
    PackageContext["ModuleInsideWorkspace"] = "module-in-workspace";
})(PackageContext || (exports.PackageContext = PackageContext = {}));
class PgpmPackage {
    cwd;
    workspacePath;
    modulePath;
    config;
    allowedDirs = [];
    allowedParentDirs = [];
    /**
     * Directory name (relative to the workspace root) where pgpm modules are installed.
     * Resolved from the constructor option, `PGPM_EXTENSIONS_DIR`, the `extensionsDir`
     * config field, then the `extensions` default.
     */
    extensionsDir = types_1.DEFAULT_EXTENSIONS_DIR;
    options;
    _moduleMap;
    _moduleInfo;
    constructor(cwd = process.cwd(), options = {}) {
        this.options = options;
        this.resetCwd(cwd);
    }
    resetCwd(cwd) {
        this.cwd = cwd;
        this.workspacePath = (0, env_1.resolvePgpmPath)(this.cwd);
        this.modulePath = this.resolveSqitchPath();
        this.extensionsDir = (0, env_1.getExtensionsDir)(this.options.extensionsDir, this.workspacePath ?? this.cwd);
        if (this.workspacePath) {
            this.config = this.loadConfigSync();
            this.allowedDirs = this.loadAllowedDirs();
            this.allowedParentDirs = this.loadAllowedParentDirs();
        }
    }
    /**
     * Absolute path of the workspace directory where pgpm modules are installed.
     */
    getExtensionsPath() {
        this.ensureWorkspace();
        return path_1.default.join(this.workspacePath, this.extensionsDir);
    }
    resolveSqitchPath() {
        try {
            return (0, env_1.walkUp)(this.cwd, 'pgpm.plan');
        }
        catch {
            return undefined;
        }
    }
    loadConfigSync() {
        return (0, env_1.loadConfigSyncFromDir)(this.workspacePath);
    }
    loadAllowedDirs() {
        const globs = this.config?.packages ?? [];
        const dirs = globs.flatMap(pattern => (0, glob_1.globPaths)(this.workspacePath, pattern));
        const resolvedDirs = dirs.map(dir => path_1.default.resolve(dir));
        // Remove duplicates by converting to Set and back to array
        return [...new Set(resolvedDirs.sort((a, b) => a.localeCompare(b)))];
    }
    loadAllowedParentDirs() {
        const globs = this.config?.packages ?? [];
        const parentDirs = globs.map(pattern => {
            // Remove glob characters (*, **, ?, etc.) to get the base path
            const basePath = pattern.replace(/[*?[\]{}]/g, '').replace(/\/$/, '');
            return path_1.default.resolve(this.workspacePath, basePath);
        });
        // Remove duplicates by converting to Set and back to array
        return [...new Set(parentDirs)];
    }
    isInsideAllowedDirs(cwd) {
        return this.allowedDirs.some(dir => cwd.startsWith(dir));
    }
    isParentOfAllowedDirs(cwd) {
        const resolvedCwd = path_1.default.resolve(cwd);
        return this.allowedDirs.some(dir => dir.startsWith(resolvedCwd + path_1.default.sep)) ||
            this.allowedParentDirs.some(dir => path_1.default.resolve(dir) === resolvedCwd);
    }
    createModuleDirectory(modName) {
        this.ensureWorkspace();
        const isRoot = path_1.default.resolve(this.workspacePath) === path_1.default.resolve(this.cwd);
        const isParentDir = this.isParentOfAllowedDirs(this.cwd);
        const isInsideModule = this.isInsideAllowedDirs(this.cwd);
        let targetPath;
        if (isRoot) {
            const packagesDir = path_1.default.join(this.cwd, 'packages');
            fs_1.default.mkdirSync(packagesDir, { recursive: true });
            targetPath = path_1.default.join(packagesDir, modName);
        }
        else if (isParentDir) {
            targetPath = path_1.default.join(this.cwd, modName);
        }
        else if (isInsideModule) {
            console.error(yanse_1.default.red(`Error: Cannot create a module inside an existing module. Please run 'pgpm init' from the workspace root or from a parent directory like 'packages/'.`));
            process.exit(1);
        }
        else {
            console.error(yanse_1.default.red(`Error: You must be inside the workspace root, a parent directory of modules (like 'packages/'), or inside one of the workspace packages: ${this.allowedDirs.join(', ')}`));
            process.exit(1);
        }
        fs_1.default.mkdirSync(targetPath, { recursive: true });
        return targetPath;
    }
    ensureModule() {
        if (!this.modulePath)
            throw new Error('Not inside a module');
    }
    ensureWorkspace() {
        if (!this.workspacePath)
            throw new Error('Not inside a workspace');
    }
    getContext() {
        if (this.modulePath && this.workspacePath) {
            const rel = path_1.default.relative(this.workspacePath, this.modulePath);
            const nested = !rel.startsWith('..') && !path_1.default.isAbsolute(rel);
            return nested ? PackageContext.ModuleInsideWorkspace : PackageContext.Module;
        }
        if (this.modulePath)
            return PackageContext.Module;
        if (this.workspacePath)
            return PackageContext.Workspace;
        return PackageContext.Outside;
    }
    isInWorkspace() {
        return this.getContext() === PackageContext.Workspace;
    }
    isInModule() {
        return (this.getContext() === PackageContext.Module ||
            this.getContext() === PackageContext.ModuleInsideWorkspace);
    }
    getWorkspacePath() {
        return this.workspacePath;
    }
    getModulePath() {
        return this.modulePath;
    }
    clearCache() {
        delete this._moduleInfo;
        delete this._moduleMap;
    }
    // ──────────────── Workspace-wide ────────────────
    async getModules() {
        if (!this.workspacePath || !this.config)
            return [];
        const dirs = this.loadAllowedDirs();
        const results = [];
        for (const dir of dirs) {
            const proj = new PgpmPackage(dir, this.options);
            if (proj.isInModule()) {
                results.push(proj);
            }
        }
        return results;
    }
    /**
     * List all modules by parsing .control files in the workspace directory.
     * Handles naming collisions by preferring the shortest path.
     */
    listModules() {
        if (!this.workspacePath)
            return {};
        // Workspace membership is first-class: modules are discovered from the
        // workspace's declared `packages` globs plus the installed extensions/
        // directory — never from an unscoped workspace-wide scan. This keeps
        // nested workspaces (e.g. test fixtures) out of the module map.
        const packageDirs = [
            ...this.allowedDirs,
            ...(0, glob_1.globPaths)(this.workspacePath, this.extensionsDir, '{*,@*/*}')
        ];
        const moduleFiles = [...new Set(packageDirs.flatMap(dir => glob.sync((0, glob_1.globPattern)(dir, '**/*.control'))))].filter((file) => !/node_modules/.test(file)).sort((a, b) => a.localeCompare(b));
        // Group files by module name to handle collisions
        const filesByName = new Map();
        moduleFiles.forEach((file) => {
            const moduleName = path_1.default.basename(file).split('.control')[0];
            if (!filesByName.has(moduleName)) {
                filesByName.set(moduleName, []);
            }
            filesByName.get(moduleName).push(file);
        });
        // For each module name, pick the shortest path in case of collisions
        const selectedFiles = new Map();
        filesByName.forEach((files, moduleName) => {
            if (files.length === 1) {
                selectedFiles.set(moduleName, files[0]);
            }
            else {
                // Multiple files with same name - pick shortest path
                const shortestFile = files.reduce((shortest, current) => current.length < shortest.length ? current : shortest);
                selectedFiles.set(moduleName, shortestFile);
            }
        });
        // Parse the selected control files
        const moduleMap = Array.from(selectedFiles.entries()).reduce((acc, [moduleName, file]) => {
            const module = (0, files_2.parseControlFile)(file, this.workspacePath);
            acc[moduleName] = module;
            return acc;
        }, {});
        return this.addApplyModules(moduleMap, packageDirs);
    }
    /**
     * Discover apply-spec proxy modules (`pgpm.apply.json`) and synthesize
     * module-map entries for them so they participate in dependency resolution
     * by name like any other module. A proxy needs no `.control` or `pgpm.plan`;
     * its `requires` default to the source module's requires. Control-file
     * modules win name collisions.
     */
    addApplyModules(moduleMap, packageDirs) {
        const specFiles = [...new Set(packageDirs.flatMap(dir => glob.sync((0, glob_1.globPattern)(dir, `**/${types_2.APPLY_SPEC_FILE}`))))].filter((file) => !/node_modules/.test(file)).sort((a, b) => a.localeCompare(b));
        for (const file of specFiles) {
            let spec;
            try {
                spec = (0, apply_spec_1.readApplySpec)(path_1.default.dirname(file));
            }
            catch (err) {
                console.warn(`Skipping invalid apply spec ${file}: ${err instanceof Error ? err.message : err}`);
                continue;
            }
            const name = spec.name;
            if (moduleMap[name])
                continue;
            const source = moduleMap[spec.source.module];
            const relPath = path_1.default
                .dirname(path_1.default.relative(this.workspacePath, file))
                .replace(/\\/g, '/');
            const baseRequires = spec.requires ?? source?.requires ?? [];
            const version = spec.version ?? source?.version ?? '0.0.1';
            if ((0, reuse_1.isReuseSpec)(spec)) {
                // A reuse proxy expands into two modules that both materialize from
                // this one directory: a shared module (deployed once, reused across
                // tenants) and the per-tenant module that `requires` it. Multiple
                // tenant proxies over the same source/shared/seed config resolve to
                // the same deterministic shared name, so it is added at most once.
                const sharedName = (0, reuse_1.resolveSharedModuleName)(spec);
                if (!moduleMap[sharedName]) {
                    moduleMap[sharedName] = { path: relPath, requires: baseRequires, version };
                }
                moduleMap[name] = {
                    path: relPath,
                    requires: [...baseRequires, sharedName],
                    version
                };
            }
            else {
                moduleMap[name] = { path: relPath, requires: baseRequires, version };
            }
        }
        return moduleMap;
    }
    getModuleMap() {
        if (!this.workspacePath)
            return {};
        if (this._moduleMap)
            return this._moduleMap;
        this._moduleMap = this.listModules();
        return this._moduleMap;
    }
    async getAvailableModules() {
        const modules = this.getModuleMap();
        return await (0, extensions_1.getAvailableExtensions)(modules);
    }
    getModuleProject(name) {
        this.ensureWorkspace();
        if (this.isInModule() && name === this.getModuleName()) {
            return this;
        }
        const modules = this.getModuleMap();
        if (!modules[name]) {
            throw types_1.errors.MODULE_NOT_FOUND({ name });
        }
        const modulePath = path_1.default.resolve(this.workspacePath, modules[name].path);
        return new PgpmPackage(modulePath, this.options);
    }
    // ──────────────── Module-scoped ────────────────
    getModuleInfo() {
        this.ensureModule();
        if (!this._moduleInfo) {
            this._moduleInfo = (0, files_2.getExtensionInfo)(this.cwd);
        }
        return this._moduleInfo;
    }
    getModuleName() {
        this.ensureModule();
        return (0, files_2.getExtensionName)(this.cwd);
    }
    getRequiredModules() {
        this.ensureModule();
        const info = this.getModuleInfo();
        return (0, files_2.getInstalledExtensions)(info.controlFile);
    }
    setModuleDependencies(modules) {
        this.ensureModule();
        // Validate for circular dependencies
        this.validateModuleDependencies(modules);
        (0, files_2.writeExtensions)(this.cwd, modules);
    }
    validateModuleDependencies(modules) {
        const currentModuleName = this.getModuleName();
        if (modules.includes(currentModuleName)) {
            throw types_1.errors.CIRCULAR_DEPENDENCY({ module: currentModuleName, dependency: currentModuleName });
        }
        // Check for circular dependencies by examining each module's dependencies
        const visited = new Set();
        const visiting = new Set();
        const checkCircular = (moduleName, path = []) => {
            if (visiting.has(moduleName)) {
                throw types_1.errors.CIRCULAR_DEPENDENCY({ module: path.join(' -> '), dependency: moduleName });
            }
            if (visited.has(moduleName)) {
                return;
            }
            visiting.add(moduleName);
            // More complex dependency resolution would require loading other modules' dependencies
            visiting.delete(moduleName);
            visited.add(moduleName);
        };
        modules.forEach(module => checkCircular(module, [currentModuleName]));
    }
    initModuleSqitch(modName, targetPath) {
        const plan = (0, files_1.generatePlan)({
            moduleName: modName,
            uri: modName,
            entries: []
        });
        (0, files_1.writePlan)(path_1.default.join(targetPath, 'pgpm.plan'), plan);
        // Create deploy, revert, and verify directories
        const dirs = ['deploy', 'revert', 'verify'];
        dirs.forEach(dir => {
            const dirPath = path_1.default.join(targetPath, dir);
            if (!fs_1.default.existsSync(dirPath)) {
                fs_1.default.mkdirSync(dirPath, { recursive: true });
            }
        });
    }
    async initModule(options) {
        this.ensureWorkspace();
        // Determine if this is a pgpm-managed module (defaults to true for backward compatibility)
        const isPgpmModule = options.pgpm ?? true;
        // If outputDir is provided, use it directly instead of createModuleDirectory
        let targetPath;
        if (options.outputDir) {
            // Resolve outputDir relative to workspace if not absolute
            const resolvedOutputDir = path_1.default.isAbsolute(options.outputDir)
                ? options.outputDir
                : path_1.default.resolve(this.workspacePath, options.outputDir);
            targetPath = path_1.default.join(resolvedOutputDir, options.name);
            fs_1.default.mkdirSync(targetPath, { recursive: true });
        }
        else {
            targetPath = this.createModuleDirectory(options.name);
        }
        const answers = {
            ...options.answers,
            name: options.name,
            moduleDesc: options.description,
            description: options.description,
            author: options.author,
            extensions: options.extensions
        };
        await (0, template_scaffold_1.scaffoldTemplate)({
            fromPath: options.templatePath ?? 'module',
            outputDir: targetPath,
            templateRepo: options.templateRepo ?? template_scaffold_1.DEFAULT_TEMPLATE_REPO,
            branch: options.branch,
            dir: options.dir,
            answers,
            noTty: options.noTty ?? false,
            cacheTtlMs: options.cacheTtlMs ?? template_scaffold_1.DEFAULT_TEMPLATE_TTL_MS,
            toolName: options.toolName ?? template_scaffold_1.DEFAULT_TEMPLATE_TOOL_NAME,
            cwd: this.cwd,
            prompter: options.prompter
        });
        // Only create pgpm files (pgpm.plan, .control, deploy/revert/verify dirs) for pgpm-managed modules
        if (isPgpmModule) {
            this.initModuleSqitch(options.name, targetPath);
            (0, files_2.writeExtensions)(targetPath, options.extensions);
        }
    }
    // ──────────────── Dependency Analysis ────────────────
    getLatestChange(moduleName) {
        const modules = this.getModuleMap();
        return (0, modules_1.latestChange)(moduleName, modules, this.workspacePath);
    }
    getLatestChangeAndVersion(moduleName) {
        const modules = this.getModuleMap();
        return (0, modules_1.latestChangeAndVersion)(moduleName, modules, this.workspacePath);
    }
    getModuleExtensions() {
        this.ensureModule();
        const moduleName = this.getModuleName();
        const moduleMap = this.getModuleMap();
        return (0, deps_1.resolveExtensionDependencies)(moduleName, moduleMap);
    }
    getModuleDependencies(moduleName) {
        const modules = this.getModuleMap();
        const { native, sqitch } = (0, modules_1.getExtensionsAndModules)(moduleName, modules);
        return { native, modules: sqitch };
    }
    getModuleDependencyChanges(moduleName) {
        const modules = this.getModuleMap();
        const { native, sqitch } = (0, modules_1.getExtensionsAndModulesChanges)(moduleName, modules, this.workspacePath);
        return { native, modules: sqitch };
    }
    // ──────────────── Plans ────────────────
    getModulePlan() {
        this.ensureModule();
        const planPath = path_1.default.join(this.getModulePath(), 'pgpm.plan');
        return fs_1.default.readFileSync(planPath, 'utf8');
    }
    getModuleControlFile() {
        this.ensureModule();
        const info = this.getModuleInfo();
        return fs_1.default.readFileSync(info.controlFile, 'utf8');
    }
    getModuleMakefile() {
        this.ensureModule();
        const info = this.getModuleInfo();
        return fs_1.default.readFileSync(info.Makefile, 'utf8');
    }
    getModuleSQL() {
        this.ensureModule();
        const info = this.getModuleInfo();
        return fs_1.default.readFileSync(info.sqlFile, 'utf8');
    }
    generateModulePlan(options) {
        this.ensureModule();
        const info = this.getModuleInfo();
        const moduleName = info.extname;
        // Get raw dependencies and resolved list
        const tagResolution = options.includeTags === true ? 'preserve' : 'internal';
        let { resolved, deps } = (0, deps_1.resolveDependencies)(this.cwd, moduleName, { tagResolution });
        // Helper to extract module name from a change reference
        const getModuleName = (change) => {
            const colonIndex = change.indexOf(':');
            return colonIndex > 0 ? change.substring(0, colonIndex) : null;
        };
        // Helper to determine if a change is truly from an external package
        const isExternalChange = (change) => {
            const changeModule = getModuleName(change);
            return changeModule !== null && changeModule !== moduleName;
        };
        // Helper to normalize change name (remove package prefix)
        const normalizeChangeName = (change) => {
            return change.includes(':') ? change.split(':').pop() : change;
        };
        // Clean up the resolved list to handle both formats
        const uniqueChangeNames = new Set();
        const normalizedResolved = [];
        // First, add local changes without prefixes
        resolved.forEach(change => {
            const normalized = normalizeChangeName(change);
            // Skip if we've already added this change
            if (uniqueChangeNames.has(normalized))
                return;
            // Skip truly external changes - they should only be in dependencies
            if (isExternalChange(change))
                return;
            uniqueChangeNames.add(normalized);
            normalizedResolved.push(normalized);
        });
        // Clean up the deps object
        const normalizedDeps = {};
        // Process each deps entry
        Object.keys(deps).forEach(key => {
            // Normalize the key - strip "/deploy/" and ".sql" if present
            let normalizedKey = key;
            if (normalizedKey.startsWith('/deploy/')) {
                normalizedKey = normalizedKey.substring(8); // Remove "/deploy/"
            }
            if (normalizedKey.endsWith('.sql')) {
                normalizedKey = normalizedKey.substring(0, normalizedKey.length - 4); // Remove ".sql"
            }
            // Skip keys for truly external changes - we only want local changes as keys
            if (isExternalChange(normalizedKey))
                return;
            // Normalize the key for all changes, removing any same-package prefix
            const cleanKey = normalizeChangeName(normalizedKey);
            // Build the standard key format for our normalized deps
            const standardKey = `/deploy/${cleanKey}.sql`;
            // Initialize the dependencies array for this key if it doesn't exist
            normalizedDeps[standardKey] = normalizedDeps[standardKey] || [];
            // Add dependencies, handling both formats
            const dependencies = deps[key] || [];
            dependencies.forEach(dep => {
                // For truly external dependencies, keep the full reference
                if (isExternalChange(dep)) {
                    if (!normalizedDeps[standardKey].includes(dep)) {
                        normalizedDeps[standardKey].push(dep);
                    }
                }
                else {
                    // For same-package dependencies, normalize by removing prefix
                    const normalizedDep = normalizeChangeName(dep);
                    if (!normalizedDeps[standardKey].includes(normalizedDep)) {
                        normalizedDeps[standardKey].push(normalizedDep);
                    }
                }
            });
        });
        // Update with normalized versions
        resolved = normalizedResolved;
        deps = normalizedDeps;
        // Process external dependencies if needed
        const includePackages = options.includePackages === true;
        const preferTags = options.includeTags === true;
        if (includePackages && this.workspacePath) {
            const depData = this.getModuleDependencyChanges(moduleName);
            if (resolved.length > 0) {
                const firstKey = `/deploy/${resolved[0]}.sql`;
                deps[firstKey] = deps[firstKey] || [];
                depData.modules.forEach(m => {
                    const extModuleName = m.name;
                    const hasTagDependency = deps[firstKey].some(dep => dep.startsWith(`${extModuleName}:@`));
                    let depToken = `${extModuleName}:${m.latest}`;
                    if (preferTags) {
                        try {
                            const moduleMap = this.getModuleMap();
                            const modInfo = moduleMap[extModuleName];
                            if (modInfo && this.workspacePath) {
                                const planPath = path_1.default.join(this.workspacePath, modInfo.path, 'pgpm.plan');
                                const parsed = (0, parser_1.parsePlanFile)(planPath);
                                const changes = parsed.data?.changes || [];
                                const tags = parsed.data?.tags || [];
                                if (changes.length > 0 && tags.length > 0) {
                                    const lastChangeName = changes[changes.length - 1]?.name;
                                    const lastTag = tags[tags.length - 1];
                                    if (lastTag && lastTag.change === lastChangeName) {
                                        depToken = `${extModuleName}:@${lastTag.name}`;
                                    }
                                }
                            }
                        }
                        catch { }
                    }
                    if (!hasTagDependency && !deps[firstKey].includes(depToken)) {
                        deps[firstKey].push(depToken);
                    }
                });
            }
        }
        // For debugging - log the cleaned structures
        // console.log("CLEAN DEPS GRAPH", JSON.stringify(deps, null, 2));
        // console.log("CLEAN RES GRAPH", JSON.stringify(resolved, null, 2));
        // Prepare entries for the plan file
        const entries = resolved.map(res => {
            const key = `/deploy/${res}.sql`;
            const dependencies = deps[key] || [];
            // Filter out dependencies that match the current change name
            // This prevents listing a change as dependent on itself
            const filteredDeps = dependencies.filter(dep => normalizeChangeName(dep) !== res);
            return {
                change: res,
                dependencies: filteredDeps,
                comment: `add ${res}`
            };
        });
        // Use the package-files package to generate the plan
        return (0, files_1.generatePlan)({
            moduleName,
            uri: options.uri,
            entries
        });
    }
    writeModulePlan(options) {
        this.ensureModule();
        const name = this.getModuleName();
        const plan = this.generateModulePlan(options);
        const moduleMap = this.getModuleMap();
        const mod = moduleMap[name];
        const planPath = path_1.default.join(this.workspacePath, mod.path, 'pgpm.plan');
        // Use the package-files package to write the plan
        (0, files_1.writePlan)(planPath, plan);
    }
    /**
     * Add a tag to the current module's plan file
     */
    addTag(tagName, changeName, comment) {
        this.ensureModule();
        if (!this.modulePath) {
            throw types_1.errors.PATH_NOT_FOUND({ path: 'module path', type: 'module' });
        }
        // Validate tag name
        if (!(0, validators_1.isValidTagName)(tagName)) {
            throw types_1.errors.INVALID_NAME({ name: tagName, type: 'tag', rules: "Tag names must follow Sqitch naming rules and cannot contain '/'" });
        }
        const planPath = path_1.default.join(this.modulePath, 'pgpm.plan');
        // Parse existing plan file
        const planResult = (0, parser_1.parsePlanFile)(planPath);
        if (!planResult.data) {
            throw types_1.errors.PLAN_PARSE_ERROR({ planPath, errors: planResult.errors.map(e => e.message).join(', ') });
        }
        const plan = planResult.data;
        let targetChange = changeName;
        if (!targetChange) {
            if (plan.changes.length === 0) {
                throw new Error('No changes found in plan file. Cannot add tag without a target change.');
            }
            targetChange = plan.changes[plan.changes.length - 1].name;
        }
        else {
            // Validate that the specified change exists
            const changeExists = plan.changes.some(c => c.name === targetChange);
            if (!changeExists) {
                throw types_1.errors.CHANGE_NOT_FOUND({ change: targetChange });
            }
        }
        // Check if tag already exists
        const existingTag = plan.tags.find(t => t.name === tagName);
        if (existingTag) {
            throw new Error(`Tag '${tagName}' already exists and points to change '${existingTag.change}'.`);
        }
        // Create new tag
        const newTag = {
            name: tagName,
            change: targetChange,
            timestamp: (0, generator_1.getNow)(),
            planner: 'constructive',
            email: 'constructive@5b0c196eeb62',
            comment
        };
        plan.tags.push(newTag);
        // Write updated plan file
        (0, files_1.writePlanFile)(planPath, plan);
    }
    /**
     * Add a change to the current module's plan file and create SQL files
     */
    addChange(changeName, dependencies, comment) {
        // Validate change name first
        if (!changeName || !changeName.trim()) {
            throw new Error('Change name is required');
        }
        if (!(0, validators_1.isValidChangeName)(changeName)) {
            throw types_1.errors.INVALID_NAME({ name: changeName, type: 'change', rules: 'Change names must follow Sqitch naming rules' });
        }
        if (!this.isInWorkspace() && !this.isInModule()) {
            throw new Error('This command must be run inside a PGPM workspace or module.');
        }
        if (this.isInModule()) {
            this.ensureModule();
            if (!this.modulePath) {
                throw types_1.errors.PATH_NOT_FOUND({ path: 'module path', type: 'module' });
            }
            this.addChangeToModule(changeName, dependencies, comment);
            return;
        }
        throw new Error('When running from workspace root, please specify --package or run from within a module directory.');
    }
    /**
     * Add change to the current module (internal helper)
     */
    addChangeToModule(changeName, dependencies, comment) {
        const planPath = path_1.default.join(this.modulePath, 'pgpm.plan');
        // Parse existing plan file
        const planResult = (0, parser_1.parsePlanFile)(planPath);
        if (!planResult.data) {
            throw types_1.errors.PLAN_PARSE_ERROR({ planPath, errors: planResult.errors.map(e => e.message).join(', ') });
        }
        const plan = planResult.data;
        // Check if change already exists
        const existingChange = plan.changes.find(c => c.name === changeName);
        if (existingChange) {
            throw new Error(`Change '${changeName}' already exists in plan.`);
        }
        // Validate dependencies exist if provided
        if (dependencies && dependencies.length > 0) {
            const currentPackage = plan.package;
            for (const dep of dependencies) {
                // Parse the dependency to check if it's a cross-module reference
                const parsed = (0, validators_1.parseReference)(dep);
                if (parsed && parsed.package && parsed.package !== currentPackage) {
                    continue;
                }
                const depExists = plan.changes.some(c => c.name === dep);
                if (!depExists) {
                    throw new Error(`Dependency '${dep}' not found in plan. Add dependencies before referencing them.`);
                }
            }
        }
        // Create new change
        const newChange = {
            name: changeName,
            dependencies: dependencies || [],
            timestamp: (0, generator_1.getNow)(),
            planner: 'constructive',
            email: 'constructive@5b0c196eeb62',
            comment: comment || `add ${changeName}`
        };
        plan.changes.push(newChange);
        // Write updated plan file
        (0, files_1.writePlanFile)(planPath, plan);
        // Create SQL files
        this.createSqlFiles(changeName, dependencies || [], comment || `add ${changeName}`);
    }
    /**
     * Create deploy/revert/verify SQL files for a change
     */
    createSqlFiles(changeName, dependencies, comment) {
        if (!this.modulePath) {
            throw types_1.errors.PATH_NOT_FOUND({ path: 'module path', type: 'module' });
        }
        const createdFiles = [];
        const createSqlFile = (type, content) => {
            const dir = path_1.default.dirname(changeName);
            const fileName = path_1.default.basename(changeName);
            const typeDir = path_1.default.join(this.modulePath, type);
            const targetDir = path_1.default.join(typeDir, dir);
            const filePath = path_1.default.join(targetDir, `${fileName}.sql`);
            fs_1.default.mkdirSync(targetDir, { recursive: true });
            fs_1.default.writeFileSync(filePath, content);
            // Track the relative path from module root
            const relativePath = path_1.default.relative(this.modulePath, filePath);
            createdFiles.push(relativePath);
        };
        // Create deploy file
        const deployContent = `-- Deploy: ${changeName}
-- made with <3 @ constructive.io

${dependencies.length > 0 ? dependencies.map(dep => `-- requires: ${dep}`).join('\n') + '\n' : ''}
-- Add your deployment SQL here
`;
        // Create revert file  
        const revertContent = `-- Revert: ${changeName}

-- Add your revert SQL here
`;
        // Create verify file
        const verifyContent = `-- Verify: ${changeName}

-- Add your verification SQL here
`;
        createSqlFile('deploy', deployContent);
        createSqlFile('revert', revertContent);
        createSqlFile('verify', verifyContent);
        // Log created files to stdout
        process.stdout.write('\n✔ Files created\n\n');
        createdFiles.forEach(file => {
            process.stdout.write(`   create  ${file}\n`);
        });
        process.stdout.write('\n✨ All set!\n\n');
    }
    // ──────────────── Packaging and npm ────────────────
    publishToDist(distFolder = 'dist') {
        this.ensureModule();
        const modPath = this.modulePath; // use modulePath, not cwd
        const name = this.getModuleName();
        const controlFile = `${name}.control`;
        const fullDist = path_1.default.join(modPath, distFolder);
        if (fs_1.default.existsSync(fullDist)) {
            fs_1.default.rmSync(fullDist, { recursive: true, force: true });
        }
        fs_1.default.mkdirSync(fullDist, { recursive: true });
        const folders = ['deploy', 'revert', 'sql', 'verify'];
        const files = ['Makefile', 'package.json', 'pgpm.plan', controlFile];
        // Add README file regardless of casing
        const readmeFile = fs_1.default.readdirSync(modPath).find(f => /^readme\.md$/i.test(f));
        if (readmeFile) {
            files.push(readmeFile); // Include it in the list of files to copy
        }
        for (const folder of folders) {
            const src = path_1.default.join(modPath, folder);
            if (fs_1.default.existsSync(src)) {
                fs_1.default.cpSync(src, path_1.default.join(fullDist, folder), { recursive: true });
            }
        }
        for (const file of files) {
            const src = path_1.default.join(modPath, file);
            if (!fs_1.default.existsSync(src)) {
                throw new Error(`Missing required file: ${file}`);
            }
            fs_1.default.cpSync(src, path_1.default.join(fullDist, file));
        }
    }
    /**
      * Installs an extension npm package into the workspace extensions directory.
      *
      * When run inside a module, the installed version is recorded in the
      * module's package.json dependencies and its .control requires list.
      * When run at the workspace root, the installed version is recorded in
      * the workspace pgpm.json `dependencies` field instead — no .control
      * file is needed.
      */
    async installModules(...pkgstrs) {
        this.ensureWorkspace();
        const inModule = this.isInModule();
        const originalDir = process.cwd();
        const skitchExtDir = this.getExtensionsPath();
        let pkgJsonPath;
        let pkgData;
        if (inModule) {
            pkgJsonPath = path_1.default.join(this.modulePath, 'package.json');
            if (!fs_1.default.existsSync(pkgJsonPath)) {
                throw new Error(`No package.json found at module path: ${this.modulePath}`);
            }
            pkgData = JSON.parse(fs_1.default.readFileSync(pkgJsonPath, 'utf-8'));
            pkgData.dependencies = pkgData.dependencies || {};
        }
        const newlyAdded = [];
        const installedVersions = {};
        for (const pkgstr of pkgstrs) {
            const { name } = (0, parse_package_name_1.parse)(pkgstr);
            const tempDir = fs_1.default.mkdtempSync(path_1.default.join(os_1.default.tmpdir(), 'pgpm-install-'));
            try {
                process.chdir(tempDir);
                (0, child_process_1.execSync)(`npm install ${pkgstr} --production --prefix ./${this.extensionsDir}`, {
                    stdio: 'inherit'
                });
                const matches = glob.sync((0, glob_1.globPattern)('.', this.extensionsDir, '**/pgpm.plan'));
                const installs = matches.map((conf) => {
                    const fullConf = (0, path_1.resolve)(conf);
                    const extDir = (0, path_1.dirname)(fullConf);
                    const parts = (0, glob_1.toPosixPath)(extDir).split('node_modules/');
                    const relativeDir = parts[parts.length - 1];
                    const dstDir = path_1.default.join(skitchExtDir, relativeDir);
                    return { src: extDir, dst: dstDir, pkg: relativeDir };
                });
                // Sort deepest paths first so nested node_modules deps are
                // extracted before their parent directories are moved.
                installs.sort((a, b) => (0, glob_1.toPosixPath)(b.src).split('/').length - (0, glob_1.toPosixPath)(a.src).split('/').length);
                for (const { src, dst, pkg } of installs) {
                    if (fs_1.default.existsSync(dst)) {
                        fs_1.default.rmSync(dst, { recursive: true, force: true });
                    }
                    fs_1.default.mkdirSync(path_1.default.dirname(dst), { recursive: true });
                    (0, fs_2.movePath)(src, dst);
                    logger.success(`✔ installed ${pkg}`);
                    const pkgJsonFile = path_1.default.join(dst, 'package.json');
                    if (!fs_1.default.existsSync(pkgJsonFile)) {
                        throw new Error(`Missing package.json in installed extension: ${dst}`);
                    }
                    const { name: installedName, version } = JSON.parse(fs_1.default.readFileSync(pkgJsonFile, 'utf-8'));
                    if (installedName === name) {
                        installedVersions[name] = `${version}`;
                        if (pkgData) {
                            pkgData.dependencies[name] = `${version}`;
                        }
                    }
                    const extensionName = (0, files_2.getExtensionName)(dst);
                    newlyAdded.push(extensionName);
                }
            }
            finally {
                // chdir out first: Windows locks the process working directory
                process.chdir(originalDir);
                fs_1.default.rmSync(tempDir, { recursive: true, force: true });
            }
        }
        if (inModule && pkgData && pkgJsonPath) {
            const { dependencies, devDependencies, ...rest } = pkgData;
            const finalPkgData = { ...rest };
            if (dependencies) {
                finalPkgData.dependencies = sortObjectByKey(dependencies);
            }
            if (devDependencies) {
                finalPkgData.devDependencies = sortObjectByKey(devDependencies);
            }
            fs_1.default.writeFileSync(pkgJsonPath, JSON.stringify(finalPkgData, null, 2));
            logger.success(`📦 Updated package.json with: ${pkgstrs.join(', ')}`);
            // ─── Update .control file with actual extension names ──────────────
            const currentDeps = this.getRequiredModules();
            const updatedDeps = Array.from(new Set([...currentDeps, ...newlyAdded])).sort();
            (0, files_2.writeExtensions)(this.modulePath, updatedDeps);
        }
        else {
            this.recordWorkspaceDependencies(installedVersions);
        }
    }
    /**
     * Returns the workspace-level pgpm module dependencies recorded in
     * the workspace pgpm.json `dependencies` field.
     */
    getWorkspaceDependencies() {
        this.ensureWorkspace();
        const configPath = path_1.default.join(this.workspacePath, 'pgpm.json');
        if (!fs_1.default.existsSync(configPath)) {
            return {};
        }
        const config = JSON.parse(fs_1.default.readFileSync(configPath, 'utf-8'));
        return config.dependencies || {};
    }
    /**
     * Records installed module versions into the workspace pgpm.json
     * `dependencies` field. No-op when the workspace uses pgpm.config.js.
     */
    recordWorkspaceDependencies(versions) {
        this.ensureWorkspace();
        if (Object.keys(versions).length === 0)
            return;
        const configPath = path_1.default.join(this.workspacePath, 'pgpm.json');
        if (!fs_1.default.existsSync(configPath)) {
            logger.warn('No pgpm.json found at workspace root — skipping dependency recording.');
            return;
        }
        const config = JSON.parse(fs_1.default.readFileSync(configPath, 'utf-8'));
        config.dependencies = sortObjectByKey({
            ...(config.dependencies || {}),
            ...versions
        });
        fs_1.default.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n');
        logger.success(`📦 Updated pgpm.json dependencies with: ${Object.keys(versions).join(', ')}`);
    }
    /**
     * Installs the workspace-level dependencies declared in pgpm.json into
     * the workspace extensions/ directory. Skips modules already present
     * unless `force` is set.
     *
     * @returns The list of installed package specs (name@version)
     */
    async installWorkspaceDependencies(options) {
        this.ensureWorkspace();
        const { force = false } = options || {};
        const dependencies = this.getWorkspaceDependencies();
        const installedModules = this.getWorkspaceInstalledModules();
        const toInstall = Object.entries(dependencies)
            .filter(([name]) => force || !installedModules.includes(name))
            .map(([name, version]) => `${name}@${version}`);
        if (toInstall.length === 0) {
            return [];
        }
        await this.installModules(...toInstall);
        return toInstall;
    }
    /**
     * Returns information about which of the specified modules are installed.
     * Checks the module's package.json dependencies to determine installation status.
     *
     * @param moduleNames - Array of npm package names to check (e.g., '@pgpm/base32')
     * @returns Object with installed (array of installed module names) and
     *          installedVersions (map of module name to installed version)
     */
    modulesInstalled(moduleNames) {
        this.ensureModule();
        const pkgJsonPath = path_1.default.join(this.modulePath, 'package.json');
        if (!fs_1.default.existsSync(pkgJsonPath)) {
            return { installed: [], installedVersions: {} };
        }
        const pkgData = JSON.parse(fs_1.default.readFileSync(pkgJsonPath, 'utf-8'));
        const dependencies = pkgData.dependencies || {};
        const installed = [];
        const installedVersions = {};
        for (const moduleName of moduleNames) {
            const { name } = (0, parse_package_name_1.parse)(moduleName);
            if (dependencies[name]) {
                installed.push(name);
                installedVersions[name] = dependencies[name];
            }
        }
        return { installed, installedVersions };
    }
    /**
     * Returns all installed pgpm modules from the module's package.json dependencies.
     * Only returns dependencies that exist in the workspace extensions directory.
     *
     * @returns Object with installed module names and their versions
     */
    getInstalledModules() {
        this.ensureModule();
        this.ensureWorkspace();
        const pkgJsonPath = path_1.default.join(this.modulePath, 'package.json');
        if (!fs_1.default.existsSync(pkgJsonPath)) {
            return { installed: [], installedVersions: {} };
        }
        const pkgData = JSON.parse(fs_1.default.readFileSync(pkgJsonPath, 'utf-8'));
        const dependencies = pkgData.dependencies || {};
        const skitchExtDir = this.getExtensionsPath();
        const installed = [];
        const installedVersions = {};
        for (const [name, version] of Object.entries(dependencies)) {
            const extPath = path_1.default.join(skitchExtDir, name);
            if (fs_1.default.existsSync(extPath)) {
                installed.push(name);
                installedVersions[name] = version;
            }
        }
        return { installed, installedVersions };
    }
    /**
     * Returns all pgpm modules installed in the workspace extensions directory.
     * Unlike getInstalledModules(), this does NOT require being inside a module.
     * It scans the workspace/extensions/ directory directly to find installed packages.
     *
     * This is useful for checking what's available at workspace level before a module exists.
     *
     * @returns Array of installed npm package names (e.g., '@pgpm/base32', '@pgpm/totp')
     */
    getWorkspaceInstalledModules() {
        this.ensureWorkspace();
        const extensionsDir = this.getExtensionsPath();
        if (!fs_1.default.existsSync(extensionsDir)) {
            return [];
        }
        const installed = [];
        const entries = fs_1.default.readdirSync(extensionsDir, { withFileTypes: true });
        for (const entry of entries) {
            if (!entry.isDirectory())
                continue;
            if (entry.name.startsWith('@')) {
                // Handle scoped packages like @pgpm/base32
                const scopeDir = path_1.default.join(extensionsDir, entry.name);
                const scopedEntries = fs_1.default.readdirSync(scopeDir, { withFileTypes: true });
                for (const scopedEntry of scopedEntries) {
                    if (scopedEntry.isDirectory()) {
                        installed.push(`${entry.name}/${scopedEntry.name}`);
                    }
                }
            }
            else {
                // Handle non-scoped packages
                installed.push(entry.name);
            }
        }
        return installed;
    }
    /**
     * Updates installed pgpm modules to their latest versions from npm.
     * Re-installs each module to get the latest version.
     * Also updates package.json for ALL modules in the workspace that reference the upgraded packages.
     *
     * Note: Extensions are installed globally in the workspace's extensions/ directory,
     * so upgrading affects all modules that depend on the upgraded package.
     *
     * @param options - Options for the update operation
     * @param options.modules - Specific modules to update (defaults to all installed modules)
     * @param options.dryRun - If true, only returns what would be updated without making changes
     * @returns Object with updated modules and their old/new versions
     */
    async upgradeModules(options) {
        this.ensureWorkspace();
        this.ensureModule();
        const { modules: specificModules, dryRun = false } = options || {};
        const { installed, installedVersions } = this.getInstalledModules();
        const modulesToUpdate = specificModules
            ? installed.filter(m => specificModules.includes(m))
            : installed;
        if (modulesToUpdate.length === 0) {
            logger.info('No modules to update.');
            return { updates: [], affectedModules: [] };
        }
        const updates = [];
        for (const moduleName of modulesToUpdate) {
            const oldVersion = installedVersions[moduleName];
            let newVersion = null;
            try {
                const result = (0, child_process_1.execSync)(`npm view ${moduleName} version`, {
                    encoding: 'utf-8',
                    stdio: ['pipe', 'pipe', 'pipe']
                }).trim();
                newVersion = result || null;
            }
            catch {
                logger.warn(`Could not fetch latest version for ${moduleName}`);
            }
            updates.push({
                name: moduleName,
                oldVersion,
                newVersion
            });
        }
        if (dryRun) {
            logger.info('Dry run - no changes made.');
            for (const update of updates) {
                if (update.newVersion && update.newVersion !== update.oldVersion) {
                    logger.info(`  ${update.name}: ${update.oldVersion} -> ${update.newVersion}`);
                }
                else if (update.newVersion === update.oldVersion) {
                    logger.info(`  ${update.name}: ${update.oldVersion} (already up to date)`);
                }
                else {
                    logger.warn(`  ${update.name}: ${update.oldVersion} (could not fetch latest)`);
                }
            }
            const updatesWithChanges = updates.filter(u => u.newVersion && u.newVersion !== u.oldVersion);
            return { updates: updatesWithChanges, affectedModules: [] };
        }
        const modulesToReinstall = updates
            .filter(u => u.newVersion && u.newVersion !== u.oldVersion)
            .map(u => u.name);
        if (modulesToReinstall.length === 0) {
            logger.success('All modules are already up to date.');
            return { updates, affectedModules: [] };
        }
        logger.info(`Upgrading ${modulesToReinstall.length} module(s)...`);
        await this.installModules(...modulesToReinstall);
        const { installedVersions: newVersions } = this.getInstalledModules();
        for (const update of updates) {
            if (modulesToReinstall.includes(update.name)) {
                update.newVersion = newVersions[update.name] || update.newVersion;
            }
        }
        // Update package.json for ALL modules in the workspace that reference the upgraded packages
        const affectedModules = this.updateWorkspaceModuleVersions(modulesToReinstall.reduce((acc, name) => {
            const update = updates.find(u => u.name === name);
            if (update?.newVersion) {
                acc[name] = update.newVersion;
            }
            return acc;
        }, {}));
        if (affectedModules.length > 0) {
            logger.info(`Updated package.json for ${affectedModules.length} module(s) in workspace.`);
        }
        logger.success('Upgrade complete.');
        return { updates, affectedModules };
    }
    /**
     * Updates package.json dependencies for all modules in the workspace that reference
     * the specified packages with their new versions.
     *
     * @param packageVersions - Map of package name to new version
     * @returns Array of module names that were updated
     */
    updateWorkspaceModuleVersions(packageVersions) {
        this.ensureWorkspace();
        const moduleMap = this.getModuleMap();
        const affectedModules = [];
        for (const [moduleName, moduleInfo] of Object.entries(moduleMap)) {
            const modulePath = path_1.default.resolve(this.workspacePath, moduleInfo.path);
            const pkgJsonPath = path_1.default.join(modulePath, 'package.json');
            if (!fs_1.default.existsSync(pkgJsonPath)) {
                continue;
            }
            const pkgData = JSON.parse(fs_1.default.readFileSync(pkgJsonPath, 'utf-8'));
            const dependencies = pkgData.dependencies || {};
            let updated = false;
            for (const [pkgName, newVersion] of Object.entries(packageVersions)) {
                if (dependencies[pkgName] && dependencies[pkgName] !== newVersion) {
                    dependencies[pkgName] = newVersion;
                    updated = true;
                }
            }
            if (updated) {
                pkgData.dependencies = sortObjectByKey(dependencies);
                fs_1.default.writeFileSync(pkgJsonPath, JSON.stringify(pkgData, null, 2));
                affectedModules.push(moduleName);
                logger.info(`  Updated ${moduleName}/package.json`);
            }
        }
        return affectedModules;
    }
    // ──────────────── Package Operations ────────────────
    /**
     * Sync extension metadata (.control default_version, Makefile sql filename,
     * and the sql/<name>--<version>.sql bundle) to the package.json version.
     * Inside a module, syncs just that module; at a workspace root, syncs every
     * workspace module. With `check: true`, reports skew without writing.
     */
    async syncVersions(options = {}) {
        if (this.isInModule()) {
            return (0, sync_versions_1.syncModuleVersions)([this.modulePath], options);
        }
        this.ensureWorkspace();
        const moduleMap = this.getModuleMap();
        const packageDirs = Object.values(moduleMap).map(mod => path_1.default.resolve(this.workspacePath, mod.path));
        return (0, sync_versions_1.syncModuleVersions)(packageDirs, options);
    }
    /**
     * Get the set of modules that have been deployed to the database
     */
    async getDeployedModules(pgConfig) {
        try {
            const client = new client_1.PgpmMigrate(pgConfig);
            await client.initialize();
            const status = await client.status();
            return new Set(status.map(s => s.package));
        }
        catch (error) {
            if (error.code === '42P01' || error.code === '3F000') {
                return new Set();
            }
            throw error;
        }
    }
    async resolveWorkspaceExtensionDependencies(opts) {
        const modules = this.getModuleMap();
        const allModuleNames = Object.keys(modules);
        if (allModuleNames.length === 0) {
            return { resolved: [], external: [] };
        }
        // Create a virtual module that depends on all workspace modules
        const virtualModuleName = '_virtual/workspace';
        const virtualModuleMap = {
            ...modules,
            [virtualModuleName]: {
                requires: allModuleNames
            }
        };
        const { resolved, external } = (0, deps_1.resolveExtensionDependencies)(virtualModuleName, virtualModuleMap);
        let filteredResolved = resolved.filter((moduleName) => moduleName !== virtualModuleName);
        // Filter by deployment status if requested
        if (opts?.filterDeployed && opts?.pgConfig) {
            const deployedModules = await this.getDeployedModules(opts.pgConfig);
            filteredResolved = filteredResolved.filter(module => deployedModules.has(module));
        }
        return {
            resolved: filteredResolved,
            external: external
        };
    }
    /**
     * Dependency closure for a named module. Proxy (apply-spec) modules have no
     * pgpm.plan, so they resolve straight off the workspace module map instead
     * of instantiating a module-rooted package.
     */
    getModuleExtensionsFor(name) {
        const modules = this.getModuleMap();
        if (!modules[name]) {
            throw types_1.errors.MODULE_NOT_FOUND({ name });
        }
        const modulePath = (0, path_1.resolve)(this.workspacePath, modules[name].path);
        if ((0, apply_spec_1.hasApplySpec)(modulePath)) {
            return (0, deps_1.resolveExtensionDependencies)(name, modules);
        }
        return this.getModuleProject(name).getModuleExtensions();
    }
    /**
     * Directory the migration engine should run against for a named module:
     * the module's own directory, or — for proxy (apply-spec) modules — the
     * materialized transpiled instance.
     */
    async getEffectiveModulePathFor(name) {
        const modules = this.getModuleMap();
        if (!modules[name]) {
            throw types_1.errors.MODULE_NOT_FOUND({ name });
        }
        const modulePath = (0, path_1.resolve)(this.workspacePath, modules[name].path);
        if ((0, apply_spec_1.hasApplySpec)(modulePath)) {
            return (0, materialize_1.resolveEffectiveModulePath)(name, modulePath, modules, this.workspacePath);
        }
        return this.getModuleProject(name).getModulePath();
    }
    parsePackageTarget(target) {
        let name;
        let toChange;
        if (!target) {
            const context = this.getContext();
            if (context === PackageContext.Module || context === PackageContext.ModuleInsideWorkspace) {
                name = this.getModuleName();
            }
            else if (context === PackageContext.Workspace) {
                const modules = this.getModuleMap();
                const moduleNames = Object.keys(modules);
                if (moduleNames.length === 0) {
                    throw new Error('No modules found in workspace');
                }
                name = null; // Indicates workspace-wide operation
            }
            else {
                throw new Error('Not in a PGPM workspace or module');
            }
        }
        else {
            const parsed = (0, target_utils_1.parseTarget)(target);
            name = parsed.packageName;
            toChange = parsed.toChange;
        }
        return { name, toChange };
    }
    async deploy(opts, target, recursive = true) {
        const log = new logger_1.Logger('deploy');
        const { name, toChange } = this.parsePackageTarget(target);
        if (recursive) {
            const modules = this.getModuleMap();
            let extensions;
            if (name === null) {
                // When name is null, deploy ALL modules in the workspace
                extensions = await this.resolveWorkspaceExtensionDependencies();
            }
            else {
                extensions = this.getModuleExtensionsFor(name);
            }
            const pgPool = (0, pg_cache_1.getPgPool)(opts.pg);
            const localModules = extensions.resolved.filter((m) => !extensions.external.includes(m));
            const roleMap = (0, resolve_install_1.roleMapFromRoles)(opts.db?.roles);
            const targetDescription = name === null ? 'all modules' : name;
            log.success(`🚀 Starting deployment to database ${opts.pg.database}...`);
            for (const extension of extensions.resolved) {
                try {
                    if (extensions.external.includes(extension)) {
                        const install = (0, resolve_install_1.findExtensionInstall)(extension, localModules, modules, this.workspacePath, { roleMap });
                        if (install) {
                            log.info(`📥 Installing external extension (declarative): ${extension}`);
                            for (const stmt of install.deploy) {
                                await pgPool.query(stmt);
                            }
                        }
                        else {
                            const msg = `CREATE EXTENSION IF NOT EXISTS "${extension}" CASCADE;`;
                            log.info(`📥 Installing external extension: ${extension}`);
                            await pgPool.query(msg);
                        }
                    }
                    else {
                        const modulePath = await (0, materialize_1.resolveEffectiveModulePath)(extension, (0, path_1.resolve)(this.workspacePath, modules[extension].path), modules, this.workspacePath);
                        log.info(`📂 Deploying local module: ${extension}`);
                        if (opts.deployment.fast || opts.deployment.bundled) {
                            // Fast strategy: one-shot execution plus a bulk-written
                            // pgpm_migrate ledger, from the module's verified bundle artifact
                            // when it has one and from `deploy/` when it does not.
                            const outcome = await (0, deploy_bundled_1.deployModuleFast)(modulePath, {
                                config: opts.pg,
                                logOnly: opts.deployment.logOnly,
                                useTransaction: opts.deployment.useTx,
                                hashMethod: opts.deployment.hashMethod
                            });
                            if ((0, deploy_bundled_1.isBundledDeployResult)(outcome)) {
                                continue;
                            }
                            log.info(`↩️ Fast deploy unavailable for ${extension} (${outcome}); using per-change path.`);
                        }
                        {
                            try {
                                const client = new client_1.PgpmMigrate(opts.pg);
                                // Only apply toChange to the target module, not its dependencies
                                const moduleToChange = extension === name ? toChange : undefined;
                                const result = await client.deploy({
                                    modulePath,
                                    toChange: moduleToChange,
                                    useTransaction: opts.deployment.useTx,
                                    logOnly: opts.deployment.logOnly,
                                    usePlan: opts.deployment.usePlan
                                });
                                if (result.failed) {
                                    throw types_1.errors.OPERATION_FAILED({ operation: 'Deployment', target: result.failed });
                                }
                            }
                            catch (deployError) {
                                log.error(`❌ Deployment failed for module ${extension}`);
                                console.error(deployError);
                                throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Deployment', module: extension });
                            }
                        }
                    }
                }
                catch (err) {
                    log.error(`🛑 Error during deployment: ${err instanceof Error ? err.message : err}`);
                    console.error(err);
                    throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Deployment', module: extension });
                }
            }
            log.success(`✅ Deployment complete for ${targetDescription}.`);
        }
        else {
            if (name === null) {
                throw types_1.errors.WORKSPACE_OPERATION_ERROR({ operation: 'deployment' });
            }
            const modulePath = await this.getEffectiveModulePathFor(name);
            if (!modulePath) {
                throw types_1.errors.PATH_NOT_FOUND({ path: name, type: 'module' });
            }
            const client = new client_1.PgpmMigrate(opts.pg);
            const result = await client.deploy({
                modulePath,
                toChange,
                useTransaction: opts.deployment?.useTx,
                logOnly: opts.deployment?.logOnly,
                usePlan: opts.deployment?.usePlan
            });
            if (result.failed) {
                throw types_1.errors.OPERATION_FAILED({ operation: 'Deployment', target: result.failed });
            }
            log.success(`✅ Single module deployment complete for ${name}.`);
        }
    }
    /**
     * Reverts database changes for modules. Unlike verify operations, revert operations
     * modify database state and must ensure dependent modules are reverted before their
     * dependencies to prevent database constraint violations.
     */
    async revert(opts, target, recursive = true) {
        const log = new logger_1.Logger('revert');
        const { name, toChange } = this.parsePackageTarget(target);
        if (recursive) {
            const modules = this.getModuleMap();
            // Mirror deploy logic: find all modules that depend on the target module
            let extensionsToRevert;
            if (name === null) {
                // When name is null, revert ALL deployed modules in the workspace
                extensionsToRevert = await this.resolveWorkspaceExtensionDependencies({
                    filterDeployed: true,
                    pgConfig: opts.pg
                });
            }
            else {
                // Always use workspace-wide resolution in recursive mode, but filter to deployed modules
                const workspaceExtensions = await this.resolveWorkspaceExtensionDependencies({
                    filterDeployed: true,
                    pgConfig: opts.pg
                });
                extensionsToRevert = truncateExtensionsToTarget(workspaceExtensions, name);
            }
            const pgPool = (0, pg_cache_1.getPgPool)(opts.pg);
            const targetDescription = name === null ? 'all modules' : name;
            log.success(`🧹 Starting revert process on database ${opts.pg.database}...`);
            const reversedExtensions = [...extensionsToRevert.resolved].reverse();
            for (const extension of reversedExtensions) {
                try {
                    if (extensionsToRevert.external.includes(extension)) {
                        const msg = `DROP EXTENSION IF EXISTS "${extension}" RESTRICT;`;
                        log.warn(`⚠️ Dropping external extension: ${extension}`);
                        try {
                            await pgPool.query(msg);
                        }
                        catch (err) {
                            if (err.code === '2BP01') {
                                log.warn(`⚠️ Cannot drop extension ${extension} due to dependencies, skipping`);
                            }
                            else {
                                throw err;
                            }
                        }
                    }
                    else {
                        const modulePath = await (0, materialize_1.resolveEffectiveModulePath)(extension, (0, path_1.resolve)(this.workspacePath, modules[extension].path), modules, this.workspacePath);
                        log.info(`📂 Reverting local module: ${extension}`);
                        try {
                            const client = new client_1.PgpmMigrate(opts.pg);
                            // Only apply toChange to the target module, not its dependencies
                            const moduleToChange = extension === name ? toChange : undefined;
                            const result = await client.revert({
                                modulePath,
                                toChange: moduleToChange,
                                useTransaction: opts.deployment.useTx
                            });
                            if (result.failed) {
                                throw types_1.errors.OPERATION_FAILED({ operation: 'Revert', target: result.failed });
                            }
                        }
                        catch (revertError) {
                            log.error(`❌ Revert failed for module ${extension}`);
                            throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Revert', module: extension });
                        }
                    }
                }
                catch (e) {
                    log.error(`🛑 Error during revert: ${e instanceof Error ? e.message : e}`);
                    console.error(e);
                    throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Revert', module: extension });
                }
            }
            log.success(`✅ Revert complete for ${targetDescription}.`);
        }
        else {
            if (name === null) {
                throw types_1.errors.WORKSPACE_OPERATION_ERROR({ operation: 'revert' });
            }
            const modulePath = await this.getEffectiveModulePathFor(name);
            if (!modulePath) {
                throw types_1.errors.PATH_NOT_FOUND({ path: name, type: 'module' });
            }
            const client = new client_1.PgpmMigrate(opts.pg);
            const result = await client.revert({
                modulePath,
                toChange,
                useTransaction: opts.deployment?.useTx
            });
            if (result.failed) {
                throw types_1.errors.OPERATION_FAILED({ operation: 'Revert', target: result.failed });
            }
            log.success(`✅ Single module revert complete for ${name}.`);
        }
    }
    async verify(opts, target, recursive = true) {
        const log = new logger_1.Logger('verify');
        const { name, toChange } = this.parsePackageTarget(target);
        if (recursive) {
            const modules = this.getModuleMap();
            let extensions;
            if (name === null) {
                // When name is null, verify ALL modules in the workspace
                extensions = await this.resolveWorkspaceExtensionDependencies();
            }
            else {
                extensions = this.getModuleExtensionsFor(name);
            }
            const pgPool = (0, pg_cache_1.getPgPool)(opts.pg);
            const targetDescription = name === null ? 'all modules' : name;
            log.success(`🔎 Verifying deployment of ${targetDescription} on database ${opts.pg.database}...`);
            for (const extension of extensions.resolved) {
                try {
                    if (extensions.external.includes(extension)) {
                        const query = `SELECT 1/count(*) FROM pg_available_extensions WHERE name = $1`;
                        log.info(`🔍 Verifying external extension: ${extension}`);
                        await pgPool.query(query, [extension]);
                    }
                    else {
                        const modulePath = await (0, materialize_1.resolveEffectiveModulePath)(extension, (0, path_1.resolve)(this.workspacePath, modules[extension].path), modules, this.workspacePath);
                        log.info(`📂 Verifying local module: ${extension}`);
                        try {
                            const client = new client_1.PgpmMigrate(opts.pg);
                            // Only apply toChange to the target module, not its dependencies
                            const moduleToChange = extension === name ? toChange : undefined;
                            const result = await client.verify({
                                modulePath,
                                toChange: moduleToChange
                            });
                            if (result.failed.length > 0) {
                                throw types_1.errors.OPERATION_FAILED({ operation: 'Verification', reason: `${result.failed.length} changes: ${result.failed.join(', ')}` });
                            }
                        }
                        catch (verifyError) {
                            log.error(`❌ Verification failed for module ${extension}`);
                            throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Verify', module: extension });
                        }
                    }
                }
                catch (e) {
                    log.error(`🛑 Error during verification: ${e instanceof Error ? e.message : e}`);
                    console.error(e);
                    throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Verify', module: extension });
                }
            }
            log.success(`✅ Verification complete for ${targetDescription}.`);
        }
        else {
            if (name === null) {
                throw types_1.errors.WORKSPACE_OPERATION_ERROR({ operation: 'verification' });
            }
            const modulePath = await this.getEffectiveModulePathFor(name);
            if (!modulePath) {
                throw types_1.errors.PATH_NOT_FOUND({ path: name, type: 'module' });
            }
            const client = new client_1.PgpmMigrate(opts.pg);
            const result = await client.verify({
                modulePath,
                toChange
            });
            if (result.failed.length > 0) {
                throw types_1.errors.OPERATION_FAILED({ operation: 'Verification', reason: `${result.failed.length} changes: ${result.failed.join(', ')}` });
            }
            log.success(`✅ Single module verification complete for ${name}.`);
        }
    }
    async removeFromPlan(toChange) {
        const log = new logger_1.Logger('remove');
        const modulePath = this.getModulePath();
        if (!modulePath) {
            throw types_1.errors.PATH_NOT_FOUND({ path: 'module path', type: 'module' });
        }
        const planPath = path_1.default.join(modulePath, 'pgpm.plan');
        const result = (0, parser_1.parsePlanFile)(planPath);
        if (result.errors.length > 0) {
            throw types_1.errors.PLAN_PARSE_ERROR({ planPath, errors: result.errors.map(e => e.message).join(', ') });
        }
        const plan = result.data;
        if (toChange.startsWith('@')) {
            const tagName = toChange.substring(1); // Remove the '@' prefix
            const tagToRemove = plan.tags.find(tag => tag.name === tagName);
            if (!tagToRemove) {
                throw types_1.errors.TAG_NOT_FOUND({ tag: toChange });
            }
            const tagChangeIndex = plan.changes.findIndex(c => c.name === tagToRemove.change);
            if (tagChangeIndex === -1) {
                throw types_1.errors.CHANGE_NOT_FOUND({ change: tagToRemove.change, plan: `for tag '${toChange}'` });
            }
            const changesToRemove = plan.changes.slice(tagChangeIndex);
            plan.changes = plan.changes.slice(0, tagChangeIndex);
            plan.tags = plan.tags.filter(tag => tag.name !== tagName && !changesToRemove.some(change => change.name === tag.change));
            for (const change of changesToRemove) {
                for (const scriptType of ['deploy', 'revert', 'verify']) {
                    const scriptPath = path_1.default.join(modulePath, scriptType, `${change.name}.sql`);
                    if (fs_1.default.existsSync(scriptPath)) {
                        fs_1.default.unlinkSync(scriptPath);
                        log.info(`Deleted ${scriptType}/${change.name}.sql`);
                    }
                }
            }
            // Write updated plan file
            (0, files_1.writePlanFile)(planPath, plan);
            log.success(`Removed tag ${toChange} and ${changesToRemove.length} subsequent changes from plan`);
            return;
        }
        const targetIndex = plan.changes.findIndex(c => c.name === toChange);
        if (targetIndex === -1) {
            throw types_1.errors.CHANGE_NOT_FOUND({ change: toChange });
        }
        const changesToRemove = plan.changes.slice(targetIndex);
        plan.changes = plan.changes.slice(0, targetIndex);
        plan.tags = plan.tags.filter(tag => !changesToRemove.some(change => change.name === tag.change));
        for (const change of changesToRemove) {
            for (const scriptType of ['deploy', 'revert', 'verify']) {
                const scriptPath = path_1.default.join(modulePath, scriptType, `${change.name}.sql`);
                if (fs_1.default.existsSync(scriptPath)) {
                    fs_1.default.unlinkSync(scriptPath);
                    log.info(`Deleted ${scriptType}/${change.name}.sql`);
                }
            }
        }
        // Write updated plan file
        (0, files_1.writePlanFile)(planPath, plan);
        log.success(`Removed ${changesToRemove.length} changes from plan`);
    }
    analyzeModule() {
        this.ensureModule();
        const info = this.getModuleInfo();
        const modPath = this.getModulePath();
        const issues = [];
        const exists = (p) => fs_1.default.existsSync(p);
        const read = (p) => (exists(p) ? fs_1.default.readFileSync(p, 'utf8') : undefined);
        const planPath = path_1.default.join(modPath, 'pgpm.plan');
        if (!exists(planPath))
            issues.push({ code: 'missing_plan', message: 'Missing pgpm.plan', file: planPath });
        const pkgJsonPath = path_1.default.join(modPath, 'package.json');
        if (!exists(pkgJsonPath))
            issues.push({ code: 'missing_package_json', message: 'Missing package.json', file: pkgJsonPath });
        const makefilePath = info.Makefile;
        if (!exists(makefilePath))
            issues.push({ code: 'missing_makefile', message: 'Missing Makefile', file: makefilePath });
        const controlPath = info.controlFile;
        if (!exists(controlPath))
            issues.push({ code: 'missing_control', message: 'Missing control file', file: controlPath });
        const sqlCombined = info.sqlFile ? path_1.default.join(modPath, info.sqlFile) : path_1.default.join(modPath, 'sql', `${info.extname}--${info.version}.sql`);
        if (!exists(sqlCombined))
            issues.push({ code: 'missing_sql', message: 'Missing combined sql file', file: sqlCombined });
        const deployDir = path_1.default.join(modPath, 'deploy');
        if (!exists(deployDir))
            issues.push({ code: 'missing_deploy_dir', message: 'Missing deploy directory', file: deployDir });
        const revertDir = path_1.default.join(modPath, 'revert');
        if (!exists(revertDir))
            issues.push({ code: 'missing_revert_dir', message: 'Missing revert directory', file: revertDir });
        const verifyDir = path_1.default.join(modPath, 'verify');
        if (!exists(verifyDir))
            issues.push({ code: 'missing_verify_dir', message: 'Missing verify directory', file: verifyDir });
        if (exists(planPath)) {
            try {
                const parsed = (0, parser_1.parsePlanFile)(planPath);
                const pkgName = parsed.data?.package;
                if (!pkgName)
                    issues.push({ code: 'plan_missing_project', message: '%project missing', file: planPath });
                if (pkgName && pkgName !== info.extname)
                    issues.push({ code: 'plan_project_mismatch', message: `pgpm.plan %project ${pkgName} != ${info.extname}`, file: planPath });
                const uri = parsed.data?.uri;
                if (uri && uri !== info.extname)
                    issues.push({ code: 'plan_uri_mismatch', message: `pgpm.plan %uri ${uri} != ${info.extname}`, file: planPath });
            }
            catch (e) {
                issues.push({ code: 'plan_parse_error', message: e?.message || 'Plan parse error', file: planPath });
            }
        }
        if (exists(makefilePath)) {
            const mf = read(makefilePath) || '';
            const extMatch = mf.match(/^EXTENSION\s*=\s*(.+)$/m);
            const dataMatch = mf.match(/^DATA\s*=\s*sql\/(.+)\.sql$/m);
            if (!extMatch)
                issues.push({ code: 'makefile_missing_extension', message: 'Makefile missing EXTENSION', file: makefilePath });
            if (!dataMatch)
                issues.push({ code: 'makefile_missing_data', message: 'Makefile missing DATA', file: makefilePath });
            if (extMatch && extMatch[1].trim() !== info.extname)
                issues.push({ code: 'makefile_extension_mismatch', message: `Makefile EXTENSION ${extMatch[1].trim()} != ${info.extname}`, file: makefilePath });
            const expectedData = `${info.extname}--${info.version}`;
            if (dataMatch && dataMatch[1].trim() !== expectedData)
                issues.push({ code: 'makefile_data_mismatch', message: `Makefile DATA sql/${dataMatch[1].trim()}.sql != sql/${expectedData}.sql`, file: makefilePath });
        }
        if (exists(controlPath)) {
            const base = path_1.default.basename(controlPath);
            const expected = `${info.extname}.control`;
            if (base !== expected)
                issues.push({ code: 'control_filename_mismatch', message: `Control filename ${base} != ${expected}`, file: controlPath });
        }
        const reported = issues.map(issue => ({ ...issue, file: (0, glob_1.toPosixPath)(issue.file) }));
        return { ok: reported.length === 0, name: info.extname, path: (0, glob_1.toPosixPath)(modPath), issues: reported };
    }
    renameModule(newName, opts) {
        this.ensureModule();
        const info = this.getModuleInfo();
        const modPath = this.getModulePath();
        const changed = [];
        const warnings = [];
        const dry = !!opts?.dryRun;
        const valid = /^[a-z][a-z0-9_]*$/;
        if (!valid.test(newName)) {
            throw types_1.errors.INVALID_NAME({ name: newName, type: 'module', rules: 'lowercase letters, digits, underscores; must start with letter' });
        }
        const planPath = path_1.default.join(modPath, 'pgpm.plan');
        if (fs_1.default.existsSync(planPath)) {
            try {
                const parsed = (0, parser_1.parsePlanFile)(planPath);
                if (parsed.data) {
                    parsed.data.package = newName;
                    parsed.data.uri = newName;
                    if (!dry)
                        (0, files_1.writePlanFile)(planPath, parsed.data);
                    changed.push(planPath);
                }
            }
            catch (e) {
                warnings.push(`failed to update pgpm.plan`);
            }
        }
        else {
            warnings.push('missing pgpm.plan');
        }
        const pkgJsonPath = path_1.default.join(modPath, 'package.json');
        if (fs_1.default.existsSync(pkgJsonPath) && opts?.syncPackageJsonName) {
            try {
                const pkg = JSON.parse(fs_1.default.readFileSync(pkgJsonPath, 'utf8'));
                const oldName = pkg.name;
                if (oldName) {
                    if (oldName.startsWith('@')) {
                        const parts = oldName.split('/');
                        if (parts.length === 2)
                            pkg.name = `${parts[0]}/${newName}`;
                        else
                            pkg.name = newName;
                    }
                    else {
                        pkg.name = newName;
                    }
                }
                else {
                    pkg.name = newName;
                }
                if (!dry)
                    fs_1.default.writeFileSync(pkgJsonPath, JSON.stringify(pkg, null, 2));
                changed.push(pkgJsonPath);
            }
            catch {
                warnings.push('failed to update package.json name');
            }
        }
        const oldControl = info.controlFile;
        const newControl = path_1.default.join(modPath, `${newName}.control`);
        const version = info.version;
        const requires = (() => {
            try {
                const c = fs_1.default.readFileSync(oldControl, 'utf8');
                const line = c.split('\n').find(l => /^requires/.test(l));
                if (!line)
                    return [];
                return line.split('=')[1].split("'")[1].split(',').map(s => s.trim()).filter(Boolean);
            }
            catch {
                return [];
            }
        })();
        if (fs_1.default.existsSync(oldControl)) {
            if (!dry) {
                const content = (0, writer_1.generateControlFileContent)({ name: newName, version, requires });
                fs_1.default.writeFileSync(newControl, content);
                if (oldControl !== newControl && fs_1.default.existsSync(oldControl))
                    fs_1.default.rmSync(oldControl);
            }
            changed.push(newControl);
        }
        else {
            warnings.push('missing control file');
        }
        const makefilePath = info.Makefile;
        if (fs_1.default.existsSync(makefilePath)) {
            if (!dry)
                (0, writer_1.writeExtensionMakefile)(makefilePath, newName, version);
            changed.push(makefilePath);
        }
        else {
            warnings.push('missing Makefile');
        }
        const oldSql = path_1.default.join(modPath, 'sql', `${info.extname}--${version}.sql`);
        const newSql = path_1.default.join(modPath, 'sql', `${newName}--${version}.sql`);
        if (fs_1.default.existsSync(oldSql)) {
            if (!dry) {
                if (oldSql !== newSql) {
                    fs_1.default.mkdirSync(path_1.default.dirname(newSql), { recursive: true });
                    fs_1.default.renameSync(oldSql, newSql);
                }
            }
            changed.push(newSql);
        }
        else {
            if (fs_1.default.existsSync(newSql)) {
                changed.push(newSql);
            }
            else {
                warnings.push('missing combined sql file');
            }
        }
        this.clearCache();
        return { changed, warnings };
    }
}
exports.PgpmPackage = PgpmPackage;
