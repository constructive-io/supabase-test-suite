import { Chunk, RebundleModuleOptions, RebundleModuleResult } from './types';
export declare const SCRIPT_DIRS: readonly ["deploy", "revert", "verify"];
export type ScriptDir = (typeof SCRIPT_DIRS)[number];
/**
 * Merge one chunk's member scripts (in the correct order per direction) into a
 * single deparsed, single-transaction migration string. Shared by the
 * single-module (`rebundleModule`) and workspace (`rebundleWorkspace`) emitters.
 */
export declare function mergeChunkScript(sourceDir: string, chunk: Chunk, scriptType: ScriptDir, opts?: {
    pretty?: boolean;
    functionDelimiter?: string;
}): Promise<string>;
/**
 * Materialize a rebundled module: merge each chunk's member scripts into a
 * single deparsed migration (reusing `packageModule`'s merge engine), write the
 * chunk-quotient plan, and verify the result is byte-identical when packaged.
 *
 * Reuses existing plumbing throughout — `rebundlePlan` for the chunk model,
 * `mergeSqlStatements`/`packageModule` for statement merging and the gate,
 * `generatePlanContent` for the chunk plan, and the source control/Makefile
 * verbatim.
 */
export declare function rebundleModule(sourceDir: string, options: RebundleModuleOptions): Promise<RebundleModuleResult>;
