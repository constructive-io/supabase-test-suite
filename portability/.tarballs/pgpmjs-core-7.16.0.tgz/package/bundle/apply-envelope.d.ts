import { BundleEnvelope, EnvelopeIssue, EnvelopePartKind } from '@pgpmjs/bundle';
import { ApplyBundleOptions, ApplyBundlePreview, ApplyBundleResult, PreviewBundleApplyOptions } from './apply';
/** One data/fixtures part in the envelope's replay order. */
export interface EnvelopePartRef {
    kind: Exclude<EnvelopePartKind, 'schema'>;
    name: string;
}
/** Pre-flight analysis of an envelope apply, computed without touching the database. */
export interface EnvelopeApplyPreview {
    name: string;
    version: string;
    envelopeDigest: string;
    /** Digest/inventory/tamper problems from `verifyEnvelope`. */
    envelopeIssues: EnvelopeIssue[];
    /** The schema bundle's own pre-flight (integrity, namespace, order, rollback). */
    schema: ApplyBundlePreview;
    /** Data then fixtures parts, in manifest replay order. */
    partOrder: EnvelopePartRef[];
    /**
     * How to undo this apply: part reverts in reverse replay order (parts
     * without a revert script are flagged), then the schema rollback plan.
     */
    rollbackPlan: {
        parts: (EnvelopePartRef & {
            hasRevert: boolean;
        })[];
        schema: string[];
    };
}
/**
 * Analyze an envelope apply without executing it: verify the envelope's
 * digest chain (including the schema bundle), run the schema pre-flight, and
 * derive replay order + rollback plan. Pure — no database, no disk.
 */
export declare function previewEnvelopeApply(envelope: BundleEnvelope, options?: PreviewBundleApplyOptions): EnvelopeApplyPreview;
/** Context handed to {@link EnvelopeApplyOptions.transformPartSql}. */
export interface PartSqlContext {
    kind: Exclude<EnvelopePartKind, 'schema'>;
    name: string;
    script: 'deploy' | 'verify';
}
/** Status/rollback metadata for one replayed part. */
export interface EnvelopePartResult {
    kind: Exclude<EnvelopePartKind, 'schema'>;
    name: string;
    /** True when the part's deploy SQL ran against the database. */
    executed: boolean;
    /** Set only when `verifyParts` is enabled and the part has a verify script. */
    verified?: boolean;
    durationMs: number;
}
export interface EnvelopeApplyOptions extends ApplyBundleOptions {
    /** Run each part's verify script after its deploy. Default false. */
    verifyParts?: boolean;
    /**
     * Seam for pre-apply rewriting of part SQL (e.g. deterministic ID remap).
     * Applied to deploy and verify scripts just before execution; identity when
     * omitted. Never sees schema-bundle SQL.
     */
    transformPartSql?: (sql: string, ctx: PartSqlContext) => string;
}
/** Explicit outcome of an {@link applyEnvelope} call. */
export interface EnvelopeApplyResult {
    preview: EnvelopeApplyPreview;
    dryRun: boolean;
    /** True when anything ran against the database. */
    executed: boolean;
    /** The schema half's own result (undefined on dry-run). */
    schema?: ApplyBundleResult;
    /** Per-part status metadata, in replay order (parts reached so far). */
    parts: EnvelopePartResult[];
    durationMs: number;
    timedOut: boolean;
}
/** Thrown when an envelope apply is refused pre-flight or fails mid-replay. */
export declare class EnvelopeApplyError extends Error {
    readonly preview: EnvelopeApplyPreview;
    /** Parts completed before the failure (for status recording). */
    readonly parts: EnvelopePartResult[];
    readonly timedOut: boolean;
    constructor(message: string, preview: EnvelopeApplyPreview, 
    /** Parts completed before the failure (for status recording). */
    parts?: EnvelopePartResult[], timedOut?: boolean);
}
/**
 * Apply a {@link BundleEnvelope} into a target database: the generic
 * `applyMigrationBundle` primitive.
 *
 * Order of operations:
 * 1. Pre-flight: {@link previewEnvelopeApply} — refuse on any envelope digest
 *    issue unless `allowUnverified` (schema-bundle integrity and namespace
 *    gating are then enforced again by {@link applyBundle}).
 * 2. Schema: {@link applyBundle} on `envelope.schema` (atomic transaction,
 *    timeout, dry-run all handled there).
 * 3. Parts: replay each data then fixtures part's deploy SQL in manifest
 *    order, inside a single transaction so a failing part rolls back all part
 *    data (the schema stays applied; the preview's rollback plan describes the
 *    full undo). Optional per-part verify. The `transformPartSql` seam runs
 *    just before execution.
 */
export declare function applyEnvelope(envelope: BundleEnvelope, options: EnvelopeApplyOptions): Promise<EnvelopeApplyResult>;
