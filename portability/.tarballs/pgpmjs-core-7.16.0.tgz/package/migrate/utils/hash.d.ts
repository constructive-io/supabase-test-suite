import { hashString } from '@pgpmjs/ast';
export { hashString };
/**
 * Generate SHA256 hash of a file's contents
 */
export declare function hashFile(filePath: string): Promise<string>;
/**
 * Generate SHA256 hash of a SQL file's parsed and cleaned AST
 */
export declare function hashSqlFile(filePath: string): Promise<string>;
