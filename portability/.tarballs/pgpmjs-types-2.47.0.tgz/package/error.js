"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PgpmError = void 0;
class PgpmError extends Error {
    code;
    context;
    httpCode;
    constructor(code, message, context, httpCode) {
        super(message);
        this.name = 'PgpmError';
        this.code = code;
        this.context = context;
        this.httpCode = httpCode;
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, PgpmError);
        }
    }
    toString() {
        return `[${this.code}] ${this.message}`;
    }
}
exports.PgpmError = PgpmError;
