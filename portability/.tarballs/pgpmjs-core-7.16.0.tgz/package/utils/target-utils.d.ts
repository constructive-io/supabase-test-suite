export interface ParsedTarget {
    packageName: string;
    toChange?: string;
}
export declare function parseTarget(target: string): ParsedTarget;
