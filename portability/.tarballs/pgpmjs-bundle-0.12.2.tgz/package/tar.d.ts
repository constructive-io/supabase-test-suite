/**
 * Pack a single named file into a gzipped tarball. Deterministic: fixed mode,
 * zero mtime/uid/gid, so identical content always yields identical bytes.
 */
export declare function packSingleFileTarGz(name: string, content: string): Buffer;
/** One entry read back out of a single-file tarball. */
export interface TarEntry {
    name: string;
    content: string;
}
/**
 * Read the first regular-file entry out of a gzipped tarball, in memory.
 *
 * @throws when the archive is empty or its header is not a readable ustar block.
 */
export declare function unpackSingleFileTarGz(archive: Buffer): TarEntry;
