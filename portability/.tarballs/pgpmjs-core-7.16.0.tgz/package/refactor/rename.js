"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renameInPlanContent = void 0;
exports.validateRenames = validateRenames;
exports.renameChanges = renameChanges;
exports.deriveRenamesFromSchemaMapping = deriveRenamesFromSchemaMapping;
const fs_1 = require("fs");
const path_1 = require("path");
const parser_1 = require("@pgpmjs/ast/files/plan/parser");
const header_1 = require("@pgpmjs/ast/files/sql/header");
const plan_rename_1 = require("@pgpmjs/ast/plan-rename");
Object.defineProperty(exports, "renameInPlanContent", { enumerable: true, get: function () { return plan_rename_1.renameInPlanContent; } });
const SCRIPT_DIRS = ['deploy', 'revert', 'verify'];
function escapeRe(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function findSqlFiles(dir) {
    const files = [];
    if (!(0, fs_1.existsSync)(dir))
        return files;
    const entries = (0, fs_1.readdirSync)(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
        const fullPath = (0, path_1.join)(dir, entry.name);
        if (entry.isDirectory()) {
            files.push(...findSqlFiles(fullPath));
        }
        else if (entry.isFile() && entry.name.endsWith('.sql')) {
            files.push(fullPath);
        }
    }
    return files;
}
function removeEmptyDirs(dir, stopAt) {
    let current = dir;
    while (current !== stopAt && current.startsWith(stopAt)) {
        if (!(0, fs_1.existsSync)(current) || (0, fs_1.readdirSync)(current).length > 0)
            return;
        (0, fs_1.rmdirSync)(current);
        current = (0, path_1.dirname)(current);
    }
}
/**
 * Validate a rename map against a module directory: every source change must
 * exist in the plan, no target may collide with an existing change, and no
 * two sources may map to the same target.
 *
 * @throws on any violation.
 */
function validateRenames(moduleDir, renames) {
    const planPath = (0, path_1.join)(moduleDir, 'pgpm.plan');
    const plan = (0, parser_1.parsePlanFileSimple)(planPath);
    const changeNames = new Set(plan.changes.map(c => c.name));
    const targets = new Set();
    for (const [from, to] of renames) {
        if (from === to) {
            throw new Error(`Rename maps change to itself: ${from}`);
        }
        if (!changeNames.has(from)) {
            throw new Error(`Cannot rename unknown change: ${from}`);
        }
        if (changeNames.has(to) && !renames.has(to)) {
            throw new Error(`Rename target already exists in plan: ${to}`);
        }
        if (targets.has(to)) {
            throw new Error(`Multiple changes rename to the same target: ${to}`);
        }
        targets.add(to);
    }
}
/**
 * Atomically rename/move changes within a pgpm module: the coupled 4-way
 * rewrite of (1) deploy/revert/verify script files on disk, (2) the moved
 * scripts' own header identity, (3) `-- requires:` headers in every script
 * that references a renamed change, and (4) the pgpm.plan.
 *
 * SQL statement bodies are NOT touched: schema-name rewrites inside SQL are a
 * separate AST-level concern for callers to compose (e.g. transform passes).
 */
function renameChanges(moduleDir, renames, options = {}) {
    const dryRun = options.dryRun ?? false;
    const result = {
        filesMoved: [],
        headersRewritten: [],
        planRewritten: false
    };
    if (dryRun)
        result.dryRunReport = [];
    if (renames.size === 0)
        return result;
    validateRenames(moduleDir, renames);
    // 1. Move script files
    for (const scriptDir of SCRIPT_DIRS) {
        for (const [from, to] of renames) {
            const oldPath = (0, path_1.join)(moduleDir, scriptDir, `${from}.sql`);
            if (!(0, fs_1.existsSync)(oldPath) || !(0, fs_1.statSync)(oldPath).isFile())
                continue;
            const newPath = (0, path_1.join)(moduleDir, scriptDir, `${to}.sql`);
            if ((0, fs_1.existsSync)(newPath)) {
                throw new Error(`Rename target file already exists: ${(0, path_1.relative)(moduleDir, newPath)}`);
            }
            if (dryRun) {
                result.dryRunReport.push(`Would move: ${(0, path_1.relative)(moduleDir, oldPath)} -> ${(0, path_1.relative)(moduleDir, newPath)}`);
            }
            else {
                (0, fs_1.mkdirSync)((0, path_1.dirname)(newPath), { recursive: true });
                (0, fs_1.renameSync)(oldPath, newPath);
                removeEmptyDirs((0, path_1.dirname)(oldPath), (0, path_1.join)(moduleDir, scriptDir));
            }
            result.filesMoved.push({
                from: [scriptDir, `${from}.sql`].join(path_1.sep),
                to: [scriptDir, `${to}.sql`].join(path_1.sep)
            });
        }
    }
    // 2 + 3. Rewrite headers in every script (identity of moved files,
    // requires of dependents)
    for (const scriptDir of SCRIPT_DIRS) {
        const dir = (0, path_1.join)(moduleDir, scriptDir);
        for (const file of findSqlFiles(dir)) {
            const content = (0, fs_1.readFileSync)(file, 'utf-8');
            const script = (0, header_1.parsePgpmHeader)(content);
            const count = (0, header_1.renameInHeader)(script, renames);
            if (count === 0)
                continue;
            const rewritten = (0, header_1.writePgpmScript)(script);
            if (rewritten === content)
                continue;
            if (dryRun) {
                result.dryRunReport.push(`Would rewrite header: ${(0, path_1.relative)(moduleDir, file)}`);
            }
            else {
                (0, fs_1.writeFileSync)(file, rewritten);
            }
            result.headersRewritten.push((0, path_1.relative)(moduleDir, file));
        }
    }
    // In dry-run mode files were not moved, so dependents' headers are found at
    // their original paths above; the moved files' own headers are still
    // reported through the same scan.
    // 4. Rewrite pgpm.plan
    const planPath = (0, path_1.join)(moduleDir, 'pgpm.plan');
    const planContent = (0, fs_1.readFileSync)(planPath, 'utf-8');
    const newPlanContent = (0, plan_rename_1.renameInPlanContent)(planContent, renames);
    if (newPlanContent !== planContent) {
        if (dryRun) {
            result.dryRunReport.push('Would rewrite: pgpm.plan');
        }
        else {
            (0, fs_1.writeFileSync)(planPath, newPlanContent);
        }
        result.planRewritten = true;
    }
    return result;
}
/**
 * Derive a change rename map from a schema mapping (old schema name -> new
 * schema name) by rewriting the `schemas/<name>/` path segment of every plan
 * change that lives under a renamed schema.
 *
 * This is the module-level counterpart of directory-based schema renames:
 * `schemas/my-app/tables/users` with mapping `my-app -> my_app` yields
 * `schemas/my_app/tables/users`.
 */
function deriveRenamesFromSchemaMapping(moduleDir, schemaMapping) {
    const renames = new Map();
    const planPath = (0, path_1.join)(moduleDir, 'pgpm.plan');
    const plan = (0, parser_1.parsePlanFileSimple)(planPath);
    const schemas = Array.from(schemaMapping.keys()).sort((a, b) => b.length - a.length);
    for (const change of plan.changes) {
        let renamed = change.name;
        for (const schema of schemas) {
            const to = schemaMapping.get(schema);
            if (!to || to === schema)
                continue;
            const re = new RegExp(`(^|/)(schemas/)${escapeRe(schema)}(/|$)`, 'g');
            renamed = renamed.replace(re, `$1$2${to}$3`);
        }
        if (renamed !== change.name) {
            renames.set(change.name, renamed);
        }
    }
    return renames;
}
