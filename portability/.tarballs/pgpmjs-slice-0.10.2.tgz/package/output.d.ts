import { SliceResult } from './types';
/**
 * Options for writing sliced packages to disk
 */
export interface WriteSliceOptions {
    /** Base output directory */
    outputDir: string;
    /** Whether to overwrite existing packages */
    overwrite?: boolean;
    /** Whether to copy SQL files from source */
    copySourceFiles?: boolean;
    /** Source directory containing deploy/revert/verify folders */
    sourceDir?: string;
}
/**
 * Write sliced packages to disk
 */
export declare function writeSliceResult(result: SliceResult, options: WriteSliceOptions): void;
/**
 * Generate a dry-run report of what would be created
 */
export declare function generateDryRunReport(result: SliceResult): string;
