"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENVELOPE_MANIFEST_FILE_NAME = exports.ENVELOPE_FILE_NAME = exports.ENVELOPE_FORMAT_VERSION = void 0;
exports.computePartDigest = computePartDigest;
exports.computeEnvelopeDigest = computeEnvelopeDigest;
exports.createEnvelope = createEnvelope;
exports.verifyEnvelope = verifyEnvelope;
exports.writeEnvelopeFile = writeEnvelopeFile;
exports.readEnvelopeFile = readEnvelopeFile;
exports.materializeEnvelope = materializeEnvelope;
exports.envelopeFromDirectory = envelopeFromDirectory;
/**
 * Bundle envelope: the versioned, shippable artifact container that wraps a
 * schema {@link MigrationBundle} together with data and fixture SQL parts —
 * the artifact `exportMigrationBundle` emits and snapshot/fork/apply consume.
 *
 * The envelope layer is deliberately payload-agnostic about how data/fixture
 * SQL is produced: callers build the scripts (e.g. with the `@pgpmjs/export`
 * data-dump builders) and hand in the text. This keeps the dependency
 * direction intact (`@pgpmjs/export` depends on core, which depends on this
 * package) while every byte remains digest-covered.
 */
const fs_1 = require("fs");
const path_1 = require("path");
const ast_1 = require("@pgpmjs/ast");
const io_1 = require("./io");
const verify_1 = require("./verify");
/** Current envelope format version. Bumped only on breaking artifact changes. */
exports.ENVELOPE_FORMAT_VERSION = '1';
/** Default file name for a serialized envelope artifact. */
exports.ENVELOPE_FILE_NAME = 'pgpm-envelope.json';
/** Manifest file name inside a materialized envelope directory. */
exports.ENVELOPE_MANIFEST_FILE_NAME = 'envelope.json';
/**
 * Digest for one data/fixtures part: its name plus the digests of its scripts
 * in fixed deploy/revert/verify order; a missing script contributes an empty
 * slot so presence/absence changes the digest.
 */
function computePartDigest(name, scripts) {
    return (0, ast_1.hashString)([
        name,
        (0, ast_1.hashString)(scripts.deploy),
        scripts.revert != null ? (0, ast_1.hashString)(scripts.revert) : '',
        scripts.verify != null ? (0, ast_1.hashString)(scripts.verify) : ''
    ].join('\n'));
}
/**
 * Top-level envelope digest: identity + the ordered part digests.
 */
function computeEnvelopeDigest(name, version, partDigests) {
    return (0, ast_1.hashString)([name, version, ...partDigests].join('\n'));
}
const toPart = (input) => ({
    name: input.name,
    deploy: input.deploy,
    revert: input.revert ?? null,
    verify: input.verify ?? null,
    digest: computePartDigest(input.name, input)
});
/**
 * Build a content-addressed {@link BundleEnvelope}. Pure and deterministic:
 * no disk I/O, no clock, no version noise in the digest. The schema part's
 * digest is the bundle's own manifest digest, so the envelope Merkle chain
 * extends down through every change and script.
 */
function createEnvelope(options) {
    const name = options.name ?? options.schema.manifest.name;
    const data = (options.data ?? []).map(toPart);
    const fixtures = (options.fixtures ?? []).map(toPart);
    const parts = [
        { kind: 'schema', name, digest: options.schema.manifest.digest },
        ...data.map(p => ({ kind: 'data', name: p.name, digest: p.digest })),
        ...fixtures.map(p => ({ kind: 'fixtures', name: p.name, digest: p.digest }))
    ];
    const manifest = {
        formatVersion: exports.ENVELOPE_FORMAT_VERSION,
        name,
        version: options.version,
        createdWith: options.createdWith ?? '@pgpmjs/bundle',
        parts,
        digest: computeEnvelopeDigest(name, options.version, parts.map(p => p.digest))
    };
    if (options.provenance)
        manifest.provenance = options.provenance;
    return { manifest, schema: options.schema, data, fixtures };
}
/**
 * Recompute every digest in an envelope and confirm it matches the recorded
 * values: each part digest, the inventory, the top-level digest, and (via
 * {@link verifyBundle}) the full schema bundle chain. Read-only; returns the
 * issues rather than throwing.
 */
function verifyEnvelope(envelope) {
    const issues = [];
    const { manifest, schema, data, fixtures } = envelope;
    const expectParts = [
        { kind: 'schema', name: manifest.name, digest: schema.manifest.digest },
        ...data.map(p => ({ kind: 'data', name: p.name, digest: computePartDigest(p.name, p) })),
        ...fixtures.map(p => ({ kind: 'fixtures', name: p.name, digest: computePartDigest(p.name, p) }))
    ];
    for (const part of [...data, ...fixtures]) {
        const recomputed = computePartDigest(part.name, part);
        if (recomputed !== part.digest) {
            issues.push({
                kind: 'part-digest',
                part: part.name,
                message: `part ${part.name}: recorded digest ${part.digest} != recomputed ${recomputed}`
            });
        }
    }
    const inventory = manifest.parts.map(p => `${p.kind}:${p.name}:${p.digest}`).join('\n');
    const expected = expectParts.map(p => `${p.kind}:${p.name}:${p.digest}`).join('\n');
    if (inventory !== expected) {
        issues.push({
            kind: 'part-inventory',
            message: 'manifest.parts does not match the envelope contents'
        });
    }
    const digest = computeEnvelopeDigest(manifest.name, manifest.version, expectParts.map(p => p.digest));
    if (digest !== manifest.digest) {
        issues.push({
            kind: 'envelope-digest',
            message: `recorded envelope digest ${manifest.digest} != recomputed ${digest}`
        });
    }
    const schemaIssues = (0, verify_1.verifyBundle)(schema);
    if (schemaIssues.length > 0) {
        issues.push({
            kind: 'schema-bundle',
            message: `schema bundle failed verification with ${schemaIssues.length} issue(s)`
        });
    }
    return { issues, schemaIssues };
}
/**
 * Serialize an envelope to a single JSON artifact file (stable 2-space formatting).
 */
function writeEnvelopeFile(envelope, filePath) {
    (0, fs_1.mkdirSync)((0, path_1.dirname)(filePath), { recursive: true });
    (0, fs_1.writeFileSync)(filePath, JSON.stringify(envelope, null, 2) + '\n');
}
/**
 * Read an envelope artifact JSON file back into memory.
 */
function readEnvelopeFile(filePath) {
    return JSON.parse((0, fs_1.readFileSync)(filePath, 'utf-8'));
}
const writePartDir = (part, dir) => {
    (0, fs_1.mkdirSync)(dir, { recursive: true });
    (0, fs_1.writeFileSync)((0, path_1.join)(dir, 'deploy.sql'), part.deploy);
    if (part.revert !== null)
        (0, fs_1.writeFileSync)((0, path_1.join)(dir, 'revert.sql'), part.revert);
    if (part.verify !== null)
        (0, fs_1.writeFileSync)((0, path_1.join)(dir, 'verify.sql'), part.verify);
};
/**
 * Materialize an envelope as a deterministic directory layout — trivially
 * tarred/shipped by callers:
 *
 * ```
 * envelope.json                 # manifest only
 * schema/pgpm-bundle.json       # the schema MigrationBundle artifact
 * data/<name>/{deploy,revert,verify}.sql
 * fixtures/<name>/{deploy,revert,verify}.sql
 * ```
 */
function materializeEnvelope(envelope, outDir) {
    (0, fs_1.mkdirSync)(outDir, { recursive: true });
    (0, fs_1.writeFileSync)((0, path_1.join)(outDir, exports.ENVELOPE_MANIFEST_FILE_NAME), JSON.stringify(envelope.manifest, null, 2) + '\n');
    (0, io_1.writeBundleFile)(envelope.schema, (0, path_1.join)(outDir, 'schema', 'pgpm-bundle.json'));
    for (const part of envelope.data)
        writePartDir(part, (0, path_1.join)(outDir, 'data', part.name));
    for (const part of envelope.fixtures)
        writePartDir(part, (0, path_1.join)(outDir, 'fixtures', part.name));
}
const readOptional = (path) => {
    try {
        return (0, fs_1.readFileSync)(path, 'utf-8');
    }
    catch {
        return null;
    }
};
const readPartsDir = (dir, order) => {
    let names;
    try {
        names = (0, fs_1.readdirSync)(dir);
    }
    catch {
        return [];
    }
    const ordered = order.filter(n => names.includes(n));
    return ordered.map(name => {
        const partDir = (0, path_1.join)(dir, name);
        const deploy = (0, fs_1.readFileSync)((0, path_1.join)(partDir, 'deploy.sql'), 'utf-8');
        const revert = readOptional((0, path_1.join)(partDir, 'revert.sql'));
        const verify = readOptional((0, path_1.join)(partDir, 'verify.sql'));
        return {
            name,
            deploy,
            revert,
            verify,
            digest: computePartDigest(name, { deploy, revert, verify })
        };
    });
};
/**
 * Read a materialized envelope directory back into memory — the inverse of
 * {@link materializeEnvelope}. Part order is restored from the manifest
 * inventory; run {@link verifyEnvelope} afterwards to prove integrity.
 */
function envelopeFromDirectory(dir) {
    const manifest = JSON.parse((0, fs_1.readFileSync)((0, path_1.join)(dir, exports.ENVELOPE_MANIFEST_FILE_NAME), 'utf-8'));
    const schema = (0, io_1.readBundleFile)((0, path_1.join)(dir, 'schema', 'pgpm-bundle.json'));
    const dataOrder = manifest.parts.filter(p => p.kind === 'data').map(p => p.name);
    const fixturesOrder = manifest.parts.filter(p => p.kind === 'fixtures').map(p => p.name);
    return {
        manifest,
        schema,
        data: readPartsDir((0, path_1.join)(dir, 'data'), dataOrder),
        fixtures: readPartsDir((0, path_1.join)(dir, 'fixtures'), fixturesOrder)
    };
}
