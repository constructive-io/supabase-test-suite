import { PgConfig } from 'pg-env';
export interface EventLogEntry {
    eventType: 'deploy' | 'revert' | 'verify';
    changeName: string;
    package: string;
    errorMessage?: string;
    errorCode?: string;
}
export declare class EventLogger {
    private pool;
    constructor(config: PgConfig);
    logEvent(entry: EventLogEntry): Promise<void>;
}
