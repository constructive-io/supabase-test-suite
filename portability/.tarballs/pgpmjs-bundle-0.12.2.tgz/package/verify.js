"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyBundle = verifyBundle;
const ast_1 = require("@pgpmjs/ast");
const traverse_1 = require("@pgpmjs/traverse");
const create_1 = require("./create");
/**
 * Recompute every digest in a bundle and confirm it matches the recorded values.
 *
 * This is the integrity gate `applyMigrationBundle` / `transpileMigrationBundle`
 * run before trusting a transported artifact: it proves the SQL bytes, per-change
 * digests, deploy order, and top-level digest are internally consistent. Read-only;
 * returns the issues rather than throwing.
 */
function verifyBundle(bundle) {
    const issues = [];
    if (bundle.changes.length !== bundle.manifest.changeCount) {
        issues.push({
            kind: 'change-count',
            message: `manifest.changeCount=${bundle.manifest.changeCount} but ${bundle.changes.length} changes present`
        });
    }
    const order = bundle.changes.map(c => c.name);
    if (order.join('\n') !== bundle.manifest.deployOrder.join('\n')) {
        issues.push({
            kind: 'order-mismatch',
            message: 'changes order does not match manifest.deployOrder'
        });
    }
    for (const change of bundle.changes) {
        (0, traverse_1.forEachScript)(change, script => {
            if ((0, ast_1.hashString)(script.sql) !== script.digest) {
                issues.push({
                    kind: 'script-digest',
                    change: change.name,
                    script: script.kind,
                    message: 'script digest does not match its sql'
                });
            }
        });
        if (change.exec && (0, ast_1.hashString)(change.exec.sql) !== change.exec.digest) {
            issues.push({
                kind: 'exec-digest',
                change: change.name,
                message: 'executable deploy digest does not match its sql'
            });
        }
        const expected = (0, create_1.computeChangeDigest)(change.name, {
            deploy: change.deploy?.digest,
            revert: change.revert?.digest,
            verify: change.verify?.digest,
            exec: change.exec?.digest
        });
        if (expected !== change.digest) {
            issues.push({
                kind: 'change-digest',
                change: change.name,
                message: 'change digest does not match its scripts'
            });
        }
    }
    const expectedBundle = (0, create_1.computeBundleDigest)(bundle.plan, bundle.control?.content ?? null, bundle.changes.map(c => c.digest));
    if (expectedBundle !== bundle.manifest.digest) {
        issues.push({
            kind: 'bundle-digest',
            message: 'manifest.digest does not match bundle content'
        });
    }
    return issues;
}
