"use strict";
/**
 * Pluggable migration-backend ("driver") contract.
 *
 * pgpm's engine only needs a node-`pg`-shaped pool/client (see `pg-cache` /
 * `pgsql-client` seams). A *driver plugin* is a package that registers those
 * factories against some backend (e.g. in-process PGlite) and tells pgpm which
 * server-only steps to skip. pgpm core/CLI depend on this contract only — never
 * on any specific backend or its dependencies. The plugin is resolved from the
 * *consumer's* project, exactly like ESLint/Babel resolve plugins and presets.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BUILTIN_ENGINES = exports.DEFAULT_ENGINE = exports.PGPM_DRIVER_EXPORT = void 0;
/** Named export a driver plugin module must expose. */
exports.PGPM_DRIVER_EXPORT = 'createPgpmDriver';
/** Engine used when nothing selects one: the built-in Postgres server path. */
exports.DEFAULT_ENGINE = 'pg';
/**
 * Engines pgpm knows by name. Anything else must be declared in the `engines`
 * block of `pgpm.json` (the analogue of sqitch's `[engine "name"]` sections) or
 * named directly with `--driver <package>`.
 */
exports.BUILTIN_ENGINES = {
    [exports.DEFAULT_ENGINE]: {},
    pglite: { plugin: '@pgpmjs/pglite-adapter' }
};
