/**
 * Declarative extension manifest (`extensions.json`) that lives next to a
 * module's `pgpm.plan` / `.control`. It makes a module self-describing about
 * the PostgreSQL extensions it relates to:
 *
 * - `provides` — the module *is* the extension wrapper: it installs the
 *   extension into a chosen schema (with grants). This is what replaces the
 *   dynamic `DO $$ EXECUTE 'CREATE EXTENSION ... SCHEMA x' $$` hack, since a
 *   literal `CREATE EXTENSION` is stripped at package time.
 * - `consumes` — the module merely *uses* symbols from an extension installed
 *   elsewhere (e.g. a bare `crypt()` call) and needs them qualified to wherever
 *   the extension actually landed. This is the transform/routing side.
 *
 * `.control` `requires` still names the extension (dependency ordering is
 * unchanged); this manifest only adds the *where + grants* that `.control`
 * cannot express.
 */
/** Candidate file names, in precedence order. */
export declare const EXTENSIONS_MANIFEST_FILES: readonly ["pgpm.extensions.json", "extensions.json"];
/**
 * What a declared grant targets. Kept structural (not free-form SQL) so it can
 * be classified, role-routed, and reverted deterministically.
 */
export type ExtensionGrantTarget = 'schema' | 'all-tables' | 'all-sequences' | 'all-functions';
export interface ExtensionGrant {
    /** Privilege list, e.g. `USAGE`, `ALL`, `EXECUTE`, `SELECT`. */
    privileges: string;
    /** Object class the grant applies to, resolved against the install schema. */
    on: ExtensionGrantTarget;
    /** Role name(s). Routed through the workspace role map when one is supplied. */
    to: string | string[];
}
export interface ExtensionProvide {
    /**
     * Target schema for the install. A string routes the extension there; `null`
     * means default/unqualified (control-file location, typically `public`).
     */
    schema?: string | null;
    /**
     * Author's assertion that the extension is relocatable. Defaults to `true`.
     * A fixed-schema (`false`) extension must not be routed to a schema that
     * differs from its control-file schema — {@link compileExtensionInstall}
     * refuses that combination.
     */
    relocatable?: boolean;
    /** Emit `IF NOT EXISTS` on `CREATE EXTENSION`. Defaults to `true`. */
    ifNotExists?: boolean;
    /** Emit `CASCADE` on `CREATE EXTENSION`. Defaults to `false`. */
    cascade?: boolean;
    /**
     * Create `schema` before installing (idempotent). Defaults to `true` when a
     * schema is given. Set `false` when the schema is owned by another module.
     */
    createSchema?: boolean;
    /** Also `DROP SCHEMA` on revert. Defaults to `false` (only drop the extension). */
    dropSchema?: boolean;
    /** Grants applied after install. */
    grants?: ExtensionGrant[];
}
export interface ExtensionConsume {
    /** Bare symbol names this module references (functions/types/operators). */
    symbols?: string[];
}
export interface ExtensionsManifest {
    provides?: Record<string, ExtensionProvide>;
    consumes?: Record<string, ExtensionConsume>;
}
/**
 * Validate + normalize a parsed manifest object. Throws with a precise message
 * on malformed input so authors get actionable errors rather than silent
 * misconfiguration.
 */
export declare function validateExtensionsManifest(raw: unknown, source?: string): ExtensionsManifest;
/**
 * Read + validate the `extensions.json` (or `pgpm.extensions.json`) manifest for
 * a module directory. Returns `undefined` when the module declares no manifest.
 */
export declare function readExtensionsManifest(moduleDir: string): ExtensionsManifest | undefined;
