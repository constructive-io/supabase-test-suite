export interface DebugOptions {
    enabled: boolean;
    logLevel?: 'info' | 'warn' | 'error' | 'debug';
    showStackTrace?: boolean;
    showQueryParams?: boolean;
    showFullSQL?: boolean;
}
export declare class DebugHelper {
    private options;
    constructor(options?: DebugOptions);
    isEnabled(): boolean;
    logError(message: string, error?: any, context?: Record<string, any>): void;
    logQuery(query: string, params?: any[], duration?: number): void;
    logTransactionStart(): void;
    logTransactionCommit(duration?: number): void;
    logTransactionRollback(duration?: number): void;
    static fromEnvironment(): DebugHelper;
}
export declare const debugHelper: DebugHelper;
export declare function enableDebugMode(): void;
export declare function createDebugSummary(error: any, context?: Record<string, any>): string;
