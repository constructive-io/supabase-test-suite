"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasApplySpec = hasApplySpec;
exports.readApplySpec = readApplySpec;
exports.parseApplySpec = parseApplySpec;
const fs_1 = require("fs");
const path_1 = require("path");
const types_1 = require("./types");
/** Whether a module directory is an apply-spec proxy module. */
function hasApplySpec(moduleDir) {
    return (0, fs_1.existsSync)((0, path_1.join)(moduleDir, types_1.APPLY_SPEC_FILE));
}
/**
 * Read, validate, and normalize a proxy module's `pgpm.apply.json`.
 *
 * Normalizations: `source` is expanded to its object form and `name` defaults
 * to the proxy directory's name.
 *
 * @throws when the file is missing, unparsable, or structurally invalid.
 */
function readApplySpec(moduleDir) {
    const specPath = (0, path_1.join)(moduleDir, types_1.APPLY_SPEC_FILE);
    if (!(0, fs_1.existsSync)(specPath)) {
        throw new Error(`No ${types_1.APPLY_SPEC_FILE} found in ${moduleDir}`);
    }
    return parseApplySpec((0, fs_1.readFileSync)(specPath, 'utf-8'), specPath);
}
/** In-memory core of {@link readApplySpec}. */
function parseApplySpec(content, specPath) {
    let parsed;
    try {
        parsed = JSON.parse(content);
    }
    catch (err) {
        throw new Error(`Failed to parse ${specPath}: ${err instanceof Error ? err.message : err}`);
    }
    const source = typeof parsed?.source === 'string' ? { module: parsed.source } : parsed?.source;
    if (!source || typeof source.module !== 'string' || !source.module) {
        throw new Error(`${specPath}: "source" (source module name, or { "module": ... }) is required`);
    }
    const isSchemaMap = (value) => typeof value === 'object' &&
        value !== null &&
        !Array.isArray(value) &&
        Object.keys(value).length > 0 &&
        Object.entries(value).every(([from, to]) => typeof from === 'string' && typeof to === 'string' && !!from && !!to);
    const hasSchemas = parsed.schemas !== undefined;
    if (hasSchemas && !isSchemaMap(parsed.schemas)) {
        throw new Error(`${specPath}: "schemas" must be a non-empty string → string map`);
    }
    const ROUTE_KINDS = ['table', 'view', 'function', 'procedure', 'type'];
    const hasRoute = parsed.route !== undefined;
    if (hasRoute) {
        if (!Array.isArray(parsed.route) || parsed.route.length === 0) {
            throw new Error(`${specPath}: "route" must be a non-empty array of route entries`);
        }
        for (const entry of parsed.route) {
            const validToSchema = entry?.toSchema === undefined ||
                entry.toSchema === null ||
                (typeof entry.toSchema === 'string' && !!entry.toSchema);
            const validToName = entry?.toName === undefined || (typeof entry.toName === 'string' && !!entry.toName);
            if (!entry ||
                typeof entry !== 'object' ||
                typeof entry.fromSchema !== 'string' ||
                !entry.fromSchema ||
                typeof entry.name !== 'string' ||
                !entry.name ||
                !validToSchema ||
                !validToName ||
                (entry.toSchema === undefined && entry.toName === undefined) ||
                !ROUTE_KINDS.includes(entry.kind)) {
                throw new Error(`${specPath}: each "route" entry needs { fromSchema, kind (${ROUTE_KINDS.join('|')}), name } plus "toSchema" (schema | null) and/or "toName"`);
            }
        }
    }
    const hasReuse = parsed.reuse !== undefined;
    if (hasReuse) {
        const reuse = parsed.reuse;
        if (typeof reuse !== 'object' || reuse === null || Array.isArray(reuse)) {
            throw new Error(`${specPath}: "reuse" must be an object`);
        }
        if (!isSchemaMap(reuse.sharedSchema)) {
            throw new Error(`${specPath}: "reuse.sharedSchema" must be a non-empty string → string map`);
        }
        if (!Array.isArray(reuse.perTenant) || reuse.perTenant.length === 0) {
            throw new Error(`${specPath}: "reuse.perTenant" must be a non-empty array of seed objects`);
        }
        for (const seed of reuse.perTenant) {
            if (!seed ||
                typeof seed !== 'object' ||
                typeof seed.fromSchema !== 'string' ||
                !seed.fromSchema ||
                typeof seed.name !== 'string' ||
                !seed.name ||
                !ROUTE_KINDS.includes(seed.kind)) {
                throw new Error(`${specPath}: each "reuse.perTenant" seed needs { fromSchema, kind (${ROUTE_KINDS.join('|')}), name } as non-empty strings`);
            }
        }
        if (reuse.sharedName !== undefined && (typeof reuse.sharedName !== 'string' || !reuse.sharedName)) {
            throw new Error(`${specPath}: "reuse.sharedName" must be a non-empty string`);
        }
        if (!hasSchemas) {
            throw new Error(`${specPath}: "reuse" requires "schemas" (the per-tenant source → target schema map)`);
        }
        for (const seed of reuse.perTenant) {
            if (!(seed.fromSchema in parsed.schemas)) {
                throw new Error(`${specPath}: "reuse.perTenant" seed schema "${seed.fromSchema}" has no per-tenant ` +
                    `target in "schemas"`);
            }
            if (!(seed.fromSchema in reuse.sharedSchema)) {
                throw new Error(`${specPath}: "reuse.perTenant" seed schema "${seed.fromSchema}" has no shared ` +
                    `target in "reuse.sharedSchema"`);
            }
        }
    }
    const hasExtensions = parsed.extensions !== undefined;
    if (hasExtensions) {
        const ext = parsed.extensions;
        if (typeof ext !== 'object' || ext === null || Array.isArray(ext)) {
            throw new Error(`${specPath}: "extensions" must be an object`);
        }
        const isSchemaOrNull = (v) => v === null || (typeof v === 'string' && !!v);
        const hasRoutes = ext.routes !== undefined;
        if (hasRoutes) {
            if (typeof ext.routes !== 'object' || ext.routes === null || Array.isArray(ext.routes)) {
                throw new Error(`${specPath}: "extensions.routes" must be an object keyed by extension name`);
            }
            for (const [name, route] of Object.entries(ext.routes)) {
                if (!route || typeof route !== 'object' || !isSchemaOrNull(route.to)) {
                    throw new Error(`${specPath}: "extensions.routes.${name}" must be { to: schema | null, from?: (string|null)[] }`);
                }
            }
        }
        else if (!('toSchema' in ext)) {
            throw new Error(`${specPath}: "extensions" needs "toSchema" (schema | null) or "routes"`);
        }
        else if (!isSchemaOrNull(ext.toSchema)) {
            throw new Error(`${specPath}: "extensions.toSchema" must be a non-empty string or null`);
        }
        if (ext.only !== undefined && (!Array.isArray(ext.only) || ext.only.some((e) => typeof e !== 'string' || !e))) {
            throw new Error(`${specPath}: "extensions.only" must be an array of extension names`);
        }
        if (ext.serverVersion !== undefined && typeof ext.serverVersion !== 'number') {
            throw new Error(`${specPath}: "extensions.serverVersion" must be a number`);
        }
    }
    const hasRoles = parsed.roles !== undefined;
    if (hasRoles && !isSchemaMap(parsed.roles)) {
        throw new Error(`${specPath}: "roles" must be a non-empty string → string map`);
    }
    const hasExclude = parsed.exclude !== undefined;
    if (hasExclude) {
        const ex = parsed.exclude;
        if (typeof ex !== 'object' ||
            ex === null ||
            Array.isArray(ex) ||
            !Array.isArray(ex.schemas) ||
            ex.schemas.length === 0 ||
            ex.schemas.some((s) => typeof s !== 'string' || !s)) {
            throw new Error(`${specPath}: "exclude" must be { schemas: [non-empty schema names] }`);
        }
    }
    if (!hasSchemas && !hasRoute && !hasExtensions && !hasRoles && !hasExclude) {
        throw new Error(`${specPath}: at least one of "schemas", "route", "extensions", "roles", or "exclude" is required`);
    }
    const name = parsed.name ?? (0, path_1.basename)((0, path_1.dirname)(specPath));
    if (typeof name !== 'string' || !name) {
        throw new Error(`${specPath}: "name" must be a non-empty string`);
    }
    if (name === source.module) {
        throw new Error(`${specPath}: apply module "${name}" cannot apply itself`);
    }
    const requires = parsed.requires;
    if (requires !== undefined &&
        (!Array.isArray(requires) || requires.some((r) => typeof r !== 'string' || !r))) {
        throw new Error(`${specPath}: "requires" must be an array of module names`);
    }
    if (requires?.includes(source.module)) {
        throw new Error(`${specPath}: "requires" must not include the source module "${source.module}" — ` +
            `it is source material, not a runtime dependency`);
    }
    return { ...parsed, name, source, requires };
}
