import { Chunk, RebundleResult, RebundleStrategy } from './types';
/**
 * Compute a rebundle plan for a pgpm module directory.
 *
 * Uses the existing plan parser, dependency graph, and package-dependency /
 * deploy-order primitives from the slicer — chunks are treated exactly like
 * packages for dependency and ordering purposes. No plan re-parsing or path
 * logic is reinvented here.
 */
export declare function rebundlePlan(moduleDir: string, strategy?: RebundleStrategy): RebundleResult;
/**
 * Assemble the merged SQL for one chunk in the given direction by concatenating
 * its member script files — the same file-concatenation `resolveWithPlan` uses,
 * just scoped to the chunk. Members are already correctly ordered per direction.
 */
export declare function assembleChunkSql(moduleDir: string, chunk: Chunk, scriptType?: 'deploy' | 'revert' | 'verify'): string;
/**
 * Byte-identical gate: assembling all chunks in deploy order must reproduce the
 * module's original resolved output in every direction the engine cares about
 * (deploy topological, verify in deploy order, revert reversed). This is the
 * invariant that makes any granularity-dial position safe.
 */
export declare function verifyRebundleInvariant(moduleDir: string, result: RebundleResult): {
    ok: boolean;
    mismatches: ('deploy' | 'revert' | 'verify')[];
};
