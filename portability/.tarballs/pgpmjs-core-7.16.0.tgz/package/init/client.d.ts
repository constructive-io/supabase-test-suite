import { RoleMapping, TestUserCredentials } from '@pgpmjs/types';
import { PgConfig } from 'pg-env';
export declare class PgpmInit {
    private pool;
    private pgConfig;
    constructor(config: PgConfig);
    /**
     * Bootstrap standard roles (anonymous, authenticated, administrator).
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param roles - Role mapping from getConnEnvOptions().roles!
     */
    bootstrapRoles(roles: RoleMapping): Promise<void>;
    /**
     * Bootstrap the restricted client role (authenticated_client) for SQL-level
     * proxy clients. Opt-in via `pgpm admin-users bootstrap --client`.
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param roles - Role mapping from getConnEnvOptions().roles!
     */
    bootstrapClientRole(roles: RoleMapping): Promise<void>;
    /**
     * Bootstrap test roles (app_user, app_admin with grants to base roles).
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param roles - Role mapping from getConnEnvOptions().roles!
     * @param connections - Test user credentials from getConnEnvOptions().connections!
     */
    bootstrapTestRoles(roles: RoleMapping, connections: TestUserCredentials): Promise<void>;
    /**
     * Bootstrap database roles with custom username and password.
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param username - The username to create
     * @param password - The password for the user
     * @param roles - Role mapping from getConnEnvOptions().roles!
     * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
     */
    bootstrapDbRoles(username: string, password: string, roles: RoleMapping, useLocksForRoles?: boolean): Promise<void>;
    /**
     * Remove database roles and revoke grants.
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param username - The username to remove
     * @param roles - Role mapping from getConnEnvOptions().roles!
     * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
     */
    removeDbRoles(username: string, roles: RoleMapping, useLocksForRoles?: boolean): Promise<void>;
    /**
     * Close the database connection
     */
    close(): Promise<void>;
}
