"use strict";
/**
 * The apply-spec ("proxy module") types.
 *
 * A proxy module is a directory containing a single `pgpm.apply.json` file:
 * "apply <source module> transpiled with this schema map, under my name". It
 * needs no `.control`, no `pgpm.plan`, and no deploy/revert/verify scripts —
 * workspace discovery synthesizes a module entry from the spec, so the proxy
 * participates in dependency resolution by name exactly like a regular
 * module. At deploy/verify/revert time the engine transpiles the source
 * module in memory and runs the normal migration path against the result;
 * transpiled code is never committed.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.APPLY_SPEC_FILE = void 0;
/** File name of the apply spec inside a proxy module directory. */
exports.APPLY_SPEC_FILE = 'pgpm.apply.json';
