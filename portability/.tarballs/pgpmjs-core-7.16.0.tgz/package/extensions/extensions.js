"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAvailableExtensions = void 0;
/**
 * Get the list of available extensions, including predefined core extensions.
 */
const getAvailableExtensions = async (modules) => {
    const coreExtensions = [
        // Security & identity
        'pgcrypto',
        'uuid-ossp',
        // Developer ergonomics
        'citext',
        'hstore',
        // Search & relevance
        'pg_trgm',
        'unaccent',
        // Indexing building blocks
        'btree_gin',
        'btree_gist',
        // Data interoperability
        'postgres_fdw',
        // Geospatial (vertical showcase)
        'postgis',
        // AI & embeddings
        'vector',
        // Procedural logic (baseline)
        'plpgsql',
    ];
    return Object.keys(modules).reduce((acc, module) => {
        if (!acc.includes(module))
            acc.push(module);
        return acc;
    }, [...coreExtensions]);
};
exports.getAvailableExtensions = getAvailableExtensions;
