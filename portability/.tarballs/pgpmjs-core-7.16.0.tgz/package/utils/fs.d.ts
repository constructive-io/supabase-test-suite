/**
 * Move a file or directory, falling back to copy + remove across devices.
 * Replaces shelling out to `mv`, which does not exist on Windows.
 */
export declare const movePath: (src: string, dst: string) => void;
