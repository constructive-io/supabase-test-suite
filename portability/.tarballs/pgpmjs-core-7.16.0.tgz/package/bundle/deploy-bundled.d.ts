import { BundleChange } from '@pgpmjs/bundle';
import { PgConfig } from 'pg-env';
/**
 * Why the one-shot path could not be used, so the caller falls back to the
 * per-change migration path.
 */
export type BundledDeploySkipReason = 'no-executable-sql' | 'unsupported-hash-method';
/** How the executable bundle for a module was obtained. */
export type BundleSource = 'artifact' | 'packaged';
export interface BundledDeployResult {
    /** Module (package) name from the bundle manifest. */
    name: string;
    /** Where the executable bundle came from. */
    source: BundleSource;
    /** Changes executed and recorded on this run, in deploy order. */
    deployed: string[];
    /** Changes already present in the ledger with a matching hash. */
    skipped: string[];
}
export interface BundledDeployOptions {
    config: PgConfig;
    /** Target database (defaults to `config.database`). */
    database?: string;
    /** Record ledger rows without executing the DDL. */
    logOnly?: boolean;
    /** Wrap execution + ledger writes in one transaction. Default true. */
    useTransaction?: boolean;
    /**
     * Ledger hash scheme in force. The bundle's per-change digests are sha256 of
     * the deploy script's bytes, i.e. identical to `PgpmMigrate`'s `content`
     * scheme; the `ast` scheme is not reproducible here, so it is reported as a
     * skip and the caller falls back.
     */
    hashMethod?: 'content' | 'ast';
}
/** Thrown when the ledger already holds a change with different content. */
export declare class BundledDeployConflictError extends Error {
    readonly packageName: string;
    readonly changeName: string;
    constructor(packageName: string, changeName: string);
}
/**
 * The ledger hash for a change: the sha256 of the deploy script bytes.
 *
 * This is deliberately the same value `PgpmMigrate.calculateScriptHash` derives
 * from `deploy/<change>.sql` under the default `content` hash method, so a
 * change hashed at package time and the hash recorded/compared at deploy time
 * agree — the one-shot and per-change paths are interchangeable and idempotent
 * against each other.
 */
export declare function ledgerHashForChange(change: BundleChange): string | null;
/**
 * Deploy a module in one shot **and** record the migration ledger — the `fast`
 * deploy strategy.
 *
 * Pending changes' deploy SQL is concatenated and executed as a single
 * statement (the speed of the old fast path), then one `pgpm_migrate.changes`
 * row per change is bulk-inserted with the deploy script's own sha256 as
 * `script_hash` — one round-trip, instead of an `isDeployed` + `readScript` +
 * `CALL pgpm_migrate.deploy` per change. Because the ledger is written, the
 * path is idempotent and resumable: re-deploys skip changes whose stored hash
 * matches, and a same-name/different-content change raises
 * {@link BundledDeployConflictError} exactly as the per-change path does.
 *
 * Returns a {@link BundledDeploySkipReason} (rather than throwing) when it
 * cannot honour the requested semantics, so the caller falls back to the
 * per-change migration path. Genuine SQL failures still throw.
 */
export declare function deployModuleFast(moduleDir: string, options: BundledDeployOptions): Promise<BundledDeployResult | BundledDeploySkipReason>;
/** True when the value is a real deploy result rather than a skip reason. */
export declare function isBundledDeployResult(value: BundledDeployResult | BundledDeploySkipReason): value is BundledDeployResult;
