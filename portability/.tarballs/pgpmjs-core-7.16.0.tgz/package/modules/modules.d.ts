import { Module } from '@pgpmjs/ast/files';
export type ModuleMap = Record<string, Module>;
/**
 * Mapping from control file names (used in extensions list) to npm package names.
 * Only includes modules that can be installed via pgpm install from @pgpm/* packages.
 * Native PostgreSQL extensions (plpgsql, uuid-ossp, etc.) are not included.
 */
export declare const PGPM_MODULE_MAP: Record<string, string>;
/**
 * Result of checking for missing installable modules.
 */
export interface MissingModule {
    controlName: string;
    npmName: string;
}
/**
 * Determines which pgpm modules from an extensions list are missing from the installed modules.
 * Only checks modules that are in PGPM_MODULE_MAP (installable via pgpm install).
 *
 * @param extensions - List of extension/control file names to check
 * @param installedModules - List of installed npm package names (e.g., '@pgpm/base32')
 * @returns Array of missing modules with their control names and npm package names
 */
export declare const getMissingInstallableModules: (extensions: string[], installedModules: string[]) => MissingModule[];
/**
 * Get the latest change from the pgpm.plan file for a specific module.
 */
export declare const latestChange: (sqlmodule: string, modules: ModuleMap, basePath: string) => string;
/**
 * Get the latest change and version for a specific module.
 */
export declare const latestChangeAndVersion: (sqlmodule: string, modules: ModuleMap, basePath: string) => {
    change: string;
    version: string;
};
/**
 * Get extensions and modules required by a specific module.
 */
export declare const getExtensionsAndModules: (sqlmodule: string, modules: ModuleMap) => {
    native: string[];
    sqitch: string[];
};
/**
 * Get extensions and modules with their latest changes and versions.
 */
export declare const getExtensionsAndModulesChanges: (sqlmodule: string, modules: ModuleMap, basePath: string) => {
    native: string[];
    sqitch: {
        name: string;
        latest: string;
        version: string;
    }[];
};
