"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.withTransaction = exports.executeQuery = exports.hashString = exports.hashFile = exports.parseAuthor = exports.PgpmInit = exports.PgpmMigrate = exports.cleanSql = void 0;
__exportStar(require("./core/class/pgpm"), exports);
__exportStar(require("./rebundle"), exports);
__exportStar(require("./extensions"), exports);
__exportStar(require("./modules/modules"), exports);
__exportStar(require("./packaging/package"), exports);
__exportStar(require("./packaging/sync-versions"), exports);
__exportStar(require("./packaging/transform"), exports);
__exportStar(require("./resolution/deps"), exports);
__exportStar(require("./resolution/resolve"), exports);
__exportStar(require("./workspace/paths"), exports);
__exportStar(require("./workspace/utils"), exports);
__exportStar(require("./workspace/minimal"), exports);
__exportStar(require("./core/template-scaffold"), exports);
__exportStar(require("./core/boilerplate-types"), exports);
__exportStar(require("./core/boilerplate-scanner"), exports);
// Re-export the module AST layer (moved to the @pgpmjs/ast leaf package)
__exportStar(require("@pgpmjs/ast/files"), exports);
__exportStar(require("@pgpmjs/ast/module"), exports);
__exportStar(require("./apply"), exports);
__exportStar(require("./bundle"), exports);
__exportStar(require("./refactor"), exports);
var clean_1 = require("./migrate/clean");
Object.defineProperty(exports, "cleanSql", { enumerable: true, get: function () { return clean_1.cleanSql; } });
var client_1 = require("./migrate/client");
Object.defineProperty(exports, "PgpmMigrate", { enumerable: true, get: function () { return client_1.PgpmMigrate; } });
var client_2 = require("./init/client");
Object.defineProperty(exports, "PgpmInit", { enumerable: true, get: function () { return client_2.PgpmInit; } });
__exportStar(require("./roles"), exports);
var ast_1 = require("@pgpmjs/ast");
Object.defineProperty(exports, "parseAuthor", { enumerable: true, get: function () { return ast_1.parseAuthor; } });
var hash_1 = require("./migrate/utils/hash");
Object.defineProperty(exports, "hashFile", { enumerable: true, get: function () { return hash_1.hashFile; } });
Object.defineProperty(exports, "hashString", { enumerable: true, get: function () { return hash_1.hashString; } });
var transaction_1 = require("./migrate/utils/transaction");
Object.defineProperty(exports, "executeQuery", { enumerable: true, get: function () { return transaction_1.executeQuery; } });
Object.defineProperty(exports, "withTransaction", { enumerable: true, get: function () { return transaction_1.withTransaction; } });
