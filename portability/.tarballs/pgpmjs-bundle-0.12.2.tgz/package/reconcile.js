"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reconcilePlan = reconcilePlan;
const diff_1 = require("./diff");
/**
 * Compute a {@link ReconcilePlan} between two bundles. Pure and deterministic.
 *
 * A `modified` change is both reverted (old definition) and re-deployed (new
 * definition). A pure reorder over identical content yields no revert/deploy
 * ops — `diff.reordered` records it for the caller to decide on.
 */
function reconcilePlan(from, to) {
    const diff = (0, diff_1.diffBundles)(from, to);
    const modified = new Set(diff.modified.map(c => c.name));
    const removed = new Set(diff.removed);
    const added = new Set(diff.added);
    const revert = from.changes
        .map(c => c.name)
        .filter(name => removed.has(name) || modified.has(name))
        .reverse();
    const deploy = to.changes
        .map(c => c.name)
        .filter(name => added.has(name) || modified.has(name));
    return { diff, revert, deploy, noop: diff.identical };
}
