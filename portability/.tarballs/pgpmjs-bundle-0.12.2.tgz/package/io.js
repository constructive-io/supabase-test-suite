"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BUNDLE_ARCHIVE_EXTENSION = exports.BUNDLE_ARCHIVE_ENTRY = exports.BUNDLE_FILE_NAME = void 0;
exports.bundleFromModule = bundleFromModule;
exports.writeBundleFile = writeBundleFile;
exports.serializeBundle = serializeBundle;
exports.readBundleFile = readBundleFile;
exports.packBundle = packBundle;
exports.unpackBundle = unpackBundle;
exports.writeBundleArchiveFile = writeBundleArchiveFile;
exports.readBundleArchiveFile = readBundleArchiveFile;
exports.moduleFromBundle = moduleFromBundle;
exports.materializeBundle = materializeBundle;
const fs_1 = require("fs");
const path_1 = require("path");
const reader_1 = require("@pgpmjs/ast/files/extension/reader");
const parser_1 = require("@pgpmjs/ast/files/plan/parser");
const header_1 = require("@pgpmjs/ast/files/sql/header");
const reader_2 = require("@pgpmjs/ast/module/reader");
const writer_1 = require("@pgpmjs/ast/module/writer");
const traverse_1 = require("@pgpmjs/traverse");
const create_1 = require("./create");
const tar_1 = require("./tar");
/** Default file name for a serialized bundle artifact. */
exports.BUNDLE_FILE_NAME = 'pgpm-bundle.json';
/** The single entry name inside a `.bundle.tar.gz` archive. */
exports.BUNDLE_ARCHIVE_ENTRY = exports.BUNDLE_FILE_NAME;
/** Suffix of the stored bundle artifact: `sql/<name>--<version>.bundle.tar.gz`. */
exports.BUNDLE_ARCHIVE_EXTENSION = '.bundle.tar.gz';
/**
 * Build a bundle straight from a module directory on disk (readModule → createBundle).
 */
function bundleFromModule(moduleDir, options) {
    return (0, create_1.createBundle)((0, reader_2.readModule)(moduleDir), options);
}
/**
 * Serialize a bundle to a single JSON artifact file (stable 2-space formatting).
 */
function writeBundleFile(bundle, filePath) {
    (0, fs_1.mkdirSync)((0, path_1.dirname)(filePath), { recursive: true });
    (0, fs_1.writeFileSync)(filePath, serializeBundle(bundle));
}
/** Stable JSON serialization of a bundle (2-space formatting, trailing newline). */
function serializeBundle(bundle) {
    return JSON.stringify(bundle, null, 2) + '\n';
}
/**
 * Read a bundle artifact JSON file back into memory.
 */
function readBundleFile(filePath) {
    return JSON.parse((0, fs_1.readFileSync)(filePath, 'utf-8'));
}
/** Serialize a bundle to the stored artifact form: gzipped tar of the JSON bundle. */
function packBundle(bundle) {
    return (0, tar_1.packSingleFileTarGz)(exports.BUNDLE_ARCHIVE_ENTRY, serializeBundle(bundle));
}
/**
 * Read a stored bundle artifact (gzipped tar) back into memory. Throws when the
 * archive or its JSON payload is unreadable.
 */
function unpackBundle(archive) {
    const { content } = (0, tar_1.unpackSingleFileTarGz)(archive);
    return JSON.parse(content);
}
/** Write the stored `.bundle.tar.gz` artifact for a bundle. */
function writeBundleArchiveFile(bundle, filePath) {
    (0, fs_1.mkdirSync)((0, path_1.dirname)(filePath), { recursive: true });
    (0, fs_1.writeFileSync)(filePath, packBundle(bundle));
}
/** Read a stored `.bundle.tar.gz` artifact from disk. */
function readBundleArchiveFile(filePath) {
    return unpackBundle((0, fs_1.readFileSync)(filePath));
}
function scriptAstFromBundleScript(script) {
    const { header, body } = (0, header_1.parsePgpmHeader)(script.sql);
    return { kind: script.kind, header, body, raw: script.sql };
}
/**
 * Hydrate a bundle back into a {@link PgpmModuleAst} — the inverse of
 * `createBundle`. Composes the existing plan/control/SQL-header parsers over
 * the bundle's byte-exact contents; every leaf keeps the bundle text as its
 * `raw`, so `writeModule` reproduces the bundle losslessly.
 */
function moduleFromBundle(bundle, dir = '') {
    const parsed = (0, parser_1.parsePlanContent)(bundle.plan);
    if (!parsed.data) {
        const detail = parsed.errors
            .map(e => `line ${e.line}: ${e.message}`)
            .join('; ');
        throw new Error(`Failed to parse bundle plan for ${bundle.manifest.name}: ${detail}`);
    }
    const plan = parsed.data;
    const planEntries = new Map(plan.changes.map(change => [change.name, change]));
    let control = null;
    if (bundle.control) {
        const { requires, version } = (0, reader_1.parseControlContent)(bundle.control.content);
        control = {
            fileName: bundle.control.fileName,
            name: bundle.manifest.name,
            requires,
            version,
            raw: bundle.control.content
        };
    }
    const changes = bundle.changes.map(change => {
        const planEntry = planEntries.get(change.name) ?? { name: change.name, dependencies: change.dependencies };
        const { deploy, revert, verify } = (0, traverse_1.mapScripts)(change, scriptAstFromBundleScript);
        return { name: change.name, plan: planEntry, deploy, revert, verify };
    });
    return {
        dir,
        name: bundle.manifest.name,
        plan,
        planRaw: bundle.plan,
        control,
        changes
    };
}
/**
 * Materialize a bundle back into a real, deployable pgpm module directory:
 * `pgpm.plan`, the `.control` file (when present), and each change's
 * deploy/revert/verify script at its `deploy/<change>.sql` path.
 *
 * The inverse of {@link bundleFromModule}; the emitted directory can be read
 * back with `readModule` or deployed with `PgpmMigrate`. Implemented as
 * {@link moduleFromBundle} → `writeModule` (byte-exact `raw` leaves), so the
 * bundle write path is the module AST writer — not a parallel one.
 */
function materializeBundle(bundle, outDir) {
    (0, writer_1.writeModule)(moduleFromBundle(bundle, outDir), { outDir });
}
