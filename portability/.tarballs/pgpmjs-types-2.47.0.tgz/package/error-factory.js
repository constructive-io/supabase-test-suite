"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeError = exports.errors = void 0;
/**
 * pgpm error factory.
 *
 * The canonical error system now lives in `@constructive-io/errors` (a
 * standalone, zero-dependency package). pgpm's error codes are registered
 * there; this module re-exports the shared factory so existing call sites
 * (`throw errors.MODULE_NOT_FOUND({ name })`) are unchanged.
 */
var errors_1 = require("@constructive-io/errors");
Object.defineProperty(exports, "errors", { enumerable: true, get: function () { return errors_1.errors; } });
Object.defineProperty(exports, "makeError", { enumerable: true, get: function () { return errors_1.makeError; } });
