export declare const cleanSql: (sql: string, pretty: boolean, functionDelimiter: string) => Promise<string>;
