"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.truncateErrorOutput = exports.formatQueryHistory = void 0;
exports.withTransaction = withTransaction;
exports.executeQuery = executeQuery;
const logger_1 = require("@pgpmjs/logger");
const types_1 = require("@pgpmjs/types");
const errors_1 = require("./errors");
// Re-export error formatting functions
var errors_2 = require("./errors");
Object.defineProperty(exports, "formatQueryHistory", { enumerable: true, get: function () { return errors_2.formatQueryHistory; } });
Object.defineProperty(exports, "truncateErrorOutput", { enumerable: true, get: function () { return errors_2.truncateErrorOutput; } });
const log = new logger_1.Logger('migrate:transaction');
/**
 * Execute a function within a transaction context
 * If useTransaction is true, wraps the execution in a transaction
 * If false, uses the pool directly without transaction
 */
async function withTransaction(pool, options, fn) {
    const queryHistory = [];
    const addQuery = (query, params, startTime) => {
        queryHistory.push({
            query,
            params,
            timestamp: Date.now(),
            duration: startTime ? Date.now() - startTime : undefined
        });
    };
    if (!options.useTransaction) {
        // No transaction - use pool directly
        log.debug('Executing without transaction');
        return fn({ client: pool, isTransaction: false, queryHistory, addQuery });
    }
    // Use transaction
    const client = await pool.connect();
    const transactionStartTime = Date.now();
    log.debug('Starting transaction');
    try {
        const beginTime = Date.now();
        await client.query('BEGIN');
        addQuery('BEGIN', [], beginTime);
        const result = await fn({ client, isTransaction: true, queryHistory, addQuery });
        const commitTime = Date.now();
        await client.query('COMMIT');
        addQuery('COMMIT', [], commitTime);
        const transactionDuration = Date.now() - transactionStartTime;
        log.debug(`Transaction committed successfully in ${transactionDuration}ms`);
        return result;
    }
    catch (error) {
        const rollbackTime = Date.now();
        try {
            await client.query('ROLLBACK');
            addQuery('ROLLBACK', [], rollbackTime);
        }
        catch (rollbackError) {
            log.error('Failed to rollback transaction:', rollbackError);
        }
        const transactionDuration = Date.now() - transactionStartTime;
        // Enhanced error logging with context
        const errorLines = [];
        errorLines.push(`Transaction rolled back due to error after ${transactionDuration}ms:`);
        errorLines.push(`Error Code: ${error.code || 'N/A'}`);
        errorLines.push(`Error Message: ${error.message || 'N/A'}`);
        // Add extended PostgreSQL error fields
        const pgFields = (0, types_1.extractPgErrorFields)(error);
        if (pgFields) {
            const fieldLines = (0, types_1.formatPgErrorFields)(pgFields);
            if (fieldLines.length > 0) {
                errorLines.push(...fieldLines);
            }
        }
        // Log query history for debugging (with smart collapsing and limiting)
        if (queryHistory.length > 0) {
            errorLines.push('Query history for this transaction:');
            const historyLines = (0, errors_1.formatQueryHistory)(queryHistory);
            errorLines.push(...historyLines);
        }
        // For transaction aborted errors, provide additional context
        if (error.code === '25P02') {
            errorLines.push('🔍 Debug Info: Transaction was aborted due to a previous error.');
            errorLines.push('   This usually means a previous command in the transaction failed.');
            errorLines.push('   Check the query history above to identify the failing command.');
        }
        // Apply total output length limit and log the consolidated error message
        const finalLines = (0, errors_1.truncateErrorOutput)(errorLines);
        log.error(finalLines.join('\n'));
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Helper to execute a query within a transaction context with enhanced logging
 */
async function executeQuery(context, query, params) {
    const startTime = Date.now();
    try {
        const result = await context.client.query(query, params);
        const duration = Date.now() - startTime;
        // Add to query history
        context.addQuery(query, params, startTime);
        // Log slow queries for debugging
        if (duration > 1000) {
            log.warn(`Slow query detected (${duration}ms): ${query.split('\n')[0].trim()}`);
        }
        return result;
    }
    catch (error) {
        const duration = Date.now() - startTime;
        // Add failed query to history
        context.addQuery(query, params, startTime);
        // Enhanced error logging
        const errorLines = [];
        errorLines.push(`Query failed after ${duration}ms:`);
        errorLines.push(`  Query: ${query.split('\n')[0].trim()}`);
        if (params && params.length > 0) {
            errorLines.push(`  Params: ${JSON.stringify(params)}`);
        }
        errorLines.push(`  Error Code: ${error.code || 'N/A'}`);
        errorLines.push(`  Error Message: ${error.message || 'N/A'}`);
        // Add extended PostgreSQL error fields
        const pgFields = (0, types_1.extractPgErrorFields)(error);
        if (pgFields) {
            const fieldLines = (0, types_1.formatPgErrorFields)(pgFields);
            if (fieldLines.length > 0) {
                fieldLines.forEach(line => errorLines.push(`  ${line}`));
            }
        }
        // Provide debugging hints for common errors
        if (error.code === '42P01') {
            errorLines.push('💡 Hint: Relation (table/view) does not exist. Check if migrations are applied in correct order.');
        }
        else if (error.code === '42883') {
            errorLines.push('💡 Hint: Function does not exist. Check if required extensions or functions are installed.');
        }
        else if (error.code === '23505') {
            errorLines.push('💡 Hint: Unique constraint violation. Check for duplicate data.');
        }
        else if (error.code === '23503') {
            errorLines.push('💡 Hint: Foreign key constraint violation. Check referential integrity.');
        }
        // Log the consolidated error message
        log.error(errorLines.join('\n'));
        throw error;
    }
}
