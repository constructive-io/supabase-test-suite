"use strict";
/**
 * The unified routing profile: the single, shared shape for consumer-side
 * routing policy ("where should schemas/objects/extensions/roles land?").
 *
 * It attaches at two scopes:
 * - workspace scope: the `portability` field of `pgpm.json`
 *   ({@link PgpmWorkspaceConfig.portability}) — the default for every
 *   apply/transpile in the workspace;
 * - per-import scope: the routing keys of a proxy module's `pgpm.apply.json` —
 *   overrides the workspace profile per key (inner scope wins).
 *
 * Module self-description (what a module provides/consumes) lives elsewhere:
 * the per-module `extensions.json` manifest and `.control` `requires`.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROUTING_PROFILE_KEYS = void 0;
exports.mergeRoutingProfiles = mergeRoutingProfiles;
/** The routing-profile keys, in a stable order. */
exports.ROUTING_PROFILE_KEYS = ['schemas', 'route', 'extensions', 'roles', 'exclude'];
/**
 * Merge routing profiles per key: for each of `schemas`/`route`/`extensions`/
 * `roles`, the last profile that defines the key wins whole (no deep merge),
 * like lexical scoping — a profile that only overrides `roles` still inherits
 * an outer `extensions` mapping. Returns `undefined` when no input defines any
 * key.
 */
function mergeRoutingProfiles(...profiles) {
    const merged = {};
    for (const profile of profiles) {
        if (!profile)
            continue;
        for (const key of exports.ROUTING_PROFILE_KEYS) {
            if (profile[key] !== undefined) {
                merged[key] = profile[key];
            }
        }
    }
    return Object.keys(merged).length > 0 ? merged : undefined;
}
