"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.movePath = void 0;
const fs_1 = __importDefault(require("fs"));
/**
 * Move a file or directory, falling back to copy + remove across devices.
 * Replaces shelling out to `mv`, which does not exist on Windows.
 */
const movePath = (src, dst) => {
    try {
        fs_1.default.renameSync(src, dst);
    }
    catch (e) {
        if (e?.code !== 'EXDEV' && e?.code !== 'EPERM')
            throw e;
        fs_1.default.cpSync(src, dst, { recursive: true });
        fs_1.default.rmSync(src, { recursive: true, force: true });
    }
};
exports.movePath = movePath;
