"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadModule = void 0;
exports.extractSqlFacts = extractSqlFacts;
const transform_1 = require("@pgpmjs/transform");
/**
 * The parser runs on a WASM build of the real PostgreSQL parser; callers must
 * `await loadModule()` once before any synchronous extraction/slicing call.
 */
var plpgsql_parser_1 = require("plpgsql-parser");
Object.defineProperty(exports, "loadModule", { enumerable: true, get: function () { return plpgsql_parser_1.loadModule; } });
function pushUnique(list, r) {
    if (list.some(x => x.schema === r.schema && x.name === r.name))
        return;
    list.push(r);
}
/**
 * Extract created objects and schema-qualified references from a SQL script,
 * including references reached inside PL/pgSQL function bodies (which are
 * opaque strings in `CREATE FUNCTION` and invisible to a plain SQL parse).
 *
 * Aggregates `@pgsql/transform`'s per-statement `classifyStatements` facts to
 * the change level: references satisfied by objects the same change creates
 * (in any statement) are dropped.
 */
function extractSqlFacts(sql) {
    const facts = { creates: [], references: [], dynamicSql: false };
    for (const stmt of (0, transform_1.classifyStatements)(sql)) {
        for (const c of stmt.creates) {
            pushUnique(facts.creates, { schema: c.schema, name: c.name });
        }
        for (const r of stmt.references) {
            pushUnique(facts.references, { schema: r.schema, name: r.name });
        }
        if (stmt.dynamicSql)
            facts.dynamicSql = true;
    }
    // A change does not depend on objects it creates itself.
    facts.references = facts.references.filter(r => !facts.creates.some(c => c.schema === r.schema && c.name === r.name));
    return facts;
}
