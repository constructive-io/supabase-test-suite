/**
 * Metadata stored for npm update checks.
 */
export interface UpdateCheckConfig {
    lastCheckedAt: number;
    latestKnownVersion: string;
}
export declare const UPDATE_CHECK_TTL_MS: number;
export declare const UPDATE_CHECK_APPSTASH_KEY = "pgpm-update-check";
export declare const UPDATE_PACKAGE_NAME = "pgpm";
