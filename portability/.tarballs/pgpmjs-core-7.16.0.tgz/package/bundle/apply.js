"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BundleApplyError = void 0;
exports.previewBundleApply = previewBundleApply;
exports.applyBundle = applyBundle;
const fs_1 = require("fs");
const os_1 = require("os");
const path_1 = require("path");
const bundle_1 = require("@pgpmjs/bundle");
const client_1 = require("../migrate/client");
/**
 * Analyze a bundle apply without executing it: verify artifact integrity, run
 * the optional namespace-reference validator, and derive the rollback plan.
 * Pure — no database, no disk.
 */
function previewBundleApply(bundle, options = {}) {
    const namespaceViolations = [];
    if (options.validateReferences) {
        for (const change of bundle.changes) {
            for (const script of [change.deploy, change.revert, change.verify]) {
                if (!script)
                    continue;
                const references = options.validateReferences(script.sql, {
                    change: change.name,
                    kind: script.kind
                });
                if (references.length > 0) {
                    namespaceViolations.push({ change: change.name, kind: script.kind, references });
                }
            }
        }
    }
    return {
        name: bundle.manifest.name,
        deployOrder: [...bundle.manifest.deployOrder],
        bundleIssues: (0, bundle_1.verifyBundle)(bundle),
        namespaceViolations,
        rollbackPlan: [...bundle.manifest.deployOrder].reverse()
    };
}
/** Thrown when an apply is refused pre-flight or exceeds its timeout. */
class BundleApplyError extends Error {
    preview;
    timedOut;
    constructor(message, preview, timedOut = false) {
        super(message);
        this.preview = preview;
        this.timedOut = timedOut;
        this.name = 'BundleApplyError';
    }
}
exports.BundleApplyError = BundleApplyError;
const TIMEOUT = Symbol('timeout');
async function withTimeout(work, ms) {
    if (!ms)
        return work;
    let timer;
    const timeout = new Promise(resolve => {
        timer = setTimeout(() => resolve(TIMEOUT), ms);
    });
    try {
        return await Promise.race([work, timeout]);
    }
    finally {
        clearTimeout(timer);
    }
}
/**
 * Safely apply a {@link MigrationBundle} to a target database.
 *
 * A thin, safety-first wrapper over {@link PgpmMigrate}: it gates on artifact
 * integrity and (optionally) namespace validation, supports a dry run, applies
 * atomically in a single transaction, enforces a timeout, and returns an
 * explicit result including the rollback plan.
 *
 * The mechanics (materialize → deploy → verify) reuse existing plumbing;
 * nothing here re-implements deployment.
 */
async function applyBundle(bundle, options) {
    const started = Date.now();
    const preview = previewBundleApply(bundle, options);
    if (!options.allowUnverified && preview.bundleIssues.length > 0) {
        throw new BundleApplyError(`Refusing to apply "${preview.name}": bundle failed integrity verification ` +
            `(${preview.bundleIssues.length} issue(s): ${preview.bundleIssues.map(i => i.kind).join(', ')})`, preview);
    }
    if (preview.namespaceViolations.length > 0) {
        throw new BundleApplyError(`Refusing to apply "${preview.name}": ${preview.namespaceViolations.length} ` +
            `reference(s) fall outside the target namespace`, preview);
    }
    if (options.dryRun) {
        return {
            preview,
            dryRun: true,
            executed: false,
            durationMs: Date.now() - started,
            timedOut: false
        };
    }
    const ownWorkDir = options.workDir === undefined;
    const workDir = options.workDir ?? (0, fs_1.mkdtempSync)((0, path_1.join)((0, os_1.tmpdir)(), 'pgpm-apply-'));
    (0, bundle_1.materializeBundle)(bundle, workDir);
    const migrate = new client_1.PgpmMigrate(options.config, options.migrateOptions);
    const useTransaction = options.useTransaction ?? true;
    try {
        const run = (async () => {
            const deploy = await migrate.deploy({ modulePath: workDir, useTransaction });
            let verify;
            if (options.verify) {
                verify = await migrate.verify({ modulePath: workDir });
            }
            return { deploy, verify };
        })();
        const outcome = await withTimeout(run, options.timeoutMs);
        if (outcome === TIMEOUT) {
            throw new BundleApplyError(`Apply of "${preview.name}" exceeded ${options.timeoutMs}ms`, preview, true);
        }
        return {
            preview,
            dryRun: false,
            executed: true,
            deploy: outcome.deploy,
            verify: outcome.verify,
            durationMs: Date.now() - started,
            timedOut: false
        };
    }
    finally {
        if (ownWorkDir) {
            try {
                (0, fs_1.rmSync)(workDir, { recursive: true, force: true });
            }
            catch {
                // best-effort cleanup
            }
        }
    }
}
