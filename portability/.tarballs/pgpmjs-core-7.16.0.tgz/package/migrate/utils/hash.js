"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashString = void 0;
exports.hashFile = hashFile;
exports.hashSqlFile = hashSqlFile;
const ast_1 = require("@pgpmjs/ast");
Object.defineProperty(exports, "hashString", { enumerable: true, get: function () { return ast_1.hashString; } });
const crypto_1 = require("crypto");
const promises_1 = require("fs/promises");
const pgsql_parser_1 = require("pgsql-parser");
const package_1 = require("../../packaging/package");
/**
 * Generate SHA256 hash of a file's contents
 */
async function hashFile(filePath) {
    const content = await (0, promises_1.readFile)(filePath, 'utf-8');
    return (0, crypto_1.createHash)('sha256').update(content).digest('hex');
}
/**
 * Generate SHA256 hash of a SQL file's parsed and cleaned AST
 */
async function hashSqlFile(filePath) {
    const content = await (0, promises_1.readFile)(filePath, 'utf-8');
    const parsed = await (0, pgsql_parser_1.parse)(content);
    const cleaned = (0, package_1.cleanTree)(parsed);
    const astString = JSON.stringify(cleaned);
    return (0, ast_1.hashString)(astString);
}
