import { MigrationBundle } from './types';
/**
 * Options for {@link splitBundle}.
 */
export interface SplitBundleOptions {
    /**
     * Change names that must be materialized per tenant (typically the
     * `perTenant` set computed by `@pgpmjs/slice`'s `partitionModule`). Every
     * other change in the bundle is treated as shared.
     */
    perTenantChanges: Iterable<string>;
    /** Module name for the shared bundle (deployed once, reused by all tenants). */
    sharedName: string;
    /** Module name for the per-tenant bundle. */
    perTenantName: string;
    /**
     * Extra changes to weave into the per-tenant bundle only, deployed before its
     * own changes. Used for infrastructure the shared module owns in *its* schema
     * but each tenant must also provision in *its* schema — canonically the
     * `CREATE SCHEMA` of the per-tenant target, which a single source
     * schema-creation change cannot express (it lands in the shared module).
     *
     * When a bootstrap declares `replacesShared`, per-tenant dependencies on that
     * shared change are re-pointed at the bootstrap (a local dependency) instead
     * of becoming a cross-module reference — so a per-tenant object depends on
     * *its own* schema, not the shared one.
     */
    perTenantBootstrap?: PerTenantBootstrapChange[];
}
/**
 * A caller-supplied change woven into the per-tenant bundle by
 * {@link splitBundle} (see {@link SplitBundleOptions.perTenantBootstrap}).
 * The caller owns the SQL (e.g. a `CREATE SCHEMA IF NOT EXISTS` transpiled to
 * the per-tenant target); `splitBundle` owns the bundle mechanics (digests,
 * plan entry, deploy order, dependency re-pointing).
 */
export interface PerTenantBootstrapChange {
    /** Change name/path (e.g. `schemas/tenant_a/schema`). */
    name: string;
    /** Local dependencies of the bootstrap change (default: none). */
    dependencies?: string[];
    /** Raw deploy SQL (or null). */
    deploy: string | null;
    /** Raw revert SQL (or null). */
    revert: string | null;
    /** Raw verify SQL (or null). */
    verify: string | null;
    /**
     * A shared change (unprefixed name) that per-tenant changes currently depend
     * on but should instead depend on this bootstrap. Every per-tenant reference
     * to it — dependency arrays, plan deps, and `-- requires:` headers — is
     * rewritten to this bootstrap's local name.
     */
    replacesShared?: string;
}
/**
 * The two bundles a {@link splitBundle} produces.
 */
export interface SplitBundleResult {
    /** Tenant-independent changes, as their own deployable module. */
    shared: MigrationBundle;
    /**
     * Per-tenant changes, as their own module. Dependencies that pointed at a
     * shared change are rewritten to cross-module references
     * (`<sharedName>:<change>`), and the shared module is added to the control
     * `requires` so it deploys first.
     */
    perTenant: MigrationBundle;
}
/**
 * Split a {@link MigrationBundle} into a shared bundle and a per-tenant bundle
 * along a change-level partition (see `@pgpmjs/slice`).
 *
 * Pure and deterministic (no I/O). The shared changes keep their identity and
 * become a module deployed once; the per-tenant changes become a second module
 * whose references to shared changes are rewritten into cross-module
 * (`<sharedName>:<change>`) dependencies — in both the plan and each script's
 * `-- requires:` header — with the shared module added to its control
 * `requires`. Digests are recomputed so both bundles are independently
 * verifiable.
 *
 * @throws when a per-tenant name is not in the bundle, or when a shared change
 * depends on a per-tenant change (an unsound partition — a shared object must
 * never require tenant-specific state).
 */
export declare function splitBundle(bundle: MigrationBundle, options: SplitBundleOptions): SplitBundleResult;
