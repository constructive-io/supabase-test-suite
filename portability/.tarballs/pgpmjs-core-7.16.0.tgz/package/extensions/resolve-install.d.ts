import { RoleMapping } from '@pgpmjs/types';
import { CompiledExtensionInstall, CompileExtensionInstallOptions } from './compile';
/**
 * Build a grant role-name map (workspace portability profile) from the
 * configured {@link RoleMapping}. Keys are the conceptual role names a module
 * author writes in its manifest (`anonymous`/`authenticated`/`administrator`);
 * values are the actual role names for this database.
 */
export declare function roleMapFromRoles(roles?: RoleMapping): Record<string, string> | undefined;
/**
 * Find a declarative install for an external extension by scanning the resolved
 * local modules for an `extensions.json` that `provides` it, and compiling it.
 *
 * Returns `undefined` when no module declares the extension — the caller then
 * falls back to the legacy `CREATE EXTENSION ... CASCADE` (no schema, no grants).
 * The first declaring module wins; a later contradictory declaration throws.
 */
export declare function findExtensionInstall(extname: string, localModules: string[], modules: Record<string, {
    path: string;
}>, workspacePath: string, options?: CompileExtensionInstallOptions): CompiledExtensionInstall | undefined;
