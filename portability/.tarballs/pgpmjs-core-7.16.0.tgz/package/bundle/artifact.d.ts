import { CreateBundleOptions, MigrationBundle } from '@pgpmjs/bundle';
/**
 * Artifact file name for a module's stored bundle: it lives beside the packaged
 * `sql/<name>--<version>.sql` as `sql/<name>--<version>.bundle.tar.gz`.
 */
export declare function bundleArtifactFileName(name: string, version: string): string;
/**
 * Locate a module's stored bundle artifact, if it has one.
 *
 * Prefers the version declared in the module's `.control` file, then falls back
 * to any single `sql/*.bundle.tar.gz` present — so a module packaged at a
 * different version still gets the fast path instead of silently degrading.
 * Returns `null` when the module ships no artifact.
 */
export declare function resolveBundleArtifactPath(moduleDir: string): string | null;
/**
 * Build the executable form of a module's bundle: the content-addressed AST
 * snapshot plus, per change, the deploy SQL with transaction-control
 * statements stripped (`cleanSql`).
 *
 * That pre-computation is the whole point of the artifact — the parse/deparse
 * work moves from every deploy to the one-time package step, while the digests
 * still cover the exact bytes that will be executed.
 */
export declare function buildExecutableBundle(moduleDir: string, options?: CreateBundleOptions): Promise<MigrationBundle>;
/**
 * Emit a module's stored bundle artifact into `sql/`, returning its path.
 */
export declare function writeBundleArtifact(moduleDir: string, version: string, options?: CreateBundleOptions): Promise<string>;
/**
 * Read a module's stored bundle artifact, or `null` when it has none or the
 * archive cannot be read. Never throws — a broken artifact must degrade to the
 * normal packaging path, not fail the deploy.
 */
export declare function readBundleArtifact(moduleDir: string): MigrationBundle | null;
