import { PgpmRoutingProfile } from '@pgpmjs/types';
import { ResolvedApplySpec } from './types';
/**
 * Load the workspace-level routing profile (the `portability` field of the
 * workspace `pgpm.json` / `pgpm.config.js`). Returns `undefined` when the
 * workspace has no config file or no profile.
 */
export declare function loadWorkspaceRoutingProfile(workspacePath: string): PgpmRoutingProfile | undefined;
/**
 * Resolve the routing profile effective for one apply spec: defaults →
 * workspace `portability` → the spec's own routing keys, merged per key
 * (inner scope wins; see {@link mergeRoutingProfiles}).
 */
export declare function resolveEffectiveApplySpec(spec: ResolvedApplySpec, workspaceProfile?: PgpmRoutingProfile): ResolvedApplySpec;
