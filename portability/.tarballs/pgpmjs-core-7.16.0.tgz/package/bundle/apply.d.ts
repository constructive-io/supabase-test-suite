import { PgConfig } from 'pg-env';
import { PgpmScriptKind } from '@pgpmjs/ast/module/types';
import { BundleIssue, MigrationBundle } from '@pgpmjs/bundle';
import { PgpmMigrateOptions } from '../migrate/client';
import { DeployResult, VerifyResult } from '../migrate/types';
/** A script whose SQL references something outside the allowed namespace. */
export interface NamespaceViolation {
    change: string;
    kind: PgpmScriptKind;
    /** Offending references reported by the caller's validator. */
    references: string[];
}
/**
 * A validator for transpiled bundles: given a script's SQL, return the
 * references that fall *outside* the target namespace (empty = clean). Core
 * stays parser-agnostic; the caller (constructive-db) supplies the AST check.
 */
export type ReferenceValidator = (sql: string, ctx: {
    change: string;
    kind: PgpmScriptKind;
}) => string[];
/** Pre-flight analysis of an apply, computed without touching the database. */
export interface ApplyBundlePreview {
    name: string;
    /** Changes in deploy order. */
    deployOrder: string[];
    /** Digest/order/integrity problems from {@link verifyBundle}. */
    bundleIssues: BundleIssue[];
    /** References outside the target namespace (only when a validator is given). */
    namespaceViolations: NamespaceViolation[];
    /** Reverse deploy order — the revert sequence that fully undoes this apply. */
    rollbackPlan: string[];
}
export interface PreviewBundleApplyOptions {
    validateReferences?: ReferenceValidator;
}
/**
 * Analyze a bundle apply without executing it: verify artifact integrity, run
 * the optional namespace-reference validator, and derive the rollback plan.
 * Pure — no database, no disk.
 */
export declare function previewBundleApply(bundle: MigrationBundle, options?: PreviewBundleApplyOptions): ApplyBundlePreview;
export interface ApplyBundleOptions extends PreviewBundleApplyOptions {
    /** Target database. */
    config: PgConfig;
    /** Analyze only; never touch the database. Default false. */
    dryRun?: boolean;
    /** Run `verify` after a successful deploy. Default false. */
    verify?: boolean;
    /**
     * Wall-clock budget for the deploy (+ optional verify). On expiry the result
     * is flagged `timedOut` and a {@link BundleApplyError} is thrown. The apply
     * runs in a single transaction (see `useTransaction`), so the database rolls
     * back rather than being left half-applied.
     */
    timeoutMs?: number;
    /** Apply as one atomic transaction so any failure rolls back. Default true. */
    useTransaction?: boolean;
    /** Directory to materialize into (default: a temp dir, removed afterward). */
    workDir?: string;
    migrateOptions?: PgpmMigrateOptions;
    /** Apply even if artifact verification fails. Default false (refuse). */
    allowUnverified?: boolean;
}
/** Explicit outcome of an {@link applyBundle} call. */
export interface ApplyBundleResult {
    preview: ApplyBundlePreview;
    dryRun: boolean;
    /** True when the deploy actually ran against the database. */
    executed: boolean;
    deploy?: DeployResult;
    verify?: VerifyResult;
    durationMs: number;
    timedOut: boolean;
}
/** Thrown when an apply is refused pre-flight or exceeds its timeout. */
export declare class BundleApplyError extends Error {
    readonly preview: ApplyBundlePreview;
    readonly timedOut: boolean;
    constructor(message: string, preview: ApplyBundlePreview, timedOut?: boolean);
}
/**
 * Safely apply a {@link MigrationBundle} to a target database.
 *
 * A thin, safety-first wrapper over {@link PgpmMigrate}: it gates on artifact
 * integrity and (optionally) namespace validation, supports a dry run, applies
 * atomically in a single transaction, enforces a timeout, and returns an
 * explicit result including the rollback plan.
 *
 * The mechanics (materialize → deploy → verify) reuse existing plumbing;
 * nothing here re-implements deployment.
 */
export declare function applyBundle(bundle: MigrationBundle, options: ApplyBundleOptions): Promise<ApplyBundleResult>;
