"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bundleArtifactFileName = bundleArtifactFileName;
exports.resolveBundleArtifactPath = resolveBundleArtifactPath;
exports.buildExecutableBundle = buildExecutableBundle;
exports.writeBundleArtifact = writeBundleArtifact;
exports.readBundleArtifact = readBundleArtifact;
const fs_1 = require("fs");
const path_1 = require("path");
const files_1 = require("@pgpmjs/ast/files");
const bundle_1 = require("@pgpmjs/bundle");
const clean_1 = require("../migrate/clean");
/**
 * Artifact file name for a module's stored bundle: it lives beside the packaged
 * `sql/<name>--<version>.sql` as `sql/<name>--<version>.bundle.tar.gz`.
 */
function bundleArtifactFileName(name, version) {
    return `${name}--${version}${bundle_1.BUNDLE_ARCHIVE_EXTENSION}`;
}
/**
 * Locate a module's stored bundle artifact, if it has one.
 *
 * Prefers the version declared in the module's `.control` file, then falls back
 * to any single `sql/*.bundle.tar.gz` present — so a module packaged at a
 * different version still gets the fast path instead of silently degrading.
 * Returns `null` when the module ships no artifact.
 */
function resolveBundleArtifactPath(moduleDir) {
    const sqlDir = (0, path_1.join)(moduleDir, 'sql');
    if (!(0, fs_1.existsSync)(sqlDir))
        return null;
    let name;
    try {
        name = (0, files_1.getExtensionName)(moduleDir);
    }
    catch {
        return null;
    }
    const controlPath = (0, path_1.join)(moduleDir, `${name}.control`);
    if ((0, fs_1.existsSync)(controlPath)) {
        const { version } = (0, files_1.parseControlContent)((0, fs_1.readFileSync)(controlPath, 'utf-8'));
        if (version) {
            const versioned = (0, path_1.join)(sqlDir, bundleArtifactFileName(name, version));
            if ((0, fs_1.existsSync)(versioned))
                return versioned;
        }
    }
    const candidates = (0, fs_1.readdirSync)(sqlDir).filter(file => file.startsWith(`${name}--`) && file.endsWith(bundle_1.BUNDLE_ARCHIVE_EXTENSION));
    if (candidates.length !== 1)
        return null;
    return (0, path_1.join)(sqlDir, candidates[0]);
}
/**
 * Build the executable form of a module's bundle: the content-addressed AST
 * snapshot plus, per change, the deploy SQL with transaction-control
 * statements stripped (`cleanSql`).
 *
 * That pre-computation is the whole point of the artifact — the parse/deparse
 * work moves from every deploy to the one-time package step, while the digests
 * still cover the exact bytes that will be executed.
 */
async function buildExecutableBundle(moduleDir, options) {
    const bundle = (0, bundle_1.bundleFromModule)(moduleDir, options);
    const execSql = {};
    for (const change of bundle.changes) {
        if (!change.deploy)
            continue;
        execSql[change.name] = await (0, clean_1.cleanSql)(change.deploy.sql, false, '$EOFCODE$');
    }
    return (0, bundle_1.withExecutableSql)(bundle, execSql);
}
/**
 * Emit a module's stored bundle artifact into `sql/`, returning its path.
 */
async function writeBundleArtifact(moduleDir, version, options) {
    const bundle = await buildExecutableBundle(moduleDir, options);
    const outPath = (0, path_1.join)(moduleDir, 'sql', bundleArtifactFileName(bundle.manifest.name, version));
    (0, bundle_1.writeBundleArchiveFile)(bundle, outPath);
    return outPath;
}
/**
 * Read a module's stored bundle artifact, or `null` when it has none or the
 * archive cannot be read. Never throws — a broken artifact must degrade to the
 * normal packaging path, not fail the deploy.
 */
function readBundleArtifact(moduleDir) {
    const artifactPath = resolveBundleArtifactPath(moduleDir);
    if (!artifactPath)
        return null;
    try {
        return (0, bundle_1.readBundleArchiveFile)(artifactPath);
    }
    catch {
        return null;
    }
}
