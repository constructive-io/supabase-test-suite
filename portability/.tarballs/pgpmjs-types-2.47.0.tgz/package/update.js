"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UPDATE_PACKAGE_NAME = exports.UPDATE_CHECK_APPSTASH_KEY = exports.UPDATE_CHECK_TTL_MS = void 0;
exports.UPDATE_CHECK_TTL_MS = 24 * 60 * 60 * 1000;
exports.UPDATE_CHECK_APPSTASH_KEY = 'pgpm-update-check';
exports.UPDATE_PACKAGE_NAME = 'pgpm';
