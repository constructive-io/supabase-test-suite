"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeMinimalModule = writeMinimalModule;
exports.writeMinimalWorkspace = writeMinimalWorkspace;
exports.generateModuleControl = generateModuleControl;
exports.generateModuleMakefile = generateModuleMakefile;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const slice_1 = require("@pgpmjs/slice");
const SCRIPT_DIRS = ['deploy', 'revert', 'verify'];
/**
 * The minimal set of files pgpm needs to recognize and deploy a module:
 * `pgpm.plan` (module marker + change order), `<name>.control` (extension
 * metadata), `Makefile` (PGXS packaging), `package.json`, and the
 * deploy/revert/verify scripts. Mirrors what `pgpm init` scaffolds, minus the
 * network-fetched boilerplate (README/LICENSE/jest/tests/lint configs).
 */
function writeMinimalModule(moduleDir, options) {
    const { name, changes, scripts, tags = [], requires = [], version = '0.0.1', license = 'CONSTRUCTIVE', overwrite = false, writePackageJson = true, } = options;
    if (fs_1.default.existsSync(moduleDir) && fs_1.default.readdirSync(moduleDir).length > 0 && !overwrite) {
        throw new Error(`Module directory is not empty: ${moduleDir}. Pass overwrite: true to replace.`);
    }
    for (const dir of SCRIPT_DIRS) {
        fs_1.default.mkdirSync(path_1.default.join(moduleDir, dir), { recursive: true });
    }
    for (const change of changes) {
        const changeScripts = scripts[change.name];
        if (!changeScripts) {
            throw new Error(`Missing scripts for change "${change.name}" in module "${name}"`);
        }
        fs_1.default.writeFileSync(path_1.default.join(moduleDir, 'deploy', `${change.name}.sql`), changeScripts.deploy);
        fs_1.default.writeFileSync(path_1.default.join(moduleDir, 'revert', `${change.name}.sql`), changeScripts.revert);
        fs_1.default.writeFileSync(path_1.default.join(moduleDir, 'verify', `${change.name}.sql`), changeScripts.verify ?? `-- Verify ${change.name}\n\nBEGIN;\n\nSELECT 1;\n\nROLLBACK;\n`);
    }
    fs_1.default.writeFileSync(path_1.default.join(moduleDir, 'pgpm.plan'), (0, slice_1.generatePlanContent)(name, changes, tags));
    fs_1.default.writeFileSync(path_1.default.join(moduleDir, `${name}.control`), generateModuleControl(name, requires, version));
    fs_1.default.writeFileSync(path_1.default.join(moduleDir, 'Makefile'), generateModuleMakefile(name, version));
    if (writePackageJson) {
        fs_1.default.writeFileSync(path_1.default.join(moduleDir, 'package.json'), JSON.stringify({ name, version, description: `${name} module`, license }, null, 2) + '\n');
    }
}
/**
 * Write the minimal workspace marker (`pgpm.json`) so pgpm discovers the
 * directory as a workspace. This is what `getWorkspacePath` walks up to find.
 */
function writeMinimalWorkspace(workspaceDir, options = {}) {
    const { packages = ['packages/*'], overwrite = true } = options;
    const configPath = path_1.default.join(workspaceDir, 'pgpm.json');
    if (fs_1.default.existsSync(configPath) && !overwrite)
        return;
    fs_1.default.mkdirSync(workspaceDir, { recursive: true });
    fs_1.default.writeFileSync(configPath, JSON.stringify({ packages }, null, 2) + '\n');
}
/**
 * Full extension control file, matching the shape `pgpm init` emits (comment,
 * default_version, module_pathname, requires, relocatable, superuser).
 */
function generateModuleControl(name, requires = [], version = '0.0.1') {
    let content = `# ${name} extension\n`;
    content += `comment = '${name} extension'\n`;
    content += `default_version = '${version}'\n`;
    content += `module_pathname = '$libdir/${name}'\n`;
    if (requires.length > 0) {
        content += `requires = '${requires.join(',')}'\n`;
    }
    content += `relocatable = false\n`;
    content += `superuser = false\n`;
    return content;
}
/**
 * PGXS Makefile for `pgpm package`/`make install`.
 */
function generateModuleMakefile(name, version = '0.0.1') {
    return (`EXTENSION = ${name}\n` +
        `DATA = sql/${name}--${version}.sql\n\n` +
        `PG_CONFIG = pg_config\n` +
        `PGXS := $(shell $(PG_CONFIG) --pgxs)\n` +
        `include $(PGXS)\n`);
}
