import { ExtendedPlanFile } from '@pgpmjs/ast/files/types';
/**
 * Represents a dependency graph where keys are module identifiers
 * and values are arrays of their direct dependencies
 */
interface DependencyGraph {
    [key: string]: string[];
}
/**
 * Result object returned by dependency resolution functions
 */
export interface DependencyResult {
    /** Array of external dependencies that are not part of the current package */
    external: string[];
    /** Array of modules in topologically sorted order for deployment */
    resolved: string[];
    /** The complete dependency graph mapping modules to their dependencies */
    deps: DependencyGraph;
    /** Mapping of resolved tags to their target changes (only for resolveDependencies) */
    resolvedTags?: Record<string, string>;
}
/**
 * Resolves dependencies for extension modules using a pre-built module map.
 * This is a simpler version that works with module metadata rather than parsing SQL files.
 *
 * @param name - The name of the module to resolve dependencies for
 * @param modules - Record mapping module names to their dependency requirements
 * @returns Object containing external dependencies and resolved dependency order
 */
export declare const resolveExtensionDependencies: (name: string, modules: Record<string, {
    requires: string[];
}>) => {
    external: string[];
    resolved: string[];
};
export interface DependencyResolutionOptions {
    /**
     * How to handle tag references:
     * - 'preserve': Keep tags as-is, as changes in plan files
     * - 'resolve': Resolve tags to their target changes
     * - 'internal': Resolve internally but preserve in output
     */
    tagResolution?: 'preserve' | 'resolve' | 'internal';
    /**
     * Whether to load and parse plan files for tag resolution
     * Only applicable when tagResolution is 'resolve' or 'internal'
     */
    loadPlanFiles?: boolean;
    /**
     * Custom plan file loader function
     * Allows overriding the default plan file loading logic
     */
    planFileLoader?: (projectName: string, currentProject: string, packageDir: string) => ExtendedPlanFile | null;
    source?: 'sql' | 'plan';
}
export declare const resolveDependencies: (packageDir: string, extname: string, options?: DependencyResolutionOptions) => DependencyResult;
export {};
