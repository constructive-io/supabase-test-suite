"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.readBoilerplatesConfig = readBoilerplatesConfig;
exports.readBoilerplateConfig = readBoilerplateConfig;
exports.scanBoilerplates = scanBoilerplates;
exports.findBoilerplateByType = findBoilerplateByType;
exports.resolveBoilerplateBaseDir = resolveBoilerplateBaseDir;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Read the root `.boilerplates.json` configuration from a template repository.
 * This file specifies the default directory containing boilerplate templates.
 *
 * @param templateDir - The root directory of the template repository
 * @returns The root config or null if not found
 */
function readBoilerplatesConfig(templateDir) {
    const configPath = path_1.default.join(templateDir, '.boilerplates.json');
    if (fs_1.default.existsSync(configPath)) {
        try {
            const content = fs_1.default.readFileSync(configPath, 'utf-8');
            return JSON.parse(content);
        }
        catch {
            return null;
        }
    }
    return null;
}
/**
 * Read the `.boilerplate.json` configuration from a boilerplate directory.
 * This file specifies the boilerplate type and questions.
 *
 * @param boilerplatePath - The path to the boilerplate directory
 * @returns The boilerplate config or null if not found
 */
function readBoilerplateConfig(boilerplatePath) {
    const jsonPath = path_1.default.join(boilerplatePath, '.boilerplate.json');
    if (fs_1.default.existsSync(jsonPath)) {
        try {
            const content = fs_1.default.readFileSync(jsonPath, 'utf-8');
            return JSON.parse(content);
        }
        catch {
            return null;
        }
    }
    return null;
}
/**
 * Scan a base directory for boilerplate templates.
 * Each subdirectory with a `.boilerplate.json` file is considered a boilerplate.
 *
 * @param baseDir - The directory to scan (e.g., "default/")
 * @returns Array of scanned boilerplates with their configurations
 */
function scanBoilerplates(baseDir) {
    const boilerplates = [];
    if (!fs_1.default.existsSync(baseDir)) {
        return boilerplates;
    }
    const entries = fs_1.default.readdirSync(baseDir, { withFileTypes: true });
    for (const entry of entries) {
        if (!entry.isDirectory()) {
            continue;
        }
        const boilerplatePath = path_1.default.join(baseDir, entry.name);
        const config = readBoilerplateConfig(boilerplatePath);
        if (config) {
            // Validate and normalize the type field
            const validTypes = ['workspace', 'module', 'generic'];
            const configType = config.type;
            const type = validTypes.includes(configType)
                ? configType
                : 'module';
            // Validate and normalize requiresWorkspace field
            const validWorkspaceTypes = ['pgpm', 'pnpm', 'lerna', 'npm'];
            let requiresWorkspace;
            if (config.requiresWorkspace === false) {
                requiresWorkspace = false;
            }
            else if (typeof config.requiresWorkspace === 'string' &&
                validWorkspaceTypes.includes(config.requiresWorkspace)) {
                requiresWorkspace = config.requiresWorkspace;
            }
            else {
                // Default: 'pgpm' for module type (backward compatibility), undefined for others
                requiresWorkspace = type === 'module' ? 'pgpm' : undefined;
            }
            boilerplates.push({
                name: entry.name,
                path: boilerplatePath,
                type,
                requiresWorkspace,
                questions: config.questions
            });
        }
    }
    return boilerplates;
}
/**
 * Find a boilerplate by type within a scanned list.
 *
 * @param boilerplates - Array of scanned boilerplates
 * @param type - The type to find ('workspace' or 'module')
 * @returns The matching boilerplate or undefined
 */
function findBoilerplateByType(boilerplates, type) {
    return boilerplates.find((bp) => bp.type === type);
}
/**
 * Resolve the base directory for boilerplates in a template repository.
 * Uses `.boilerplates.json` if present, otherwise returns empty string.
 *
 * @param templateDir - The root directory of the template repository
 * @returns The resolved base directory path
 */
function resolveBoilerplateBaseDir(templateDir) {
    const rootConfig = readBoilerplatesConfig(templateDir);
    if (rootConfig?.dir) {
        return path_1.default.join(templateDir, rootConfig.dir);
    }
    return templateDir;
}
