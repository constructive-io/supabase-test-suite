"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.writePackage = exports.packageModule = exports.mergeSqlStatements = exports.cleanTree = void 0;
const logger_1 = require("@pgpmjs/logger");
const fs_1 = require("fs");
const path_1 = require("path");
const pgsql_deparser_1 = require("pgsql-deparser");
const pgsql_parser_1 = require("pgsql-parser");
const files_1 = require("@pgpmjs/ast/files");
const artifact_1 = require("../bundle/artifact");
const resolve_1 = require("../resolution/resolve");
const transform_1 = require("./transform");
const log = new logger_1.Logger('package');
const noop = () => undefined;
const cleanTree = (tree) => {
    return (0, transform_1.transformProps)(tree, {
        stmt_len: noop,
        stmt_location: noop,
        location: noop,
    });
};
exports.cleanTree = cleanTree;
const filterStatements = (stmts, stripTransactions) => {
    if (!stripTransactions)
        return stmts;
    return stmts.filter(node => {
        const stmt = node.stmt;
        return !stmt.hasOwnProperty('TransactionStmt') &&
            !stmt.hasOwnProperty('CreateExtensionStmt');
    });
};
/**
 * Merge a concatenated SQL string into a single deparsed script.
 *
 * Parses the input, optionally strips transaction/extension statements, deparses
 * with a stable function delimiter, and round-trips the result to detect any AST
 * drift. This is the shared engine behind `packageModule` (whole-module packaging)
 * and per-chunk rebundling — both must merge statements identically.
 */
const mergeSqlStatements = async (sql, { stripTransactions = false, echoExtensionName, pretty = true, functionDelimiter = '$EOFCODE$' } = {}) => {
    if (!sql?.trim()) {
        return { sql: '' };
    }
    const parsed = await (0, pgsql_parser_1.parse)(sql);
    parsed.stmts = filterStatements(parsed.stmts, stripTransactions);
    const topLine = echoExtensionName
        ? `\\echo Use "CREATE EXTENSION ${echoExtensionName}" to load this file. \\quit\n`
        : '';
    const finalSql = await (0, pgsql_deparser_1.deparse)(parsed, { pretty, functionDelimiter });
    const tree1 = parsed.stmts;
    const reparsed = await (0, pgsql_parser_1.parse)(finalSql);
    const tree2 = filterStatements(reparsed.stmts, stripTransactions);
    const results = {
        sql: `${topLine}${finalSql}`,
    };
    const diff = JSON.stringify((0, exports.cleanTree)(tree1)) !== JSON.stringify((0, exports.cleanTree)(tree2));
    if (diff) {
        results.diff = true;
        results.tree1 = JSON.stringify((0, exports.cleanTree)(tree1), null, 2);
        results.tree2 = JSON.stringify((0, exports.cleanTree)(tree2), null, 2);
    }
    return results;
};
exports.mergeSqlStatements = mergeSqlStatements;
const packageModule = async (packageDir, { usePlan = true, extension = true, pretty = true, functionDelimiter = '$EOFCODE$' } = {}) => {
    const resolveFn = usePlan ? resolve_1.resolveWithPlan : resolve_1.resolve;
    const sql = resolveFn(packageDir);
    if (!sql?.trim()) {
        log.warn(`⚠️ No SQL generated for module at ${packageDir}. Skipping.`);
        return { sql: '' };
    }
    const extname = (0, files_1.getExtensionName)(packageDir);
    try {
        return await (0, exports.mergeSqlStatements)(sql, {
            stripTransactions: extension,
            echoExtensionName: extension ? extname : undefined,
            pretty,
            functionDelimiter,
        });
    }
    catch (e) {
        log.error(`❌ Failed to parse SQL for ${packageDir}`);
        console.error(e);
        throw e;
    }
};
exports.packageModule = packageModule;
const writePackage = async ({ version, extension = true, usePlan = true, packageDir, outputDiff = false, bundle = true, }) => {
    const pkgPath = `${packageDir}/package.json`;
    const pkg = require(pkgPath);
    const extname = await (0, files_1.getExtensionName)(packageDir);
    const makePath = `${packageDir}/Makefile`;
    const controlPath = `${packageDir}/${extname}.control`;
    const sqlFileName = `${extname}--${version}.sql`;
    const Makefile = (0, fs_1.readFileSync)(makePath, 'utf-8');
    const control = (0, fs_1.readFileSync)(controlPath, 'utf-8');
    const { sql, diff, tree1, tree2 } = await (0, exports.packageModule)(packageDir, {
        extension,
        usePlan,
        outputDiff,
    });
    const outPath = extension ? `${packageDir}/sql` : `${packageDir}/out`;
    (0, fs_1.rmSync)(outPath, { recursive: true, force: true });
    (0, fs_1.mkdirSync)(outPath, { recursive: true });
    if (extension) {
        (0, fs_1.writeFileSync)(controlPath, control.replace(/default_version = '[0-9\.]+'/, `default_version = '${version}'`));
        pkg.version = version;
        (0, fs_1.writeFileSync)(pkgPath, JSON.stringify(pkg, null, 2) + '\n');
        const regex = new RegExp(`${extname}--[0-9.]+.sql`);
        (0, fs_1.writeFileSync)(makePath, Makefile.replace(regex, sqlFileName));
    }
    if (diff) {
        if (outputDiff) {
            (0, fs_1.writeFileSync)(`${outPath}/orig.${sqlFileName}.tree.json`, tree1);
            (0, fs_1.writeFileSync)(`${outPath}/parsed.${sqlFileName}.tree.json`, tree2);
            log.warn(`⚠️ AST round-trip diff detected! Diff files written to ${(0, path_1.relative)(packageDir, outPath)}/`);
        }
        else {
            log.warn(`⚠️ AST round-trip diff detected! Run with --outputDiff to export the AST diff files.`);
        }
    }
    const writePath = `${outPath}/${sqlFileName}`;
    (0, fs_1.writeFileSync)(writePath, sql);
    log.success(`${(0, path_1.relative)(packageDir, writePath)} written`);
    if (bundle) {
        const bundlePath = await (0, artifact_1.writeBundleArtifact)(packageDir, version, {
            createdWith: '@pgpmjs/core'
        });
        log.success(`${(0, path_1.relative)(packageDir, bundlePath)} written`);
    }
};
exports.writePackage = writePackage;
