/**
 * Convert a native filesystem path to a posix-style path.
 * Windows path separators are not valid inside glob patterns.
 */
export declare const toPosixPath: (p: string) => string;
/**
 * Join path segments into a glob pattern.
 *
 * `glob` treats `\` as an escape character on every platform, so a Windows
 * path produced by `path.join` silently matches nothing. Patterns must always
 * use forward slashes, which Windows accepts as a separator.
 */
export declare const globPattern: (...segments: string[]) => string;
/**
 * Cross-platform `glob.sync` over path segments joined into a pattern.
 */
export declare const globPaths: (...segments: string[]) => string[];
