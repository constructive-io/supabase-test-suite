"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.excludeSubsystem = excludeSubsystem;
exports.blankScriptSql = blankScriptSql;
exports.stripSubsystemSql = stripSubsystemSql;
const transform_1 = require("@pgpmjs/transform");
const plpgsql_parser_1 = require("plpgsql-parser");
function inSubsystem(ref, schemas) {
    return ref.schema !== null && schemas.has(ref.schema);
}
function refKey(ref) {
    return `${ref.schema ?? ''}.${ref.name}`;
}
function pushUnique(list, ref) {
    if (!list.some(x => x.schema === ref.schema && x.name === ref.name))
        list.push(ref);
}
/**
 * The classifier does not tag a reference with its namespace, so resolution
 * tries each object namespace (FK targets are known to be relations) before
 * falling back to the schema-level default.
 */
function resolveRebind(router, ref, fk) {
    if (!router)
        return false;
    const namespaces = fk
        ? ['relation']
        : ['function', 'relation', 'type', 'unknown'];
    for (const ns of namespaces) {
        const target = router.resolveObject(ref.schema, ref.name, ns);
        if (target !== undefined && (target.name !== undefined || target.schema !== undefined)) {
            return true;
        }
    }
    return false;
}
/**
 * Decide statement membership: a statement belongs to the subsystem when
 * everything it creates/targets is inside it, or (creating nothing) when all
 * of its references point inside it (GRANTs on subsystem objects).
 */
function classifyMembership(facts, schemas) {
    if (facts.kind === 'schema') {
        const created = facts.creates[0];
        return created && schemas.has(created.name) ? 'inside' : 'outside';
    }
    if (facts.creates.length > 0) {
        const inside = facts.creates.filter(c => inSubsystem(c, schemas)).length;
        if (inside === facts.creates.length)
            return 'inside';
        if (inside === 0)
            return 'outside';
        return 'mixed';
    }
    const refs = [...facts.references, ...facts.bodyReferences];
    if (refs.length > 0) {
        return refs.every(r => inSubsystem(r, schemas)) ? 'inside' : 'outside';
    }
    // No creates, no visible references: COMMENT ON, bare DROP, SET, ...
    return 'opaque';
}
/**
 * Partition a SQL script into a subsystem (statements to exclude) and its
 * survivors, measure the subsystem's external contract, and verify that a
 * routing profile rebinds every surviving reference into it.
 *
 * Pure and I/O-free. The caller applies the actual removal/rewrite (e.g. via
 * `transpileBundle`'s `transformScript` with the same router); this function
 * only *decides* and *checks* — exclusion is safe iff `unsatisfied` is empty.
 */
function excludeSubsystem(sql, selector, options = {}) {
    const schemas = new Set(selector.schemas);
    const statements = (0, transform_1.classifyStatements)(sql);
    const router = options.rebinds;
    const excluded = [];
    const kept = [];
    const warnings = [];
    const provides = [];
    const internal = [];
    const required = new Map();
    const unsatisfied = [];
    statements.forEach((facts, i) => {
        const membership = classifyMembership(facts, schemas);
        if (membership === 'inside') {
            excluded.push(i);
            for (const c of facts.creates) {
                if (inSubsystem(c, schemas))
                    pushUnique(provides, { schema: c.schema, name: c.name });
            }
            return;
        }
        kept.push(i);
        if (membership === 'mixed') {
            warnings.push({
                kind: 'mixed-statement',
                statement: i,
                detail: `creates objects both inside and outside the subsystem: ${facts.creates
                    .map(refKey)
                    .join(', ')}`
            });
        }
        else if (membership === 'opaque') {
            warnings.push({
                kind: 'opaque-statement',
                statement: i,
                detail: `${facts.nodeTag} target is not classified; verify it does not reference the subsystem`
            });
        }
        if (facts.dynamicSql) {
            warnings.push({
                kind: 'dynamic-sql',
                statement: i,
                detail: 'kept statement executes dynamic SQL; references inside it are unchecked'
            });
        }
        const refs = new Map();
        for (const r of [...facts.references, ...facts.bodyReferences]) {
            if (inSubsystem(r, schemas))
                refs.set(refKey(r), { ref: r, fk: refs.get(refKey(r))?.fk ?? false });
        }
        for (const t of facts.fkTargets) {
            if (inSubsystem(t, schemas))
                refs.set(refKey(t), { ref: t, fk: true });
        }
        for (const { ref, fk } of refs.values()) {
            const key = refKey(ref);
            const dep = required.get(key) ?? { object: { schema: ref.schema, name: ref.name }, fk: false, dependents: [] };
            dep.fk = dep.fk || fk;
            if (!dep.dependents.includes(i))
                dep.dependents.push(i);
            required.set(key, dep);
            const rebound = resolveRebind(router, ref, fk);
            if (!rebound && !unsatisfied.some(u => refKey(u.object) === key && u.statement === i)) {
                unsatisfied.push({ object: { schema: ref.schema, name: ref.name }, statement: i, fk });
            }
        }
    });
    for (const p of provides) {
        if (!required.has(refKey(p)))
            pushUnique(internal, p);
    }
    return {
        excluded,
        kept,
        contract: {
            provides,
            required: [...required.values()],
            internal
        },
        unsatisfied,
        warnings,
        statements
    };
}
/**
 * Blank a script: keep its leading text (pgpm header) and transaction
 * statements, drop everything else. Used for the scripts of a change whose
 * deploy is entirely inside an excluded subsystem — its verify/revert bodies
 * target dropped objects, so they must go with it.
 */
function blankScriptSql(sql) {
    const parsed = (0, plpgsql_parser_1.parseSql)(sql);
    const prefix = parsed.stmts.length > 0 ? sql.slice(0, parsed.stmts[0].stmt_location ?? 0) : sql;
    const pieces = [];
    for (const s of parsed.stmts) {
        if (!('TransactionStmt' in s.stmt))
            continue;
        const start = s.stmt_location ?? 0;
        const len = s.stmt_len ?? sql.length - start;
        pieces.push(sql.slice(start, start + len).trim() + ';');
    }
    return prefix + pieces.join('\n\n') + (pieces.length > 0 ? '\n' : '');
}
/** Qualified name (`[schema, name]` items) from a raw parse-tree name list. */
function qualifiedName(node) {
    const items = node?.List
        ?.items;
    if (!items)
        return undefined;
    const parts = items.map(x => x.String?.sval).filter((s) => typeof s === 'string');
    if (parts.length === 2)
        return { schema: parts[0], name: parts[1] };
    if (parts.length === 1)
        return { schema: null, name: parts[0] };
    return undefined;
}
/**
 * Whether an opaque statement (invisible to classification) provably targets
 * only subsystem objects, so it can be removed along with them: bare `DROP`
 * of subsystem objects, `COMMENT ON` a subsystem object.
 */
function opaqueTargetsSubsystem(stmt, schemas) {
    if (stmt.DropStmt?.objects) {
        const objects = stmt.DropStmt.objects;
        const refs = objects.map(qualifiedName);
        return refs.length > 0 && refs.every(r => r !== undefined && inSubsystem(r, schemas));
    }
    if (stmt.CommentStmt?.object) {
        const ref = qualifiedName(stmt.CommentStmt.object);
        return ref !== undefined && inSubsystem(ref, schemas);
    }
    return false;
}
/**
 * Remove a subsystem's statements from a SQL script, preserving the original
 * text of every survivor (no reformat — statements are sliced out of the
 * source by parser-reported location). Also removes opaque statements that
 * provably target only subsystem objects (`DROP`/`COMMENT ON` them), which
 * membership classification alone keeps.
 *
 * Requires `await loadModule()` first (same as every other sync API here).
 * This performs no safety check by itself — callers decide what to do with
 * `result.unsatisfied` (typically: refuse before ever writing output).
 */
function stripSubsystemSql(sql, selector, options = {}) {
    const result = excludeSubsystem(sql, selector, options);
    const schemas = new Set(selector.schemas);
    const parsed = (0, plpgsql_parser_1.parseSql)(sql);
    if (parsed.stmts.length !== result.statements.length) {
        throw new Error(`stripSubsystemSql: parser saw ${parsed.stmts.length} statements but the classifier saw ` +
            `${result.statements.length}; refusing to slice by index`);
    }
    const drop = new Set(result.excluded);
    for (const i of result.kept) {
        if (opaqueTargetsSubsystem(parsed.stmts[i].stmt, schemas))
            drop.add(i);
    }
    // Text before the first statement (pgpm headers, leading comments) is
    // preserved verbatim so script identity headers survive the strip.
    const prefix = parsed.stmts.length > 0 ? sql.slice(0, parsed.stmts[0].stmt_location ?? 0) : sql;
    const pieces = [];
    parsed.stmts.forEach((s, i) => {
        if (drop.has(i))
            return;
        const start = s.stmt_location ?? 0;
        const len = s.stmt_len ?? sql.length - start;
        pieces.push(sql.slice(start, start + len).trim() + ';');
    });
    return {
        sql: prefix + pieces.join('\n\n') + (pieces.length > 0 ? '\n' : ''),
        result,
        dropped: [...drop].sort((a, b) => a - b)
    };
}
