"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TIER_PROFILE = void 0;
exports.categorizeChange = categorizeChange;
exports.buildCategoryOf = buildCategoryOf;
const transform_1 = require("@pgsql/transform");
/**
 * Default tier profile: isolates the security surface and procedural code out
 * of the schema base. Precedence, highest first — a change is placed in the
 * most specialized tier any of its statements reaches:
 *
 *   security       any securityRelevant statement (policy/grant/RLS/role/owner)
 *   functionality  functions and triggers
 *   fixtures       seed DML (INSERT/UPDATE/DELETE)
 *   schema         schemas, tables, views, indexes, types, constraints (base)
 *
 * Ordering/dependencies across the resulting chunks are still resolved by
 * core's rebundle graph, so this only decides *naming/grouping*, never deploy
 * order.
 */
exports.TIER_PROFILE = {
    name: 'tier',
    categorize(facts) {
        if (facts.length === 0)
            return 'schema';
        if (facts.some(f => f.securityRelevant))
            return 'security';
        if (facts.some(f => f.kind === 'function' || f.kind === 'trigger'))
            return 'functionality';
        if (facts.some(f => f.kind === 'seed_dml'))
            return 'fixtures';
        return 'schema';
    },
};
/**
 * Classify a single change's deploy SQL into its category under `profile`
 * (defaults to {@link TIER_PROFILE}).
 */
function categorizeChange(sql, changeName, profile = exports.TIER_PROFILE) {
    return profile.categorize((0, transform_1.classifyStatements)(sql), changeName);
}
/**
 * Build a `categoryOf(changeName)` seam function from a map of change name to
 * its deploy SQL — ready to pass straight to `@pgpmjs/core`'s rebundle
 * `boundary: 'category'` / `categoryOf` options.
 *
 * Changes absent from `changeSql` return `undefined`, letting core fall back to
 * its folder key for anything the classifier did not see.
 */
function buildCategoryOf(changeSql, profile = exports.TIER_PROFILE) {
    const categories = new Map();
    for (const [name, sql] of Object.entries(changeSql)) {
        categories.set(name, categorizeChange(sql, name, profile));
    }
    return (changeName) => categories.get(changeName);
}
