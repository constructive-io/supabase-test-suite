import { RebundleWorkspaceOptions, RebundleWorkspaceResult } from './types';
/**
 * Materialize a rebundled workspace: emit each chunk as its own tiny module
 * (one merged change) under `packages/<chunk>/`, carrying cross-chunk deps via
 * the control-file `requires` (and optionally a plan cross-reference).
 *
 * This is the "modular workspace" carve — the same monolith sliced into
 * independently publishable module forks (e.g. a users module, an admin module).
 * The emitted directory is a real, discoverable pgpm workspace: it reuses
 * `writeMinimalWorkspace`/`writeMinimalModule` (the minimal deployable file set
 * pgpm recognizes — `pgpm.json`, `pgpm.plan`, `<name>.control`, `Makefile`,
 * `package.json`), `rebundlePlan` for the chunk model, and `mergeChunkScript`
 * for the per-chunk merge.
 */
export declare function rebundleWorkspace(sourceDir: string, options: RebundleWorkspaceOptions): Promise<RebundleWorkspaceResult>;
