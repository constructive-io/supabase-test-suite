import { renameInPlanContent } from '@pgpmjs/ast/plan-rename';
export { renameInPlanContent };
/**
 * Options for {@link renameChanges}.
 */
export interface RenameChangesOptions {
    /** Report planned operations without touching the filesystem. Default: false */
    dryRun?: boolean;
}
/**
 * Result of a {@link renameChanges} run.
 */
export interface RenameChangesResult {
    /** deploy/revert/verify script files moved (old path -> new path, module-relative). */
    filesMoved: Array<{
        from: string;
        to: string;
    }>;
    /** Script files whose headers were rewritten (identity and/or requires). */
    headersRewritten: string[];
    /** Whether pgpm.plan was rewritten. */
    planRewritten: boolean;
    /** Dry-run report lines (only populated when dryRun). */
    dryRunReport?: string[];
}
/**
 * Validate a rename map against a module directory: every source change must
 * exist in the plan, no target may collide with an existing change, and no
 * two sources may map to the same target.
 *
 * @throws on any violation.
 */
export declare function validateRenames(moduleDir: string, renames: Map<string, string>): void;
/**
 * Atomically rename/move changes within a pgpm module: the coupled 4-way
 * rewrite of (1) deploy/revert/verify script files on disk, (2) the moved
 * scripts' own header identity, (3) `-- requires:` headers in every script
 * that references a renamed change, and (4) the pgpm.plan.
 *
 * SQL statement bodies are NOT touched: schema-name rewrites inside SQL are a
 * separate AST-level concern for callers to compose (e.g. transform passes).
 */
export declare function renameChanges(moduleDir: string, renames: Map<string, string>, options?: RenameChangesOptions): RenameChangesResult;
/**
 * Derive a change rename map from a schema mapping (old schema name -> new
 * schema name) by rewriting the `schemas/<name>/` path segment of every plan
 * change that lives under a renamed schema.
 *
 * This is the module-level counterpart of directory-based schema renames:
 * `schemas/my-app/tables/users` with mapping `my-app -> my_app` yields
 * `schemas/my_app/tables/users`.
 */
export declare function deriveRenamesFromSchemaMapping(moduleDir: string, schemaMapping: Map<string, string>): Map<string, string>;
