"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.splitBundle = splitBundle;
const ast_1 = require("@pgpmjs/ast");
const parser_1 = require("@pgpmjs/ast/files/plan/parser");
const writer_1 = require("@pgpmjs/ast/files/plan/writer");
const header_1 = require("@pgpmjs/ast/files/sql/header");
const create_1 = require("./create");
/**
 * Split a {@link MigrationBundle} into a shared bundle and a per-tenant bundle
 * along a change-level partition (see `@pgpmjs/slice`).
 *
 * Pure and deterministic (no I/O). The shared changes keep their identity and
 * become a module deployed once; the per-tenant changes become a second module
 * whose references to shared changes are rewritten into cross-module
 * (`<sharedName>:<change>`) dependencies — in both the plan and each script's
 * `-- requires:` header — with the shared module added to its control
 * `requires`. Digests are recomputed so both bundles are independently
 * verifiable.
 *
 * @throws when a per-tenant name is not in the bundle, or when a shared change
 * depends on a per-tenant change (an unsound partition — a shared object must
 * never require tenant-specific state).
 */
function splitBundle(bundle, options) {
    const perTenant = new Set(options.perTenantChanges);
    const names = new Set(bundle.changes.map(c => c.name));
    for (const name of perTenant) {
        if (!names.has(name)) {
            throw new Error(`splitBundle: per-tenant change "${name}" is not in the bundle`);
        }
    }
    const isShared = (name) => !perTenant.has(name);
    for (const change of bundle.changes) {
        if (!isShared(change.name))
            continue;
        for (const dep of change.dependencies) {
            if (perTenant.has(dep)) {
                throw new Error(`splitBundle: shared change "${change.name}" depends on per-tenant change "${dep}"; ` +
                    `a shared object cannot require tenant-specific state (unsound partition)`);
            }
        }
    }
    const bootstrap = options.perTenantBootstrap ?? [];
    for (const b of bootstrap) {
        if (names.has(b.name)) {
            throw new Error(`splitBundle: bootstrap change "${b.name}" collides with an existing bundle change`);
        }
        if (b.replacesShared !== undefined && !isShared(b.replacesShared)) {
            throw new Error(`splitBundle: bootstrap "${b.name}" replaces "${b.replacesShared}", which is not a shared change`);
        }
    }
    const shared = buildSubBundle(bundle, isShared, options.sharedName, null);
    const perTenantBundle = buildSubBundle(bundle, name => perTenant.has(name), options.perTenantName, { sharedName: options.sharedName, isShared, bootstrap });
    return { shared, perTenant: perTenantBundle };
}
/** Build a {@link BundleChange} from raw bootstrap SQL, computing digests. */
function bootstrapToChange(b) {
    const toScript = (kind, sql) => sql === null ? null : { kind, sql, digest: (0, ast_1.hashString)(sql) };
    const deploy = toScript('deploy', b.deploy);
    const revert = toScript('revert', b.revert);
    const verify = toScript('verify', b.verify);
    return {
        name: b.name,
        dependencies: b.dependencies ?? [],
        deploy,
        revert,
        verify,
        digest: (0, create_1.computeChangeDigest)(b.name, {
            deploy: deploy?.digest,
            revert: revert?.digest,
            verify: verify?.digest
        })
    };
}
/** Build one side of the split: the changes matching `include`, as a module. */
function buildSubBundle(bundle, include, moduleName, cross) {
    // One rename map for both dependency arrays and `-- requires:` headers on the
    // per-tenant side: a reference to a shared change becomes a cross-module
    // reference `<sharedName>:<change>`, except a change a bootstrap replaces,
    // which is re-pointed at the (local) bootstrap instead.
    const renameMap = cross ? buildRenameMap(bundle, cross) : null;
    const rewriteScript = (script) => {
        if (!script)
            return null;
        if (!renameMap || renameMap.size === 0)
            return script;
        const parsed = (0, header_1.parsePgpmHeader)(script.sql);
        if ((0, header_1.renameInHeader)(parsed, renameMap) === 0)
            return script;
        const sql = (0, header_1.writePgpmScript)(parsed);
        return { kind: script.kind, sql, digest: (0, ast_1.hashString)(sql) };
    };
    const changes = bundle.changes
        .filter(c => include(c.name))
        .map(change => {
        const dependencies = change.dependencies.map(dep => renameMap?.get(dep) ?? dep);
        const deploy = rewriteScript(change.deploy);
        const revert = rewriteScript(change.revert);
        const verify = rewriteScript(change.verify);
        const digest = (0, create_1.computeChangeDigest)(change.name, {
            deploy: deploy?.digest,
            revert: revert?.digest,
            verify: verify?.digest
        });
        return { name: change.name, dependencies, deploy, revert, verify, digest };
    });
    // Bootstrap changes deploy before the tenant's own changes.
    const bootstrapChanges = (cross?.bootstrap ?? []).map(bootstrapToChange);
    const allChanges = [...bootstrapChanges, ...changes];
    const plan = buildPlan(bundle.plan, moduleName, include, renameMap, bootstrapChanges);
    let control = bundle.control
        ? { fileName: `${moduleName}.control`, content: bundle.control.content }
        : null;
    if (control && cross) {
        control = { fileName: control.fileName, content: addControlRequire(control.content, cross.sharedName) };
    }
    const digest = (0, create_1.computeBundleDigest)(plan, control?.content ?? null, allChanges.map(c => c.digest));
    return {
        manifest: {
            formatVersion: bundle.manifest.formatVersion,
            name: moduleName,
            createdWith: bundle.manifest.createdWith,
            changeCount: allChanges.length,
            deployOrder: allChanges.map(c => c.name),
            digest,
            provenance: {
                ...(bundle.manifest.provenance ?? {}),
                splitFrom: bundle.manifest.name
            }
        },
        plan,
        control,
        changes: allChanges
    };
}
/**
 * Build the per-tenant reference-rewrite map: every shared change → its
 * cross-module reference, then bootstrap `replacesShared` overrides → the
 * bootstrap's local name (so a per-tenant object depends on its own schema).
 */
function buildRenameMap(bundle, cross) {
    const map = new Map();
    for (const c of bundle.changes) {
        if (cross.isShared(c.name))
            map.set(c.name, `${cross.sharedName}:${c.name}`);
    }
    for (const b of cross.bootstrap) {
        if (b.replacesShared !== undefined)
            map.set(b.replacesShared, b.name);
    }
    return map;
}
/**
 * Rebuild a plan for one side of the split: keep only the included changes (and
 * their tags), rewrite the project identity, and cross-reference shared
 * dependencies for the per-tenant side.
 */
function buildPlan(planContent, moduleName, include, renameMap, bootstrapChanges) {
    const parsed = (0, parser_1.parsePlanContent)(planContent);
    if (!parsed.data) {
        const detail = parsed.errors?.map(e => `Line ${e.line}: ${e.message}`).join('; ') || 'unknown';
        throw new Error(`splitBundle: could not parse source plan: ${detail}`);
    }
    const source = parsed.data;
    const bootstrapPlan = bootstrapChanges.map(b => ({
        name: b.name,
        dependencies: b.dependencies
    }));
    const changes = source.changes
        .filter(c => include(c.name))
        .map(c => ({
        ...c,
        dependencies: (c.dependencies ?? []).map(dep => renameMap?.get(dep) ?? dep)
    }));
    const allChanges = [...bootstrapPlan, ...changes];
    const kept = new Set(allChanges.map(c => c.name));
    const tags = source.tags.filter(t => kept.has(t.change));
    const plan = {
        ...source,
        package: moduleName,
        uri: moduleName,
        changes: allChanges,
        tags
    };
    return (0, writer_1.generatePlanFileContent)(plan);
}
/**
 * Add a module to a `.control` file's comma-separated `requires`, creating the
 * line when absent. Idempotent — an already-present requirement is left alone.
 */
function addControlRequire(content, requireName) {
    const lines = content.split('\n');
    const idx = lines.findIndex(l => /^\s*requires\s*=/.test(l));
    if (idx === -1) {
        return `${content.replace(/\n?$/, '\n')}requires = '${requireName}'\n`;
    }
    const match = lines[idx].match(/^(\s*requires\s*=\s*')([^']*)(')(.*)$/);
    if (!match)
        return content;
    const existing = match[2]
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);
    if (existing.includes(requireName))
        return content;
    existing.push(requireName);
    lines[idx] = `${match[1]}${existing.join(',')}${match[3]}${match[4]}`;
    return lines.join('\n');
}
