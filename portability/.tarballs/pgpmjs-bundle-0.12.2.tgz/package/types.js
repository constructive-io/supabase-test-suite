"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BUNDLE_FORMAT_VERSION = void 0;
/** Current bundle format version. Bumped only on breaking artifact changes. */
exports.BUNDLE_FORMAT_VERSION = '1';
