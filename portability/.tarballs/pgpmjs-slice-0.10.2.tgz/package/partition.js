"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.partitionChanges = partitionChanges;
exports.partitionModule = partitionModule;
const fs_1 = require("fs");
const path_1 = require("path");
const parser_1 = require("@pgpmjs/ast/files/plan/parser");
const closure_1 = require("./closure");
const refs_1 = require("./refs");
const slice_1 = require("./slice");
/** The dependency edges of a change: declared plan `requires` + AST-discovered. */
function dependenciesOf(change, graph, astEdges) {
    const deps = new Set();
    for (const dep of graph.edges.get(change) ?? []) {
        if (graph.nodes.has(dep))
            deps.add(dep);
    }
    for (const dep of astEdges.edges.get(change)?.keys() ?? [])
        deps.add(dep);
    return deps;
}
/**
 * Pure partition core: classify every change in the graph as per-tenant or
 * shared by propagating "per-tenant-ness" from the seeds along dependency
 * edges (a change that depends on a per-tenant change is itself per-tenant).
 *
 * Deterministic and I/O-free — the on-disk entry point is
 * {@link partitionModule}.
 */
function partitionChanges(input) {
    const { graph, astEdges } = input;
    const warnings = [];
    // dependents[x] = every change that depends on x (reverse of dependenciesOf).
    const dependents = new Map();
    for (const change of graph.nodes.keys()) {
        for (const dep of dependenciesOf(change, graph, astEdges)) {
            (dependents.get(dep) ?? dependents.set(dep, new Set()).get(dep)).add(change);
        }
    }
    // Propagate per-tenant status from the seeds up through their dependents.
    const perTenant = new Set();
    const queue = [];
    for (const seed of input.seeds) {
        if (!graph.nodes.has(seed)) {
            warnings.push({ kind: 'unknown-seed', change: seed, detail: 'seed change is not in the plan' });
            continue;
        }
        if (!perTenant.has(seed)) {
            perTenant.add(seed);
            queue.push(seed);
        }
    }
    while (queue.length > 0) {
        const current = queue.shift();
        for (const dependent of dependents.get(current) ?? []) {
            if (perTenant.has(dependent))
                continue;
            perTenant.add(dependent);
            queue.push(dependent);
        }
    }
    const shared = new Set();
    for (const change of graph.nodes.keys()) {
        if (!perTenant.has(change))
            shared.add(change);
    }
    const sharedDependencies = new Map();
    for (const change of perTenant) {
        const sharedDeps = new Set();
        for (const dep of dependenciesOf(change, graph, astEdges)) {
            if (shared.has(dep))
                sharedDeps.add(dep);
        }
        if (sharedDeps.size > 0)
            sharedDependencies.set(change, sharedDeps);
    }
    // A shared change that runs dynamic SQL could secretly reference per-tenant
    // data the parser can't see — flag it so callers don't share it blindly.
    for (const change of astEdges.dynamicSqlChanges) {
        if (shared.has(change)) {
            warnings.push({
                kind: 'dynamic-sql',
                change,
                detail: 'shared change executes dynamic SQL; hidden references cannot be proven tenant-independent'
            });
        }
    }
    for (const { change, ref } of astEdges.unresolvedReferences) {
        warnings.push({ kind: 'unresolved-reference', change, detail: `references ${ref}, produced by no change in the plan` });
    }
    return { perTenant, shared, sharedDependencies, warnings };
}
function objectKey(schema, name) {
    return `${schema ?? ''}\u0000${name}`;
}
/**
 * On-disk entry point: parse a module's plan + deploy SQL, resolve the given
 * per-tenant seed *objects* to the changes that create them, and partition the
 * module into shared vs per-tenant changes.
 *
 * `loadModule()` from `plpgsql-parser` must have been awaited first (the SQL
 * fact extraction is synchronous over the WASM parser).
 */
function partitionModule(options) {
    const planPath = options.planPath ?? (0, path_1.join)(options.moduleDir, 'pgpm.plan');
    const parsed = (0, parser_1.parsePlanFile)(planPath);
    if (!parsed.data) {
        const msg = parsed.errors?.map(e => `Line ${e.line}: ${e.message}`).join('\n') || 'Unknown error';
        throw new Error(`Failed to parse plan file: ${msg}`);
    }
    const graph = (0, slice_1.buildDependencyGraph)(parsed.data);
    // Producer index in plan order: first change creating an object wins.
    const producerByObject = new Map();
    for (const change of parsed.data.changes) {
        const deployPath = (0, path_1.join)(options.moduleDir, 'deploy', `${change.name}.sql`);
        if (!(0, fs_1.existsSync)(deployPath))
            continue;
        const facts = (0, refs_1.extractSqlFacts)((0, fs_1.readFileSync)(deployPath, 'utf-8'));
        for (const c of facts.creates) {
            const key = objectKey(c.schema, c.name);
            if (!producerByObject.has(key))
                producerByObject.set(key, change.name);
        }
    }
    const seedChanges = [];
    const unresolvedSeeds = [];
    for (const obj of options.seedObjects) {
        const producer = producerByObject.get(objectKey(obj.schema, obj.name));
        if (!producer) {
            unresolvedSeeds.push({
                kind: 'unknown-seed',
                change: obj.schema ? `${obj.schema}.${obj.name}` : obj.name,
                detail: 'no change in the module creates this seed object'
            });
            continue;
        }
        if (!seedChanges.includes(producer))
            seedChanges.push(producer);
    }
    const astEdges = (0, closure_1.buildAstEdges)(graph, options.moduleDir);
    const result = partitionChanges({ graph, astEdges, seeds: seedChanges });
    return { ...result, seedChanges, warnings: [...unresolvedSeeds, ...result.warnings] };
}
