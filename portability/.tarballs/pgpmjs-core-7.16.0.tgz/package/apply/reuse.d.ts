import { MigrationBundle } from '@pgpmjs/bundle';
import { ResolvedApplySpec } from './types';
/** A resolved apply spec that carries a reuse declaration. */
export type ResolvedReuseSpec = ResolvedApplySpec & {
    reuse: NonNullable<ResolvedApplySpec['reuse']>;
};
/** Whether an apply spec is a reuse (shared/per-tenant split) spec. */
export declare function isReuseSpec(spec: ResolvedApplySpec): spec is ResolvedReuseSpec;
/**
 * Deterministic name of the shared module a reuse proxy expands into. Derived
 * from the source module, the shared-schema mapping, and the per-tenant seed
 * set — the exact inputs that determine the shared partition — so two tenant
 * proxies over the same source/shared/seed configuration resolve to *one*
 * shared module (deployed once), while any difference isolates them.
 */
export declare function resolveSharedModuleName(spec: ResolvedReuseSpec): string;
export interface MaterializeReuseOptions {
    /** Directory of the source module being applied. */
    sourceDir: string;
    /** The resolved reuse spec. */
    spec: ResolvedReuseSpec;
    /** Deployable directory for the shared module (default: a fresh temp dir). */
    sharedOutDir?: string;
    /** Deployable directory for the per-tenant module (default: a fresh temp dir). */
    perTenantOutDir?: string;
}
export interface MaterializeReuseResult {
    sharedName: string;
    perTenantName: string;
    shared: {
        bundle: MigrationBundle;
        outDir: string;
    };
    perTenant: {
        bundle: MigrationBundle;
        outDir: string;
    };
}
/**
 * Expand a reuse proxy into two deployable modules: a shared module (objects the
 * classifier proves tenant-independent, deployed once) and a per-tenant module
 * (objects reachable from the per-tenant seeds, materialized per instance) that
 * `requires` the shared one.
 *
 * Pipeline over existing primitives:
 * `bundleFromModule` → `partitionModule` (classifier) →
 * `transpileBundle(makeSchemaTranspiler)` routing shared objects to the shared
 * schema and per-tenant objects to the per-tenant schema in *one* pass (so
 * cross-boundary references resolve correctly) → `splitBundle` with a per-tenant
 * schema bootstrap → `verifyBundle` → `materializeBundle`.
 */
export declare function materializeReuseModule(options: MaterializeReuseOptions): Promise<MaterializeReuseResult>;
