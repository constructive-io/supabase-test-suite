"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnvelopeApplyError = void 0;
exports.previewEnvelopeApply = previewEnvelopeApply;
exports.applyEnvelope = applyEnvelope;
const pg_cache_1 = require("pg-cache");
const bundle_1 = require("@pgpmjs/bundle");
const apply_1 = require("./apply");
/**
 * Analyze an envelope apply without executing it: verify the envelope's
 * digest chain (including the schema bundle), run the schema pre-flight, and
 * derive replay order + rollback plan. Pure — no database, no disk.
 */
function previewEnvelopeApply(envelope, options = {}) {
    const { issues } = (0, bundle_1.verifyEnvelope)(envelope);
    const parts = [
        ...envelope.data.map(part => ({ kind: 'data', name: part.name, part })),
        ...envelope.fixtures.map(part => ({ kind: 'fixtures', name: part.name, part }))
    ];
    const schema = (0, apply_1.previewBundleApply)(envelope.schema, options);
    return {
        name: envelope.manifest.name,
        version: envelope.manifest.version,
        envelopeDigest: envelope.manifest.digest,
        envelopeIssues: issues,
        schema,
        partOrder: parts.map(({ kind, name }) => ({ kind, name })),
        rollbackPlan: {
            parts: [...parts]
                .reverse()
                .map(({ kind, name, part }) => ({ kind, name, hasRevert: part.revert !== null })),
            schema: schema.rollbackPlan
        }
    };
}
/** Thrown when an envelope apply is refused pre-flight or fails mid-replay. */
class EnvelopeApplyError extends Error {
    preview;
    parts;
    timedOut;
    constructor(message, preview, 
    /** Parts completed before the failure (for status recording). */
    parts = [], timedOut = false) {
        super(message);
        this.preview = preview;
        this.parts = parts;
        this.timedOut = timedOut;
        this.name = 'EnvelopeApplyError';
    }
}
exports.EnvelopeApplyError = EnvelopeApplyError;
/**
 * Apply a {@link BundleEnvelope} into a target database: the generic
 * `applyMigrationBundle` primitive.
 *
 * Order of operations:
 * 1. Pre-flight: {@link previewEnvelopeApply} — refuse on any envelope digest
 *    issue unless `allowUnverified` (schema-bundle integrity and namespace
 *    gating are then enforced again by {@link applyBundle}).
 * 2. Schema: {@link applyBundle} on `envelope.schema` (atomic transaction,
 *    timeout, dry-run all handled there).
 * 3. Parts: replay each data then fixtures part's deploy SQL in manifest
 *    order, inside a single transaction so a failing part rolls back all part
 *    data (the schema stays applied; the preview's rollback plan describes the
 *    full undo). Optional per-part verify. The `transformPartSql` seam runs
 *    just before execution.
 */
async function applyEnvelope(envelope, options) {
    const started = Date.now();
    const preview = previewEnvelopeApply(envelope, options);
    if (!options.allowUnverified && preview.envelopeIssues.length > 0) {
        throw new EnvelopeApplyError(`Refusing to apply envelope "${preview.name}@${preview.version}": failed integrity ` +
            `verification (${preview.envelopeIssues.length} issue(s): ` +
            `${preview.envelopeIssues.map(i => i.kind).join(', ')})`, preview);
    }
    if (options.dryRun) {
        return {
            preview,
            dryRun: true,
            executed: false,
            parts: [],
            durationMs: Date.now() - started,
            timedOut: false
        };
    }
    const schema = await (0, apply_1.applyBundle)(envelope.schema, options);
    const transform = options.transformPartSql ?? ((sql) => sql);
    const orderedParts = [
        ...envelope.data.map(part => ({ kind: 'data', name: part.name, part })),
        ...envelope.fixtures.map(part => ({ kind: 'fixtures', name: part.name, part }))
    ];
    const parts = [];
    if (orderedParts.length > 0) {
        const pool = (0, pg_cache_1.getPgPool)(options.config);
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            for (const { kind, name, part } of orderedParts) {
                const partStarted = Date.now();
                try {
                    await client.query(transform(part.deploy, { kind, name, script: 'deploy' }));
                    const result = {
                        kind,
                        name,
                        executed: true,
                        durationMs: Date.now() - partStarted
                    };
                    if (options.verifyParts && part.verify !== null) {
                        await client.query(transform(part.verify, { kind, name, script: 'verify' }));
                        result.verified = true;
                    }
                    parts.push(result);
                }
                catch (e) {
                    await client.query('ROLLBACK');
                    throw new EnvelopeApplyError(`Part ${kind}/${name} of envelope "${preview.name}@${preview.version}" failed: ` +
                        `${e instanceof Error ? e.message : String(e)} — all part data rolled back ` +
                        `(schema remains applied; see preview.rollbackPlan)`, preview, parts);
                }
            }
            await client.query('COMMIT');
        }
        finally {
            client.release();
        }
    }
    return {
        preview,
        dryRun: false,
        executed: true,
        schema,
        parts,
        durationMs: Date.now() - started,
        timedOut: schema.timedOut
    };
}
