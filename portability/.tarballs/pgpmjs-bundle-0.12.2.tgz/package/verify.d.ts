import { MigrationBundle } from './types';
/**
 * A single bundle integrity discrepancy found by {@link verifyBundle}.
 */
export interface BundleIssue {
    kind: 'script-digest' | 'exec-digest' | 'change-digest' | 'bundle-digest' | 'order-mismatch' | 'change-count';
    change?: string;
    script?: string;
    message: string;
}
/**
 * Recompute every digest in a bundle and confirm it matches the recorded values.
 *
 * This is the integrity gate `applyMigrationBundle` / `transpileMigrationBundle`
 * run before trusting a transported artifact: it proves the SQL bytes, per-change
 * digests, deploy order, and top-level digest are internally consistent. Read-only;
 * returns the issues rather than throwing.
 */
export declare function verifyBundle(bundle: MigrationBundle): BundleIssue[];
