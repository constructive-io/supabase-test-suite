"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EXTENSIONS_MANIFEST_FILES = void 0;
exports.validateExtensionsManifest = validateExtensionsManifest;
exports.readExtensionsManifest = readExtensionsManifest;
const fs_1 = require("fs");
const path_1 = require("path");
/**
 * Declarative extension manifest (`extensions.json`) that lives next to a
 * module's `pgpm.plan` / `.control`. It makes a module self-describing about
 * the PostgreSQL extensions it relates to:
 *
 * - `provides` — the module *is* the extension wrapper: it installs the
 *   extension into a chosen schema (with grants). This is what replaces the
 *   dynamic `DO $$ EXECUTE 'CREATE EXTENSION ... SCHEMA x' $$` hack, since a
 *   literal `CREATE EXTENSION` is stripped at package time.
 * - `consumes` — the module merely *uses* symbols from an extension installed
 *   elsewhere (e.g. a bare `crypt()` call) and needs them qualified to wherever
 *   the extension actually landed. This is the transform/routing side.
 *
 * `.control` `requires` still names the extension (dependency ordering is
 * unchanged); this manifest only adds the *where + grants* that `.control`
 * cannot express.
 */
/** Candidate file names, in precedence order. */
exports.EXTENSIONS_MANIFEST_FILES = ['pgpm.extensions.json', 'extensions.json'];
const isPlainObject = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
const GRANT_TARGETS = new Set([
    'schema',
    'all-tables',
    'all-sequences',
    'all-functions'
]);
/**
 * Validate + normalize a parsed manifest object. Throws with a precise message
 * on malformed input so authors get actionable errors rather than silent
 * misconfiguration.
 */
function validateExtensionsManifest(raw, source = 'extensions.json') {
    if (!isPlainObject(raw)) {
        throw new Error(`${source}: manifest must be a JSON object`);
    }
    const manifest = {};
    if (raw.provides !== undefined) {
        if (!isPlainObject(raw.provides)) {
            throw new Error(`${source}: "provides" must be an object keyed by extension name`);
        }
        const provides = {};
        for (const [extname, value] of Object.entries(raw.provides)) {
            provides[extname] = validateProvide(extname, value, source);
        }
        manifest.provides = provides;
    }
    if (raw.consumes !== undefined) {
        if (!isPlainObject(raw.consumes)) {
            throw new Error(`${source}: "consumes" must be an object keyed by extension name`);
        }
        const consumes = {};
        for (const [extname, value] of Object.entries(raw.consumes)) {
            if (!isPlainObject(value)) {
                throw new Error(`${source}: consumes."${extname}" must be an object`);
            }
            const entry = {};
            if (value.symbols !== undefined) {
                if (!Array.isArray(value.symbols) || value.symbols.some((s) => typeof s !== 'string' || !s.trim())) {
                    throw new Error(`${source}: consumes."${extname}".symbols must be an array of non-empty strings`);
                }
                entry.symbols = value.symbols;
            }
            consumes[extname] = entry;
        }
        manifest.consumes = consumes;
    }
    return manifest;
}
function validateProvide(extname, value, source) {
    if (!isPlainObject(value)) {
        throw new Error(`${source}: provides."${extname}" must be an object`);
    }
    const provide = {};
    if (value.schema !== undefined) {
        if (value.schema !== null && (typeof value.schema !== 'string' || !value.schema.trim())) {
            throw new Error(`${source}: provides."${extname}".schema must be a non-empty string or null`);
        }
        provide.schema = value.schema;
    }
    for (const flag of ['relocatable', 'ifNotExists', 'cascade', 'createSchema', 'dropSchema']) {
        if (value[flag] !== undefined) {
            if (typeof value[flag] !== 'boolean') {
                throw new Error(`${source}: provides."${extname}".${flag} must be a boolean`);
            }
            provide[flag] = value[flag];
        }
    }
    if (value.grants !== undefined) {
        if (!Array.isArray(value.grants)) {
            throw new Error(`${source}: provides."${extname}".grants must be an array`);
        }
        provide.grants = value.grants.map((g, i) => validateGrant(extname, g, i, source));
    }
    return provide;
}
function validateGrant(extname, value, index, source) {
    const where = `provides."${extname}".grants[${index}]`;
    if (!isPlainObject(value)) {
        throw new Error(`${source}: ${where} must be an object`);
    }
    if (typeof value.privileges !== 'string' || !value.privileges.trim()) {
        throw new Error(`${source}: ${where}.privileges must be a non-empty string`);
    }
    if (typeof value.on !== 'string' || !GRANT_TARGETS.has(value.on)) {
        throw new Error(`${source}: ${where}.on must be one of ${[...GRANT_TARGETS].join(', ')}`);
    }
    const toValid = (typeof value.to === 'string' && value.to.trim()) ||
        (Array.isArray(value.to) && value.to.length > 0 && value.to.every((r) => typeof r === 'string' && r.trim()));
    if (!toValid) {
        throw new Error(`${source}: ${where}.to must be a role name or non-empty array of role names`);
    }
    return {
        privileges: value.privileges,
        on: value.on,
        to: value.to
    };
}
/**
 * Read + validate the `extensions.json` (or `pgpm.extensions.json`) manifest for
 * a module directory. Returns `undefined` when the module declares no manifest.
 */
function readExtensionsManifest(moduleDir) {
    for (const file of exports.EXTENSIONS_MANIFEST_FILES) {
        const p = (0, path_1.join)(moduleDir, file);
        if ((0, fs_1.existsSync)(p)) {
            let parsed;
            try {
                parsed = JSON.parse((0, fs_1.readFileSync)(p, 'utf-8'));
            }
            catch (e) {
                throw new Error(`Failed to parse ${file} at ${moduleDir}: ${e.message}`);
            }
            return validateExtensionsManifest(parsed, file);
        }
    }
    return undefined;
}
