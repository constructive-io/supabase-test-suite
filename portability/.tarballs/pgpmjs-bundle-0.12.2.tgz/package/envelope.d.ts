import { MigrationBundle } from './types';
import { BundleIssue } from './verify';
/** Current envelope format version. Bumped only on breaking artifact changes. */
export declare const ENVELOPE_FORMAT_VERSION = "1";
/** Default file name for a serialized envelope artifact. */
export declare const ENVELOPE_FILE_NAME = "pgpm-envelope.json";
/** Manifest file name inside a materialized envelope directory. */
export declare const ENVELOPE_MANIFEST_FILE_NAME = "envelope.json";
export type EnvelopePartKind = 'schema' | 'data' | 'fixtures';
/**
 * One data or fixtures part: a named deploy/revert/verify SQL triplet.
 * `deploy` is required; `revert`/`verify` are optional (null when absent).
 */
export interface EnvelopeScriptPart {
    name: string;
    /** SQL text, byte-exact. */
    deploy: string;
    revert: string | null;
    verify: string | null;
    /** sha256 over the part name + script digests (see `computePartDigest`). */
    digest: string;
}
/** Inventory entry for one part of the envelope. */
export interface EnvelopePartEntry {
    kind: EnvelopePartKind;
    name: string;
    digest: string;
}
/**
 * The envelope's self-describing header: identity, contents inventory with
 * per-part digests, an overall content digest, and source lineage.
 */
export interface EnvelopeManifest {
    formatVersion: string;
    /** Artifact name (typically the module/extension name). */
    name: string;
    /** Artifact version (caller-assigned, e.g. a semver or revision tag). */
    version: string;
    /** Tool that produced the envelope (informational; excluded from {@link digest}). */
    createdWith: string;
    /** Contents inventory in serialization order: schema first, then data, then fixtures. */
    parts: EnvelopePartEntry[];
    /**
     * sha256 over the identity (name, version) + ordered part digests. Merkle:
     * any byte change in any part changes a part digest and therefore this one.
     * Independent of `createdWith`/provenance so identical contents hash identically.
     */
    digest: string;
    /**
     * Optional caller-supplied lineage — e.g. source database/metaschema
     * revision, the slice spec that produced the schema bundle, a schema map.
     * Recorded but excluded from {@link digest}.
     */
    provenance?: Record<string, string>;
}
/**
 * A portable, content-addressed shipping container: schema (required) plus
 * ordered data and fixtures parts.
 */
export interface BundleEnvelope {
    manifest: EnvelopeManifest;
    schema: MigrationBundle;
    data: EnvelopeScriptPart[];
    fixtures: EnvelopeScriptPart[];
}
/**
 * Digest for one data/fixtures part: its name plus the digests of its scripts
 * in fixed deploy/revert/verify order; a missing script contributes an empty
 * slot so presence/absence changes the digest.
 */
export declare function computePartDigest(name: string, scripts: {
    deploy: string;
    revert?: string | null;
    verify?: string | null;
}): string;
/**
 * Top-level envelope digest: identity + the ordered part digests.
 */
export declare function computeEnvelopeDigest(name: string, version: string, partDigests: string[]): string;
/** Input shape for a data/fixtures part (digest computed by createEnvelope). */
export interface EnvelopeScriptPartInput {
    name: string;
    deploy: string;
    revert?: string | null;
    verify?: string | null;
}
export interface CreateEnvelopeOptions {
    /** Artifact name; defaults to the schema bundle's manifest name. */
    name?: string;
    /** Artifact version (caller-assigned). */
    version: string;
    /** The schema bundle (required). */
    schema: MigrationBundle;
    /** Data parts, in replay order. */
    data?: EnvelopeScriptPartInput[];
    /** Fixture parts, in replay order. */
    fixtures?: EnvelopeScriptPartInput[];
    /** Tool identifier recorded in the manifest (default `@pgpmjs/bundle`). */
    createdWith?: string;
    /** Lineage recorded in the manifest (excluded from the digest). */
    provenance?: Record<string, string>;
}
/**
 * Build a content-addressed {@link BundleEnvelope}. Pure and deterministic:
 * no disk I/O, no clock, no version noise in the digest. The schema part's
 * digest is the bundle's own manifest digest, so the envelope Merkle chain
 * extends down through every change and script.
 */
export declare function createEnvelope(options: CreateEnvelopeOptions): BundleEnvelope;
/**
 * A single envelope integrity discrepancy found by {@link verifyEnvelope}.
 */
export interface EnvelopeIssue {
    kind: 'part-digest' | 'part-inventory' | 'envelope-digest' | 'schema-bundle';
    part?: string;
    message: string;
}
/**
 * Recompute every digest in an envelope and confirm it matches the recorded
 * values: each part digest, the inventory, the top-level digest, and (via
 * {@link verifyBundle}) the full schema bundle chain. Read-only; returns the
 * issues rather than throwing.
 */
export declare function verifyEnvelope(envelope: BundleEnvelope): {
    issues: EnvelopeIssue[];
    schemaIssues: BundleIssue[];
};
/**
 * Serialize an envelope to a single JSON artifact file (stable 2-space formatting).
 */
export declare function writeEnvelopeFile(envelope: BundleEnvelope, filePath: string): void;
/**
 * Read an envelope artifact JSON file back into memory.
 */
export declare function readEnvelopeFile(filePath: string): BundleEnvelope;
/**
 * Materialize an envelope as a deterministic directory layout — trivially
 * tarred/shipped by callers:
 *
 * ```
 * envelope.json                 # manifest only
 * schema/pgpm-bundle.json       # the schema MigrationBundle artifact
 * data/<name>/{deploy,revert,verify}.sql
 * fixtures/<name>/{deploy,revert,verify}.sql
 * ```
 */
export declare function materializeEnvelope(envelope: BundleEnvelope, outDir: string): void;
/**
 * Read a materialized envelope directory back into memory — the inverse of
 * {@link materializeEnvelope}. Part order is restored from the manifest
 * inventory; run {@link verifyEnvelope} afterwards to prove integrity.
 */
export declare function envelopeFromDirectory(dir: string): BundleEnvelope;
