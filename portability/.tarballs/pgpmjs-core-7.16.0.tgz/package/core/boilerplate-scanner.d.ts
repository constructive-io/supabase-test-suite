import { BoilerplateConfig, BoilerplatesRootConfig, ScannedBoilerplate } from './boilerplate-types';
/**
 * Read the root `.boilerplates.json` configuration from a template repository.
 * This file specifies the default directory containing boilerplate templates.
 *
 * @param templateDir - The root directory of the template repository
 * @returns The root config or null if not found
 */
export declare function readBoilerplatesConfig(templateDir: string): BoilerplatesRootConfig | null;
/**
 * Read the `.boilerplate.json` configuration from a boilerplate directory.
 * This file specifies the boilerplate type and questions.
 *
 * @param boilerplatePath - The path to the boilerplate directory
 * @returns The boilerplate config or null if not found
 */
export declare function readBoilerplateConfig(boilerplatePath: string): BoilerplateConfig | null;
/**
 * Scan a base directory for boilerplate templates.
 * Each subdirectory with a `.boilerplate.json` file is considered a boilerplate.
 *
 * @param baseDir - The directory to scan (e.g., "default/")
 * @returns Array of scanned boilerplates with their configurations
 */
export declare function scanBoilerplates(baseDir: string): ScannedBoilerplate[];
/**
 * Find a boilerplate by type within a scanned list.
 *
 * @param boilerplates - Array of scanned boilerplates
 * @param type - The type to find ('workspace' or 'module')
 * @returns The matching boilerplate or undefined
 */
export declare function findBoilerplateByType(boilerplates: ScannedBoilerplate[], type: 'workspace' | 'module'): ScannedBoilerplate | undefined;
/**
 * Resolve the base directory for boilerplates in a template repository.
 * Uses `.boilerplates.json` if present, otherwise returns empty string.
 *
 * @param templateDir - The root directory of the template repository
 * @returns The resolved base directory path
 */
export declare function resolveBoilerplateBaseDir(templateDir: string): string;
