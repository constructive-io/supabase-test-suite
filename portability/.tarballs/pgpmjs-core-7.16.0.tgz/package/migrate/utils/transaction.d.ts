import { Pool, PoolClient } from 'pg';
export { formatQueryHistory, truncateErrorOutput } from './errors';
export interface TransactionOptions {
    useTransaction: boolean;
}
export interface TransactionContext {
    client: PoolClient | Pool;
    isTransaction: boolean;
    queryHistory: QueryHistoryEntry[];
    addQuery: (query: string, params?: any[], startTime?: number) => void;
}
export interface QueryHistoryEntry {
    query: string;
    params?: any[];
    timestamp: number;
    duration?: number;
    error?: any;
}
/**
 * Execute a function within a transaction context
 * If useTransaction is true, wraps the execution in a transaction
 * If false, uses the pool directly without transaction
 */
export declare function withTransaction<T>(pool: Pool, options: TransactionOptions, fn: (context: TransactionContext) => Promise<T>): Promise<T>;
/**
 * Helper to execute a query within a transaction context with enhanced logging
 */
export declare function executeQuery(context: TransactionContext, query: string, params?: any[]): Promise<any>;
