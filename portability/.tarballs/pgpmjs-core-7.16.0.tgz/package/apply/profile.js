"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadWorkspaceRoutingProfile = loadWorkspaceRoutingProfile;
exports.resolveEffectiveApplySpec = resolveEffectiveApplySpec;
const env_1 = require("@pgpmjs/env");
const types_1 = require("@pgpmjs/types");
/**
 * Load the workspace-level routing profile (the `portability` field of the
 * workspace `pgpm.json` / `pgpm.config.js`). Returns `undefined` when the
 * workspace has no config file or no profile.
 */
function loadWorkspaceRoutingProfile(workspacePath) {
    let config;
    try {
        config = (0, env_1.loadConfigSyncFromDir)(workspacePath);
    }
    catch {
        return undefined;
    }
    return config?.portability;
}
/**
 * Resolve the routing profile effective for one apply spec: defaults →
 * workspace `portability` → the spec's own routing keys, merged per key
 * (inner scope wins; see {@link mergeRoutingProfiles}).
 */
function resolveEffectiveApplySpec(spec, workspaceProfile) {
    if (!workspaceProfile)
        return spec;
    const merged = (0, types_1.mergeRoutingProfiles)(workspaceProfile, {
        schemas: spec.schemas,
        route: spec.route,
        extensions: spec.extensions,
        roles: spec.roles,
        exclude: spec.exclude
    });
    return { ...spec, ...merged };
}
