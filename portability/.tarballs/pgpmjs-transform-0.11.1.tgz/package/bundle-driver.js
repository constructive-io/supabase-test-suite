"use strict";
/**
 * Bundle transpile/apply drivers.
 *
 * Adapters that plug this package's AST transforms into the pgpm migration
 * bundle seams (`transpileBundle`'s `renameChange`/`transformScript` and
 * `applyBundle`'s `validateReferences`). The seams are structurally typed on
 * purpose — no dependency on `@pgpmjs/bundle`/`@pgpmjs/core` — so the driver
 * stays a pure function factory over `transformSql` and `classifyStatements`.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildExtensionRouter = buildExtensionRouter;
exports.buildSchemaRouter = buildSchemaRouter;
exports.makeSchemaTranspiler = makeSchemaTranspiler;
exports.makeNamespaceValidator = makeNamespaceValidator;
const transform_1 = require("@pgsql/transform");
const transform_2 = require("@pgsql/transform");
/**
 * Build an {@link ExtensionRouter} from the declarative {@link ExtensionRoutingInput}:
 * an explicit `routes` spec when given, otherwise the "move everything matched
 * to one schema" shortcut via `ExtensionRouter.toSchema`.
 */
function buildExtensionRouter(input) {
    const opts = {};
    if (input.serverVersion !== undefined)
        opts.serverVersion = input.serverVersion;
    if (input.inventory)
        opts.inventory = input.inventory;
    if (input.routes)
        return new transform_2.ExtensionRouter(input.routes, opts);
    return transform_2.ExtensionRouter.toSchema(input.toSchema ?? null, {
        ...opts,
        extensions: input.only,
        from: input.from
    });
}
/** pgpm change-path folder segment → transform routing namespace. */
const PATH_KIND_NS = {
    tables: 'relation',
    views: 'relation',
    procedures: 'function',
    functions: 'function',
    types: 'type'
};
/** Object route `kind` → the {@link SchemaRoute} bucket it belongs in. */
const ROUTE_KIND_BUCKET = {
    table: 'relations',
    view: 'relations',
    function: 'functions',
    procedure: 'functions',
    type: 'types'
};
/**
 * Build a {@link SchemaRouter} from a schema-level default map plus object
 * routes. Object routes are grouped into the router's relation/function/type
 * buckets; schema-level entries become each route's default target.
 */
function buildSchemaRouter(options) {
    const spec = {};
    const ensure = (schema) => (spec[schema] ??= {});
    for (const [from, to] of Object.entries(options.schemaMap ?? {})) {
        ensure(from).schema = to;
    }
    for (const route of options.routes ?? []) {
        if (route.toSchema === undefined && route.toName === undefined) {
            throw new Error(`Object route for ${route.fromSchema}.${route.name} needs "toSchema" and/or "toName"`);
        }
        const bucketKey = ROUTE_KIND_BUCKET[route.kind];
        const target = ensure(route.fromSchema);
        (target[bucketKey] ??= {})[route.name] =
            route.toName === undefined && typeof route.toSchema === 'string'
                ? route.toSchema
                : {
                    ...(route.toSchema !== undefined ? { schema: route.toSchema } : {}),
                    ...(route.toName !== undefined ? { name: route.toName } : {})
                };
    }
    return new transform_2.SchemaRouter(spec);
}
/**
 * Rewrite the schema segment of a pgpm change path to the object's routed
 * target. Interprets `schemas/<schema>/<kind>/<name>...`: the bare
 * `schemas/<schema>/schema` change resolves at the schema level; typed folders
 * (`tables`, `procedures`, `types`, …) resolve the named object in its
 * namespace, so object routes and the schema-level default both apply.
 */
function renameChangePath(name, router) {
    const parts = name.split('/');
    for (let i = 0; i < parts.length - 1; i++) {
        if (parts[i] !== 'schemas')
            continue;
        const schema = parts[i + 1];
        if (!router.has(schema))
            continue;
        const folder = parts[i + 2];
        let target;
        if (folder === undefined || folder === 'schema') {
            target = router.resolve(schema, undefined, 'schema');
        }
        else {
            const ns = PATH_KIND_NS[folder];
            const objectName = parts[i + 3];
            target = ns
                ? router.resolve(schema, objectName, ns)
                : router.resolve(schema, undefined, 'schema');
        }
        if (target && target !== schema)
            parts[i + 1] = target;
    }
    return parts.join('/');
}
/**
 * Build the caller-supplied callbacks for `transpileBundle` from a schema map
 * and/or object routes, so the folder/plan rename (change identity) and the
 * in-SQL rewrite (AST) stay in lockstep on the exact same {@link SchemaRouter}.
 */
function makeSchemaTranspiler(options) {
    const router = buildSchemaRouter(options);
    const result = {
        schemasFound: new Set(),
        schemasTransformed: new Map(),
        errors: []
    };
    // Extension/role routing are additional, orthogonal AST dimensions applied
    // after schema routing on each script. Each is a self-contained parse →
    // rewrite → deparse pass, so they compose by threading the SQL through.
    const extRouter = options.extensions ? buildExtensionRouter(options.extensions) : undefined;
    const roleRouter = options.roles ? transform_2.RoleRouter.from(options.roles) : undefined;
    const extensionResult = extRouter ? (0, transform_2.createExtensionResult)() : undefined;
    const roleResult = roleRouter ? (0, transform_2.createRoleResult)() : undefined;
    const renameChange = (name) => renameChangePath(name, router);
    const transformScript = (sql, _ctx) => {
        let out = (0, transform_2.transformSql)(sql, router, options.transform, result).content;
        if (extRouter) {
            const r = (0, transform_2.transformExtensions)(out, extRouter);
            out = r.sql;
            for (const [name, schema] of r.result.installsMoved) {
                extensionResult.installsMoved.set(name, schema);
            }
            for (const [name, count] of r.result.symbolsRewritten) {
                extensionResult.symbolsRewritten.set(name, (extensionResult.symbolsRewritten.get(name) ?? 0) + count);
            }
        }
        if (roleRouter) {
            const r = (0, transform_2.transformRoles)(out, roleRouter);
            out = r.sql;
            for (const [name, count] of r.result.rolesRenamed) {
                roleResult.rolesRenamed.set(name, (roleResult.rolesRenamed.get(name) ?? 0) + count);
            }
        }
        return out;
    };
    return { renameChange, transformScript, result, extensionResult, roleResult };
}
/**
 * Build an `applyBundle`-compatible `validateReferences` callback: returns a
 * description of every schema-qualified object a script creates or references
 * outside the allowed namespace. Unqualified references resolve via
 * search_path and are not reported.
 */
function makeNamespaceValidator(options) {
    const allowed = new Set(options.allowedSchemas);
    return (sql, _ctx) => {
        const violations = new Set();
        for (const facts of (0, transform_1.classifyStatements)(sql)) {
            for (const ref of [...facts.creates, ...facts.references, ...facts.fkTargets]) {
                if (ref.schema && !allowed.has(ref.schema)) {
                    violations.add(`${facts.nodeTag}: ${ref.schema}.${ref.name}`);
                }
            }
            if (options.flagDynamicSql && facts.dynamicSql) {
                violations.add(`${facts.nodeTag}: dynamic SQL — references not statically verifiable`);
            }
        }
        return [...violations];
    };
}
