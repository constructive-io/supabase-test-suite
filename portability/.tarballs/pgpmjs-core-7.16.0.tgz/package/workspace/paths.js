"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getModulePath = exports.getWorkspacePath = exports.pgpmPath = exports.modulePath = void 0;
const utils_1 = require("./utils");
const PROJECT_FILES = {
    PLAN: 'pgpm.plan',
    PGPM: 'pgpm.json',
};
/**
 * Finds the module path by looking for pgpm.plan.
 * @param cwd - Current working directory.
 * @returns A promise that resolves to the directory path containing `pgpm.plan`.
 */
const modulePath = (cwd = process.cwd()) => {
    return (0, utils_1.walkUp)(cwd, PROJECT_FILES.PLAN);
};
exports.modulePath = modulePath;
/**
 * Finds the pgpm project path.
 * @param cwd - Current working directory.
 * @returns A promise that resolves to the directory path containing `pgpm.json`.
 */
const pgpmPath = (cwd = process.cwd()) => {
    return (0, utils_1.walkUp)(cwd, PROJECT_FILES.PGPM);
};
exports.pgpmPath = pgpmPath;
const getWorkspacePath = (cwd) => {
    let workspacePath;
    try {
        workspacePath = (0, exports.pgpmPath)(cwd);
    }
    catch (err) {
        console.error('Error: You must be in a pgpm workspace. You can initialize one with `pgpm init workspace`.');
        process.exit(1);
    }
    return workspacePath;
};
exports.getWorkspacePath = getWorkspacePath;
const getModulePath = (cwd) => {
    let pkgPath;
    try {
        pkgPath = (0, exports.modulePath)(cwd);
    }
    catch (err) {
        console.error('Error: You must be in a pgpm module. You can initialize one with the `init` command.');
        process.exit(1);
    }
    return pkgPath;
};
exports.getModulePath = getModulePath;
