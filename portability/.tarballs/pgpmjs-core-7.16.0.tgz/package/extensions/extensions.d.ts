import { ModuleMap } from '../modules/modules';
/**
 * Get the list of available extensions, including predefined core extensions.
 */
export declare const getAvailableExtensions: (modules: ModuleMap) => Promise<string[]>;
