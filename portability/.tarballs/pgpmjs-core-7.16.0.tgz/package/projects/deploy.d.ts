import { PgpmOptions } from '@pgpmjs/types';
import { PgpmPackage } from '../core/class/pgpm';
interface Extensions {
    resolved: string[];
    external: string[];
}
export declare const deployProject: (opts: PgpmOptions, name: string, database: string, pkg: PgpmPackage, toChange?: string) => Promise<Extensions>;
export {};
