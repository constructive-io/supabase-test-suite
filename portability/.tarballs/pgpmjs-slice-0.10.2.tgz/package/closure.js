"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildAstEdges = buildAstEdges;
exports.expandClosures = expandClosures;
const fs_1 = require("fs");
const path_1 = require("path");
const refs_1 = require("./refs");
function objectKey(schema, name) {
    return `${schema ?? ''}\u0000${name}`;
}
function refLabel(schema, name) {
    return schema ? `${schema}.${name}` : name;
}
/**
 * Parse each change's deploy SQL and derive dependency edges from the
 * schema-qualified objects it references, mapped back to the plan change that
 * creates each object. Only edges between plan-known changes are produced —
 * references to objects created outside the plan (installed modules,
 * extensions) are reported as unresolved instead.
 */
function buildAstEdges(graph, moduleDir) {
    const facts = new Map();
    for (const changeName of graph.nodes.keys()) {
        const deployPath = (0, path_1.join)(moduleDir, 'deploy', `${changeName}.sql`);
        if (!(0, fs_1.existsSync)(deployPath))
            continue;
        facts.set(changeName, (0, refs_1.extractSqlFacts)((0, fs_1.readFileSync)(deployPath, 'utf-8')));
    }
    // Producer index in plan order: first change creating an object wins.
    const producerByObject = new Map();
    for (const change of graph.plan.changes) {
        const f = facts.get(change.name);
        if (!f)
            continue;
        for (const c of f.creates) {
            const key = objectKey(c.schema, c.name);
            if (!producerByObject.has(key))
                producerByObject.set(key, change.name);
        }
    }
    const edges = new Map();
    const dynamicSqlChanges = [];
    const unresolvedReferences = [];
    for (const [changeName, f] of facts) {
        if (f.dynamicSql)
            dynamicSqlChanges.push(changeName);
        for (const r of f.references) {
            const producer = producerByObject.get(objectKey(r.schema, r.name));
            if (!producer) {
                unresolvedReferences.push({ change: changeName, ref: refLabel(r.schema, r.name) });
                continue;
            }
            if (producer === changeName)
                continue;
            if (!edges.has(changeName))
                edges.set(changeName, new Map());
            const deps = edges.get(changeName);
            if (!deps.has(producer))
                deps.set(producer, refLabel(r.schema, r.name));
        }
    }
    return { edges, dynamicSqlChanges, unresolvedReferences };
}
/**
 * Expand the packages of closure-enabled pattern slices to cover the
 * transitive dependency closure of their seed changes.
 *
 * The closure follows declared plan `requires` edges plus AST-discovered
 * edges. Only changes currently assigned to the default package are pulled in
 * — a dependency that another explicit slice claimed stays where it is and
 * remains an ordinary cross-package dependency. Mutates `assignments` in
 * place and returns a report of every auto-included change and why.
 */
function expandClosures(assignments, graph, astEdges, strategy, defaultPackage) {
    const autoIncluded = [];
    const defaultChanges = assignments.get(defaultPackage) ?? new Set();
    for (const slice of strategy.slices) {
        if (!slice.closure)
            continue;
        const pkgChanges = assignments.get(slice.packageName);
        if (!pkgChanges || pkgChanges.size === 0)
            continue;
        const queue = [...pkgChanges];
        const seen = new Set(queue);
        while (queue.length > 0) {
            const current = queue.shift();
            const pull = (dep, reason, ref) => {
                if (seen.has(dep))
                    return;
                seen.add(dep);
                if (pkgChanges.has(dep)) {
                    queue.push(dep);
                    return;
                }
                // A dependency claimed by another explicit slice stays where it is
                // and remains an ordinary cross-package dependency.
                if (!defaultChanges.has(dep))
                    return;
                defaultChanges.delete(dep);
                pkgChanges.add(dep);
                queue.push(dep);
                autoIncluded.push({
                    change: dep,
                    package: slice.packageName,
                    requiredBy: current,
                    reason,
                    ...(ref ? { ref } : {})
                });
            };
            for (const dep of graph.edges.get(current) ?? []) {
                if (graph.nodes.has(dep))
                    pull(dep, 'requires');
            }
            for (const [dep, ref] of astEdges.edges.get(current) ?? []) {
                pull(dep, 'ast', ref);
            }
        }
    }
    return {
        autoIncluded,
        dynamicSqlChanges: astEdges.dynamicSqlChanges,
        unresolvedReferences: astEdges.unresolvedReferences
    };
}
