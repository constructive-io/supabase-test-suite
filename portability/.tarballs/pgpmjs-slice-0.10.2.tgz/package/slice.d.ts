import { Change, Tag, ExtendedPlanFile } from '@pgpmjs/ast/files/types';
import { SliceConfig, SliceResult, DependencyGraph, PackageOutput, GroupingStrategy, PatternStrategy, CrossPackageDepMode } from './types';
/**
 * Build a dependency graph from a parsed plan file
 */
export declare function buildDependencyGraph(plan: ExtendedPlanFile): DependencyGraph;
/**
 * Validate that the dependency graph is a DAG (no cycles)
 */
export declare function validateDAG(graph: DependencyGraph): void;
/**
 * Extract package name from a change path using folder-based strategy
 */
export declare function extractPackageFromPath(changeName: string, depth?: number, prefixToStrip?: string): string;
/**
 * Find the matching package for a change using pattern-based strategy.
 * Returns the first matching slice's package name, or undefined if no match.
 */
export declare function findMatchingPattern(changeName: string, strategy: PatternStrategy): string | undefined;
/**
 * Assign changes to packages based on grouping strategy
 */
export declare function assignChangesToPackages(graph: DependencyGraph, strategy: GroupingStrategy, defaultPackage?: string): Map<string, Set<string>>;
/**
 * Merge small packages into larger ones
 */
export declare function mergeSmallPackages(assignments: Map<string, Set<string>>, minChanges: number, defaultPackage?: string): Map<string, Set<string>>;
/**
 * Build package-level dependency graph
 */
export declare function buildPackageDependencies(graph: DependencyGraph, assignments: Map<string, Set<string>>, extraEdges?: Map<string, Map<string, string>>): Map<string, Set<string>>;
/**
 * Detect cycles in package dependency graph
 */
export declare function detectPackageCycle(deps: Map<string, Set<string>>): string[] | null;
/**
 * Compute deployment order for packages (topological sort)
 */
export declare function computeDeployOrder(packageDeps: Map<string, Set<string>>): string[];
/**
 * Topological sort of changes within a package
 */
export declare function topologicalSortWithinPackage(changes: Set<string>, graph: DependencyGraph): string[];
/**
 * Generate plan file content for a package
 */
export declare function generatePlanContent(pkgName: string, entries: Change[], tags?: Tag[]): string;
/**
 * Generate control file content for a package
 */
export declare function generateControlContent(pkgName: string, deps: Set<string>): string;
/**
 * Generate a single package output
 */
export declare function generateSinglePackage(pkgName: string, changes: Set<string>, graph: DependencyGraph, changeToPackage: Map<string, string>, pkgDeps: Set<string>, crossPackageDeps?: boolean | CrossPackageDepMode): PackageOutput;
/**
 * Main slicing function
 */
export declare function slicePlan(config: SliceConfig): SliceResult;
