/**
 * Resolves SQL scripts for deployment or reversion.
 *
 * @param pkgDir - The package directory (defaults to the current working directory).
 * @param scriptType - The type of script to resolve (`deploy` or `revert`).
 * @returns A single concatenated SQL script as a string.
 */
export declare const resolve: (pkgDir?: string, scriptType?: "deploy" | "revert") => string;
/**
 * Resolves SQL scripts based on the `pgpm.plan` file.
 *
 * @param pkgDir - The package directory (defaults to the current working directory).
 * @param scriptType - The type of script to resolve (`deploy` or `revert`).
 * @returns A single concatenated SQL script as a string.
 */
export declare const resolveWithPlan: (pkgDir?: string, scriptType?: "deploy" | "revert") => string;
/**
 * Resolves a tag reference to its corresponding change name.
 * Tags provide a way to reference specific points in a package's deployment history.
 *
 * @param planPath - Path to the plan file containing tag definitions
 * @param tagReference - The tag reference to resolve (e.g., "package:@tagName" or "@tagName")
 * @param currentPackage - The current package name (used when tag doesn't specify package)
 * @returns The resolved change name
 * @throws Error if tag format is invalid or tag is not found
 *
 * @example
 * // Resolve a tag in the current package
 * resolveTagToChangeName('/path/to/pgpm.plan', '@v1.0.0', 'mypackage')
 * // Returns: 'schema/v1'
 *
 * @example
 * // Resolve a tag from another package
 * resolveTagToChangeName('/path/to/pgpm.plan', 'auth:@v2.0.0')
 * // Returns: 'users/table'
 */
export declare const resolveTagToChangeName: (planPath: string, tagReference: string, currentProject?: string) => string;
