"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cleanSql = void 0;
const pgsql_parser_1 = require("pgsql-parser");
const filterStatements = (stmts) => {
    const filteredStmts = stmts.filter(node => {
        const stmt = node.stmt;
        return stmt && !stmt.hasOwnProperty('TransactionStmt');
    });
    const hasFiltered = filteredStmts.length !== stmts.length;
    return { filteredStmts, hasFiltered };
};
const cleanSql = async (sql, pretty, functionDelimiter) => {
    const parsed = await (0, pgsql_parser_1.parse)(sql);
    const { filteredStmts, hasFiltered } = filterStatements(parsed.stmts);
    if (!hasFiltered) {
        return sql;
    }
    parsed.stmts = filteredStmts;
    const finalSql = await (0, pgsql_parser_1.deparse)(parsed, {
        pretty,
        functionDelimiter
    });
    return finalSql;
};
exports.cleanSql = cleanSql;
