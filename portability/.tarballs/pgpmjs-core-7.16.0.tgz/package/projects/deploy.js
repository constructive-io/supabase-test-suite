"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.deployProject = void 0;
const env_1 = require("@pgpmjs/env");
const logger_1 = require("@pgpmjs/logger");
const types_1 = require("@pgpmjs/types");
const path_1 = require("path");
const path = __importStar(require("path"));
const pg_cache_1 = require("pg-cache");
const materialize_1 = require("../apply/materialize");
const apply_spec_1 = require("../apply/apply-spec");
const deploy_bundled_1 = require("../bundle/deploy-bundled");
const pgpm_1 = require("../core/class/pgpm");
const extensions_1 = require("../extensions");
const client_1 = require("../migrate/client");
const deps_1 = require("../resolution/deps");
const log = new logger_1.Logger('deploy');
const deployProject = async (opts, name, database, pkg, toChange) => {
    const mergedOpts = (0, env_1.getEnvOptions)(opts);
    log.info(`🔍 Gathering modules from ${pkg.workspacePath}...`);
    const modules = pkg.getModuleMap();
    if (!modules[name]) {
        log.error(`❌ Module "${name}" not found in modules list.`);
        throw types_1.errors.MODULE_NOT_FOUND({ name });
    }
    const modulePath = path.resolve(pkg.workspacePath, modules[name].path);
    log.info(`📦 Resolving dependencies for ${name}...`);
    // Proxy (apply-spec) modules have no pgpm.plan, so resolve straight off the
    // workspace module map instead of instantiating a module-rooted package.
    const extensions = (0, apply_spec_1.hasApplySpec)(modulePath)
        ? (0, deps_1.resolveExtensionDependencies)(name, modules)
        : new pgpm_1.PgpmPackage(modulePath, { extensionsDir: pkg.extensionsDir }).getModuleExtensions();
    const pgPool = (0, pg_cache_1.getPgPool)({ ...opts.pg, database });
    // Local modules (in resolve order) that may carry an `extensions.json`
    // declaring how an external extension should be installed (schema + grants).
    const localModules = extensions.resolved.filter((m) => !extensions.external.includes(m));
    const roleMap = (0, extensions_1.roleMapFromRoles)(mergedOpts.db?.roles);
    log.success(`🚀 Starting deployment to database ${database}...`);
    for (const extension of extensions.resolved) {
        try {
            if (extensions.external.includes(extension)) {
                const install = (0, extensions_1.findExtensionInstall)(extension, localModules, modules, pkg.workspacePath, { roleMap });
                if (install) {
                    log.info(`📥 Installing external extension (declarative): ${extension}`);
                    for (const stmt of install.deploy) {
                        log.debug(`> ${stmt}`);
                        await pgPool.query(stmt);
                    }
                }
                else {
                    const msg = `CREATE EXTENSION IF NOT EXISTS "${extension}" CASCADE;`;
                    log.info(`📥 Installing external extension: ${extension}`);
                    log.debug(`> ${msg}`);
                    await pgPool.query(msg);
                }
            }
            else {
                const sourcePath = (0, path_1.resolve)(pkg.workspacePath, modules[extension].path);
                const modulePath = await (0, materialize_1.resolveEffectiveModulePath)(extension, sourcePath, modules, pkg.workspacePath);
                log.info(`📂 Deploying local module: ${extension}`);
                log.debug(`→ Path: ${modulePath}`);
                if (modulePath !== sourcePath) {
                    log.info(`🔁 Applying transpiled module (spec in ${sourcePath})`);
                }
                // The fast strategy is opt-in; everything else uses the per-change path.
                if (mergedOpts.deployment.fast || mergedOpts.deployment.bundled) {
                    // Fast strategy: execute the module in one shot AND record the
                    // migration ledger, from the pre-built bundle artifact when one
                    // verifies and from `deploy/` otherwise. If the semantics cannot be
                    // honoured, fall through to the per-change migration path rather than
                    // deploying without a ledger.
                    const outcome = await (0, deploy_bundled_1.deployModuleFast)(modulePath, {
                        config: { ...mergedOpts.pg, database },
                        logOnly: mergedOpts.deployment.logOnly,
                        useTransaction: mergedOpts.deployment.useTx,
                        hashMethod: mergedOpts.deployment.hashMethod
                    });
                    if ((0, deploy_bundled_1.isBundledDeployResult)(outcome)) {
                        continue;
                    }
                    log.info(`↩️ Fast deploy unavailable for ${extension} (${outcome}); using per-change path.`);
                }
                {
                    // Use new migration system
                    log.debug(`→ Command: constructive migrate deploy db:pg:${database}`);
                    try {
                        const client = new client_1.PgpmMigrate(mergedOpts.pg);
                        const result = await client.deploy({
                            modulePath,
                            toChange,
                            useTransaction: mergedOpts.deployment.useTx,
                            logOnly: mergedOpts.deployment.logOnly
                        });
                        if (result.failed) {
                            throw types_1.errors.OPERATION_FAILED({ operation: 'Deployment', target: result.failed });
                        }
                    }
                    catch (deployError) {
                        log.error(`❌ Deployment failed for module ${extension}`);
                        console.error(deployError);
                        throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Deployment', module: extension });
                    }
                }
            }
        }
        catch (err) {
            log.error(`🛑 Error during deployment: ${err instanceof Error ? err.message : err}`);
            console.error(err); // Keep raw error output for stack traces
            throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Deployment', module: extension });
        }
    }
    log.success(`✅ Deployment complete for ${name}.`);
    return extensions;
};
exports.deployProject = deployProject;
