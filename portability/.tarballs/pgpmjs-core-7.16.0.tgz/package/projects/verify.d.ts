import { PgpmOptions } from '@pgpmjs/types';
import { PgpmPackage } from '../core/class/pgpm';
interface Extensions {
    resolved: string[];
    external: string[];
}
export declare const verifyProject: (opts: PgpmOptions, name: string, database: string, pkg: PgpmPackage, options?: {}) => Promise<Extensions>;
export {};
