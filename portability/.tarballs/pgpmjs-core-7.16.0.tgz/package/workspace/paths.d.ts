/**
 * Finds the module path by looking for pgpm.plan.
 * @param cwd - Current working directory.
 * @returns A promise that resolves to the directory path containing `pgpm.plan`.
 */
export declare const modulePath: (cwd?: string) => string;
/**
 * Finds the pgpm project path.
 * @param cwd - Current working directory.
 * @returns A promise that resolves to the directory path containing `pgpm.json`.
 */
export declare const pgpmPath: (cwd?: string) => string;
export declare const getWorkspacePath: (cwd: string) => string;
export declare const getModulePath: (cwd: string) => string;
