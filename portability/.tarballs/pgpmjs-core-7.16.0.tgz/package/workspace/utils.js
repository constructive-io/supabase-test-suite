"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sluggify = exports.walkUp = void 0;
const fs_1 = require("fs");
const path_1 = require("path");
const types_1 = require("@pgpmjs/types");
/**
 * Recursively walks up directories to find a specific file (sync version).
 * @param startDir - Starting directory.
 * @param filename - The target file to search for.
 * @returns The directory path containing the file.
 */
const walkUp = (startDir, filename) => {
    let currentDir = (0, path_1.resolve)(startDir);
    while (currentDir) {
        const targetPath = (0, path_1.resolve)(currentDir, filename);
        if ((0, fs_1.existsSync)(targetPath)) {
            return currentDir;
        }
        const parentDir = (0, path_1.dirname)(currentDir);
        if (parentDir === currentDir) {
            break;
        }
        currentDir = parentDir;
    }
    throw types_1.errors.FILE_NOT_FOUND({ filePath: filename, type: 'configuration' });
};
exports.walkUp = walkUp;
const sluggify = (text) => {
    return text.toString().toLowerCase().trim()
        .replace(/\s+/g, '-') // Replace spaces with -
        .replace(/&/g, '-and-') // Replace & with 'and'
        .replace(/[^\w\-]+/g, '') // Remove all non-word chars
        .replace(/\-\-+/g, '-'); // Replace multiple - with single -
};
exports.sluggify = sluggify;
