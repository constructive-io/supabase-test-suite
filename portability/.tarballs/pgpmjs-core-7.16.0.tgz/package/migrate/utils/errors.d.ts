import { QueryHistoryEntry } from './transaction';
/**
 * Get error output configuration from environment variables with defaults.
 * Uses centralized env var parsing from @pgpmjs/env and defaults from @pgpmjs/types.
 */
export declare const getErrorOutputConfig: () => {
    queryHistoryLimit: number;
    maxLength: number;
    verbose: boolean;
};
/**
 * Format query history with smart collapsing and limiting
 */
export declare function formatQueryHistory(history: QueryHistoryEntry[]): string[];
/**
 * Truncate error output if it exceeds the max length
 */
export declare function truncateErrorOutput(lines: string[]): string[];
