"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pgpmDefaults = exports.DEFAULT_EXTENSIONS_DIR = void 0;
exports.getGitConfigInfo = getGitConfigInfo;
const child_process_1 = require("child_process");
/**
 * Default directory (relative to the workspace root) where pgpm modules are installed.
 */
exports.DEFAULT_EXTENSIONS_DIR = 'extensions';
/**
 * Default configuration values for PGPM framework
 */
exports.pgpmDefaults = {
    db: {
        rootDb: 'postgres',
        prefix: 'db-',
        extensions: [],
        cwd: process.cwd(),
        connections: {
            app: {
                user: 'app_user',
                password: 'app_password'
            },
            admin: {
                user: 'app_admin',
                password: 'admin_password'
            }
        },
        roles: {
            anonymous: 'anonymous',
            authenticated: 'authenticated',
            administrator: 'administrator',
            default: 'anonymous'
        },
        useLocksForRoles: false
    },
    pg: {
        host: 'localhost',
        port: 5432,
        user: 'postgres',
        password: 'password',
        database: 'postgres'
    },
    server: {
        host: 'localhost',
        port: 3000,
        trustProxy: false,
        strictAuth: false
    },
    cdn: {
        provider: 'minio',
        bucketName: 'test-bucket',
        awsRegion: 'us-east-1',
        awsAccessKey: 'minioadmin',
        awsSecretKey: 'minioadmin',
        endpoint: 'http://localhost:9000',
        publicUrlPrefix: 'http://localhost:9000'
    },
    deployment: {
        useTx: true,
        fast: false,
        bundled: false,
        usePlan: true,
        cache: false,
        logOnly: false,
        hashMethod: 'content'
    },
    migrations: {
        codegen: {
            useTx: false
        }
    },
    errorOutput: {
        queryHistoryLimit: 30,
        maxLength: 10000,
        verbose: false
    },
    extensionsDir: exports.DEFAULT_EXTENSIONS_DIR,
    smtp: {
        port: 587,
        secure: false,
        pool: false,
        logger: false,
        debug: false
    }
};
function getGitConfigInfo() {
    const isTestEnv = process.env.NODE_ENV === 'test' ||
        process.env.NODE_ENV === 'testing' || // fallback
        process.env.GITHUB_ACTIONS === 'true'; // GitHub Actions
    if (isTestEnv) {
        return {
            username: 'CI Test User',
            email: 'ci@example.com'
        };
    }
    let username = '';
    let email = '';
    try {
        username = (0, child_process_1.execSync)('git config --global user.name', {
            encoding: 'utf8'
        }).trim();
    }
    catch {
        username = '';
    }
    try {
        email = (0, child_process_1.execSync)('git config --global user.email', {
            encoding: 'utf8'
        }).trim();
    }
    catch {
        email = '';
    }
    return { username, email };
}
