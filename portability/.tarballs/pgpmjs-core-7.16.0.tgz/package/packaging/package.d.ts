export declare const cleanTree: (tree: any) => any;
interface PackageModuleOptions {
    usePlan?: boolean;
    extension?: boolean;
    pretty?: boolean;
    functionDelimiter?: string;
    outputDiff?: boolean;
}
interface WritePackageOptions extends PackageModuleOptions {
    version: string;
    packageDir: string;
    /**
     * Also emit the content-addressed bundle artifact
     * `sql/<name>--<version>.bundle.tar.gz` (default true). It is what
     * `deploy --bundled` consumes.
     */
    bundle?: boolean;
}
export interface MergeSqlOptions {
    /** Strip `TransactionStmt`/`CreateExtensionStmt` before deparsing (extension mode) */
    stripTransactions?: boolean;
    /** Prepend a `\echo ... \quit` extension guard line */
    echoExtensionName?: string;
    pretty?: boolean;
    functionDelimiter?: string;
}
/**
 * Merge a concatenated SQL string into a single deparsed script.
 *
 * Parses the input, optionally strips transaction/extension statements, deparses
 * with a stable function delimiter, and round-trips the result to detect any AST
 * drift. This is the shared engine behind `packageModule` (whole-module packaging)
 * and per-chunk rebundling — both must merge statements identically.
 */
export declare const mergeSqlStatements: (sql: string, { stripTransactions, echoExtensionName, pretty, functionDelimiter }?: MergeSqlOptions) => Promise<{
    sql: string;
    diff?: boolean;
    tree1?: string;
    tree2?: string;
}>;
export declare const packageModule: (packageDir: string, { usePlan, extension, pretty, functionDelimiter }?: PackageModuleOptions) => Promise<{
    sql: string;
    diff?: boolean;
    tree1?: string;
    tree2?: string;
}>;
export declare const writePackage: ({ version, extension, usePlan, packageDir, outputDiff, bundle, }: WritePackageOptions) => Promise<void>;
export {};
