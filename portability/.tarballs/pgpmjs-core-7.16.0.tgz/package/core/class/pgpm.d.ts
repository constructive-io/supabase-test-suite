import { PgpmOptions, PgpmWorkspaceConfig } from '@pgpmjs/types';
import { PgConfig } from 'pg-env';
import { ExtensionInfo } from '@pgpmjs/ast/files';
import { PackageAnalysisResult, RenameOptions } from '@pgpmjs/ast/files/types';
import { ModuleMap } from '../../modules/modules';
import { SyncVersionsOptions, SyncVersionsResult } from '../../packaging/sync-versions';
/**
 * Options accepted by the {@link PgpmPackage} constructor.
 */
export interface PgpmPackageOptions {
    /**
     * Directory (relative to the workspace root) where pgpm modules are installed.
     * Takes precedence over `PGPM_EXTENSIONS_DIR` and the `extensionsDir` config
     * field. Defaults to `extensions`.
     */
    extensionsDir?: string;
}
export declare enum PackageContext {
    Outside = "outside",
    Workspace = "workspace-root",
    Module = "module",
    ModuleInsideWorkspace = "module-in-workspace"
}
export interface InitModuleOptions {
    name: string;
    description: string;
    author: string;
    extensions: string[];
    branch?: string;
    templateRepo?: string;
    templatePath?: string;
    /** Override the base directory for template resolution (e.g., 'supabase', 'drizzle') */
    dir?: string;
    cacheTtlMs?: number;
    noTty?: boolean;
    toolName?: string;
    answers?: Record<string, any>;
    /**
     * Parent directory where the module should be created.
     * When provided, bypasses createModuleDirectory() and creates the module at outputDir/name.
     * Must be an absolute path or relative to workspace root.
     */
    outputDir?: string;
    /**
     * Whether this is a pgpm-managed module that should create pgpm.plan and .control files.
     * Defaults to true for backward compatibility.
     */
    pgpm?: boolean;
    /**
     * Optional Inquirerer instance to reuse for prompting during template scaffolding.
     * If provided, prevents creating a duplicate instance on process.stdin which
     * would cause double-echoed keystrokes and other input conflicts.
     * The caller retains ownership and is responsible for closing it.
     */
    prompter?: import('inquirerer').Inquirerer;
}
export declare class PgpmPackage {
    cwd: string;
    workspacePath?: string;
    modulePath?: string;
    config?: PgpmWorkspaceConfig;
    allowedDirs: string[];
    allowedParentDirs: string[];
    /**
     * Directory name (relative to the workspace root) where pgpm modules are installed.
     * Resolved from the constructor option, `PGPM_EXTENSIONS_DIR`, the `extensionsDir`
     * config field, then the `extensions` default.
     */
    extensionsDir: string;
    private readonly options;
    private _moduleMap?;
    private _moduleInfo?;
    constructor(cwd?: string, options?: PgpmPackageOptions);
    resetCwd(cwd: string): void;
    /**
     * Absolute path of the workspace directory where pgpm modules are installed.
     */
    getExtensionsPath(): string;
    private resolveSqitchPath;
    private loadConfigSync;
    private loadAllowedDirs;
    private loadAllowedParentDirs;
    isInsideAllowedDirs(cwd: string): boolean;
    isParentOfAllowedDirs(cwd: string): boolean;
    private createModuleDirectory;
    ensureModule(): void;
    ensureWorkspace(): void;
    getContext(): PackageContext;
    isInWorkspace(): boolean;
    isInModule(): boolean;
    getWorkspacePath(): string | undefined;
    getModulePath(): string | undefined;
    clearCache(): void;
    getModules(): Promise<PgpmPackage[]>;
    /**
     * List all modules by parsing .control files in the workspace directory.
     * Handles naming collisions by preferring the shortest path.
     */
    listModules(): ModuleMap;
    /**
     * Discover apply-spec proxy modules (`pgpm.apply.json`) and synthesize
     * module-map entries for them so they participate in dependency resolution
     * by name like any other module. A proxy needs no `.control` or `pgpm.plan`;
     * its `requires` default to the source module's requires. Control-file
     * modules win name collisions.
     */
    private addApplyModules;
    getModuleMap(): ModuleMap;
    getAvailableModules(): Promise<string[]>;
    getModuleProject(name: string): PgpmPackage;
    getModuleInfo(): ExtensionInfo;
    getModuleName(): string;
    getRequiredModules(): string[];
    setModuleDependencies(modules: string[]): void;
    private validateModuleDependencies;
    private initModuleSqitch;
    initModule(options: InitModuleOptions): Promise<void>;
    getLatestChange(moduleName: string): string;
    getLatestChangeAndVersion(moduleName: string): {
        change: string;
        version: string;
    };
    getModuleExtensions(): {
        resolved: string[];
        external: string[];
    };
    getModuleDependencies(moduleName: string): {
        native: string[];
        modules: string[];
    };
    getModuleDependencyChanges(moduleName: string): {
        native: string[];
        modules: {
            name: string;
            latest: string;
            version: string;
        }[];
    };
    getModulePlan(): string;
    getModuleControlFile(): string;
    getModuleMakefile(): string;
    getModuleSQL(): string;
    generateModulePlan(options: {
        uri?: string;
        includePackages?: boolean;
        includeTags?: boolean;
    }): string;
    writeModulePlan(options: {
        uri?: string;
        includePackages?: boolean;
        includeTags?: boolean;
    }): void;
    /**
     * Add a tag to the current module's plan file
     */
    addTag(tagName: string, changeName?: string, comment?: string): void;
    /**
     * Add a change to the current module's plan file and create SQL files
     */
    addChange(changeName: string, dependencies?: string[], comment?: string): void;
    /**
     * Add change to the current module (internal helper)
     */
    private addChangeToModule;
    /**
     * Create deploy/revert/verify SQL files for a change
     */
    private createSqlFiles;
    publishToDist(distFolder?: string): void;
    /**
      * Installs an extension npm package into the workspace extensions directory.
      *
      * When run inside a module, the installed version is recorded in the
      * module's package.json dependencies and its .control requires list.
      * When run at the workspace root, the installed version is recorded in
      * the workspace pgpm.json `dependencies` field instead — no .control
      * file is needed.
      */
    installModules(...pkgstrs: string[]): Promise<void>;
    /**
     * Returns the workspace-level pgpm module dependencies recorded in
     * the workspace pgpm.json `dependencies` field.
     */
    getWorkspaceDependencies(): Record<string, string>;
    /**
     * Records installed module versions into the workspace pgpm.json
     * `dependencies` field. No-op when the workspace uses pgpm.config.js.
     */
    recordWorkspaceDependencies(versions: Record<string, string>): void;
    /**
     * Installs the workspace-level dependencies declared in pgpm.json into
     * the workspace extensions/ directory. Skips modules already present
     * unless `force` is set.
     *
     * @returns The list of installed package specs (name@version)
     */
    installWorkspaceDependencies(options?: {
        force?: boolean;
    }): Promise<string[]>;
    /**
     * Returns information about which of the specified modules are installed.
     * Checks the module's package.json dependencies to determine installation status.
     *
     * @param moduleNames - Array of npm package names to check (e.g., '@pgpm/base32')
     * @returns Object with installed (array of installed module names) and
     *          installedVersions (map of module name to installed version)
     */
    modulesInstalled(moduleNames: string[]): {
        installed: string[];
        installedVersions: Record<string, string>;
    };
    /**
     * Returns all installed pgpm modules from the module's package.json dependencies.
     * Only returns dependencies that exist in the workspace extensions directory.
     *
     * @returns Object with installed module names and their versions
     */
    getInstalledModules(): {
        installed: string[];
        installedVersions: Record<string, string>;
    };
    /**
     * Returns all pgpm modules installed in the workspace extensions directory.
     * Unlike getInstalledModules(), this does NOT require being inside a module.
     * It scans the workspace/extensions/ directory directly to find installed packages.
     *
     * This is useful for checking what's available at workspace level before a module exists.
     *
     * @returns Array of installed npm package names (e.g., '@pgpm/base32', '@pgpm/totp')
     */
    getWorkspaceInstalledModules(): string[];
    /**
     * Updates installed pgpm modules to their latest versions from npm.
     * Re-installs each module to get the latest version.
     * Also updates package.json for ALL modules in the workspace that reference the upgraded packages.
     *
     * Note: Extensions are installed globally in the workspace's extensions/ directory,
     * so upgrading affects all modules that depend on the upgraded package.
     *
     * @param options - Options for the update operation
     * @param options.modules - Specific modules to update (defaults to all installed modules)
     * @param options.dryRun - If true, only returns what would be updated without making changes
     * @returns Object with updated modules and their old/new versions
     */
    upgradeModules(options?: {
        modules?: string[];
        dryRun?: boolean;
    }): Promise<{
        updates: Array<{
            name: string;
            oldVersion: string;
            newVersion: string | null;
        }>;
        affectedModules: string[];
    }>;
    /**
     * Updates package.json dependencies for all modules in the workspace that reference
     * the specified packages with their new versions.
     *
     * @param packageVersions - Map of package name to new version
     * @returns Array of module names that were updated
     */
    private updateWorkspaceModuleVersions;
    /**
     * Sync extension metadata (.control default_version, Makefile sql filename,
     * and the sql/<name>--<version>.sql bundle) to the package.json version.
     * Inside a module, syncs just that module; at a workspace root, syncs every
     * workspace module. With `check: true`, reports skew without writing.
     */
    syncVersions(options?: SyncVersionsOptions): Promise<SyncVersionsResult>;
    /**
     * Get the set of modules that have been deployed to the database
     */
    private getDeployedModules;
    resolveWorkspaceExtensionDependencies(opts?: {
        filterDeployed?: boolean;
        pgConfig?: PgConfig;
    }): Promise<{
        resolved: string[];
        external: string[];
    }>;
    /**
     * Dependency closure for a named module. Proxy (apply-spec) modules have no
     * pgpm.plan, so they resolve straight off the workspace module map instead
     * of instantiating a module-rooted package.
     */
    private getModuleExtensionsFor;
    /**
     * Directory the migration engine should run against for a named module:
     * the module's own directory, or — for proxy (apply-spec) modules — the
     * materialized transpiled instance.
     */
    private getEffectiveModulePathFor;
    private parsePackageTarget;
    deploy(opts: PgpmOptions, target?: string, recursive?: boolean): Promise<void>;
    /**
     * Reverts database changes for modules. Unlike verify operations, revert operations
     * modify database state and must ensure dependent modules are reverted before their
     * dependencies to prevent database constraint violations.
     */
    revert(opts: PgpmOptions, target?: string, recursive?: boolean): Promise<void>;
    verify(opts: PgpmOptions, target?: string, recursive?: boolean): Promise<void>;
    removeFromPlan(toChange: string): Promise<void>;
    analyzeModule(): PackageAnalysisResult;
    renameModule(newName: string, opts?: RenameOptions): {
        changed: string[];
        warnings: string[];
    };
}
