"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.materializeApplyModule = materializeApplyModule;
exports.resolveEffectiveModulePath = resolveEffectiveModulePath;
exports.clearApplyMaterializationCache = clearApplyMaterializationCache;
const fs_1 = require("fs");
const os_1 = require("os");
const path_1 = require("path");
const bundle_1 = require("@pgpmjs/bundle");
const transform_1 = require("@pgpmjs/transform");
const slice_1 = require("@pgpmjs/slice");
const apply_spec_1 = require("./apply-spec");
const profile_1 = require("./profile");
const reuse_1 = require("./reuse");
// Functions that take a bare schema name as a string-literal first argument.
// The AST pass only remaps dotted literals ('schema.object'); these helpers
// (ubiquitous in verify scripts) name the schema alone, so a string-level
// pre-pass remaps them.
const SCHEMA_NAME_LITERAL_FUNCS = ['verify_schema', 'has_schema_privilege'];
const schemaNameLiteralPass = (content, schemaMapping) => {
    const pattern = new RegExp(`\\b(${SCHEMA_NAME_LITERAL_FUNCS.join('|')})\\s*\\(\\s*'([^']+)'`, 'gi');
    return content.replace(pattern, (match, _fn, schema) => {
        const mapped = schemaMapping.get(schema);
        return mapped ? match.replace(`'${schema}'`, `'${mapped}'`) : match;
    });
};
/**
 * Build the per-script subsystem stripper for an `exclude` spec, verifying
 * cascade safety across the *whole* source bundle first: every deploy-script
 * reference into an excluded schema (FKs, calls, policy predicates) must have
 * a rebind route, or materialization refuses with each unsatisfied reference
 * named. Checking bundle-wide (not per script) is what catches cross-change
 * dependencies on the excluded subsystem.
 */
function makeSubsystemStripper(source, spec, instanceName) {
    const selector = { schemas: spec.exclude.schemas };
    const rebinds = (0, transform_1.buildSchemaRouter)({ schemaMap: spec.schemas, routes: spec.route });
    const fullDeploySql = source.changes
        .map(c => c.deploy?.sql ?? '')
        .filter(Boolean)
        .join('\n');
    const analysis = (0, slice_1.excludeSubsystem)(fullDeploySql, selector, { rebinds });
    if (analysis.unsatisfied.length > 0) {
        const detail = [
            ...new Set(analysis.unsatisfied.map(u => `${u.object.schema}.${u.object.name}${u.fk ? ' (foreign key target)' : ''}`))
        ].join(', ');
        throw new Error(`Cannot exclude schema(s) ${spec.exclude.schemas.join(', ')} from ` +
            `"${spec.source.module}" as "${instanceName}": surviving statements still reference ` +
            `${detail} with no route/rebind target. Add "route" entries substituting each ` +
            `referenced object, or keep the subsystem.`);
    }
    // A change whose deploy consists entirely of subsystem statements (plus
    // transaction control) is excluded *as a change*: its verify/revert scripts
    // target dropped objects the classifier can't always see (bare DROPs,
    // catalog probes), so all three scripts are blanked together.
    const excludedChanges = new Set();
    for (const change of source.changes) {
        if (!change.deploy)
            continue;
        const stripped = (0, slice_1.stripSubsystemSql)(change.deploy.sql, selector);
        const survivors = stripped.result.kept.filter(i => !stripped.dropped.includes(i) && stripped.result.statements[i].nodeTag !== 'TransactionStmt');
        if (stripped.dropped.length > 0 && survivors.length === 0) {
            excludedChanges.add(change.name);
        }
    }
    const strip = (sql, change) => excludedChanges.has(change) ? (0, slice_1.blankScriptSql)(sql) : (0, slice_1.stripSubsystemSql)(sql, selector).sql;
    return { strip, excludedChanges };
}
/**
 * Transpile a source module per an apply spec and materialize the result as a
 * deployable module directory carrying the instance's identity.
 *
 * Pure pipeline over existing primitives: `bundleFromModule` →
 * `transpileBundle(makeSchemaTranspiler)` → `verifyBundle` →
 * `materializeBundle`. Deterministic — identical source + spec always produce
 * an identical bundle (and digest), which is what makes verify/revert able to
 * re-derive the exact deployed artifact.
 */
async function materializeApplyModule(options) {
    const { sourceDir, spec } = options;
    const instanceName = spec.name;
    // the schema transpiler's SQL/PLpgSQL parser is WASM-backed and needs a
    // one-time async init (idempotent)
    await (0, transform_1.loadModule)();
    const source = (0, bundle_1.bundleFromModule)(sourceDir);
    if (spec.source.bundleDigest && spec.source.bundleDigest !== source.manifest.digest) {
        throw new Error(`Apply spec for "${instanceName}" pins source bundle digest ${spec.source.bundleDigest}, ` +
            `but the installed source "${spec.source.module}" hashes to ${source.manifest.digest}. ` +
            `Reinstall the pinned version or update the spec.`);
    }
    // Every distinct target schema is treated as "may already exist": apply
    // deploys into consumer-chosen namespaces that can pre-exist (a shared schema,
    // another tenant), so `CREATE SCHEMA` is emitted idempotently. This is what
    // lets the same source apply cleanly whether or not the destination exists.
    const targetSchemas = [
        ...new Set([
            ...Object.values(spec.schemas ?? {}),
            ...(spec.route ?? [])
                .map(r => r.toSchema)
                .filter((s) => typeof s === 'string')
        ])
    ];
    const stripSubsystem = spec.exclude
        ? makeSubsystemStripper(source, spec, instanceName)
        : undefined;
    const { renameChange, transformScript, result } = (0, transform_1.makeSchemaTranspiler)({
        schemaMap: spec.schemas,
        routes: spec.route,
        extensions: spec.extensions,
        roles: spec.roles,
        transform: {
            prePasses: [schemaNameLiteralPass],
            assumeSchemasExist: targetSchemas
        }
    });
    // Excluded changes keep their source identity (an emptied tombstone) —
    // renaming them into the replacement provider's namespace would be a lie.
    const transpiled = (0, bundle_1.transpileBundle)(source, {
        renameChange: stripSubsystem
            ? (name) => (stripSubsystem.excludedChanges.has(name) ? name : renameChange(name))
            : renameChange,
        transformScript: stripSubsystem
            ? (sql, ctx) => transformScript(stripSubsystem.strip(sql, ctx.change), ctx)
            : transformScript,
        renameModule: instanceName,
        provenance: {
            appliedFrom: spec.source.module,
            ...(spec.source.package ? { sourcePackage: spec.source.package } : {}),
            ...(spec.source.version ? { sourceVersion: spec.source.version } : {})
        }
    });
    if (result.errors.length > 0) {
        const detail = result.errors.map(e => `${e.file}: ${e.error}`).join('; ');
        throw new Error(`Apply transpile of "${spec.source.module}" as "${instanceName}" failed: ${detail}`);
    }
    const issues = (0, bundle_1.verifyBundle)(transpiled);
    if (issues.length > 0) {
        throw new Error(`Transpiled bundle for "${instanceName}" failed integrity verification: ` +
            issues.map(i => i.kind).join(', '));
    }
    const outDir = options.outDir ?? (0, fs_1.mkdtempSync)((0, path_1.join)((0, os_1.tmpdir)(), `pgpm-apply-${instanceName}-`));
    (0, bundle_1.materializeBundle)(transpiled, outDir);
    return { bundle: transpiled, outDir };
}
// One materialization per proxy path per process: the pipeline is
// deterministic, so re-deriving within a process is pure waste.
const materializedCache = new Map();
/**
 * Deploy-path dispatch seam: given a resolved module's directory, return the
 * directory the migration engine should actually run against.
 *
 * Non-proxy modules pass through unchanged. For proxy modules (directories
 * carrying a `pgpm.apply.json`), the source module is located in the workspace
 * module map, transpiled per the spec, and materialized to a cached temp dir
 * carrying the instance's identity.
 */
async function resolveEffectiveModulePath(moduleName, modulePath, moduleMap, workspacePath) {
    if (!(0, apply_spec_1.hasApplySpec)(modulePath))
        return modulePath;
    // A reuse proxy resolves under two names (shared + per-tenant) from one
    // directory, so the cache is keyed by the requested module name too.
    const cacheKey = `${modulePath}::${moduleName}`;
    const cached = materializedCache.get(cacheKey);
    if (cached)
        return cached;
    const spec = (0, profile_1.resolveEffectiveApplySpec)((0, apply_spec_1.readApplySpec)(modulePath), (0, profile_1.loadWorkspaceRoutingProfile)(workspacePath));
    const sourceModule = moduleMap[spec.source.module];
    if (!sourceModule) {
        throw new Error(`Apply spec in "${moduleName}" references source module "${spec.source.module}", ` +
            `which was not found in the workspace. Run \`pgpm install\` to install it` +
            (spec.source.package ? ` (${spec.source.package})` : '') +
            `.`);
    }
    const sourceDir = (0, path_1.resolve)(workspacePath, sourceModule.path);
    if ((0, reuse_1.isReuseSpec)(spec)) {
        const result = await (0, reuse_1.materializeReuseModule)({ sourceDir, spec });
        materializedCache.set(`${modulePath}::${result.sharedName}`, result.shared.outDir);
        materializedCache.set(`${modulePath}::${result.perTenantName}`, result.perTenant.outDir);
        const outDir = moduleName === (0, reuse_1.resolveSharedModuleName)(spec) ? result.shared.outDir : result.perTenant.outDir;
        return outDir;
    }
    const { outDir } = await materializeApplyModule({ sourceDir, spec });
    materializedCache.set(cacheKey, outDir);
    return outDir;
}
/** Test seam: clear the per-process materialization cache. */
function clearApplyMaterializationCache() {
    materializedCache.clear();
}
