/**
 * PostgreSQL Error Formatting Utilities
 *
 * Extracts and formats extended PostgreSQL error fields from pg library errors.
 * These fields provide additional context for debugging database errors.
 */
/**
 * Extended PostgreSQL error fields available from pg-protocol.
 * These fields are populated by PostgreSQL when an error occurs.
 */
export interface PgErrorFields {
    /** PostgreSQL error code (e.g., '42P01' for undefined table) */
    code?: string;
    /** Additional detail about the error */
    detail?: string;
    /** Suggestion for fixing the error */
    hint?: string;
    /** PL/pgSQL call stack or context */
    where?: string;
    /** Character position in the query where the error occurred */
    position?: string;
    /** Position in internal query */
    internalPosition?: string;
    /** Internal query that caused the error */
    internalQuery?: string;
    /** Schema name related to the error */
    schema?: string;
    /** Table name related to the error */
    table?: string;
    /** Column name related to the error */
    column?: string;
    /** Data type name related to the error */
    dataType?: string;
    /** Constraint name related to the error */
    constraint?: string;
    /** Source file in PostgreSQL where error was generated */
    file?: string;
    /** Line number in PostgreSQL source file */
    line?: string;
    /** PostgreSQL routine that generated the error */
    routine?: string;
}
/**
 * Context about the query that caused the error.
 */
export interface PgErrorContext {
    /** The SQL query that was executed */
    query?: string;
    /** Parameter values passed to the query */
    values?: any[];
}
/**
 * Extract PostgreSQL error fields from an error object.
 * Returns null if the error doesn't appear to be a PostgreSQL error.
 *
 * @param err - The error object to extract fields from
 * @returns PgErrorFields if the error has PG fields, null otherwise
 */
export declare function extractPgErrorFields(err: unknown): PgErrorFields | null;
/**
 * Format PostgreSQL error fields into an array of human-readable lines.
 * Only includes fields that are present and non-empty.
 *
 * @param fields - The PostgreSQL error fields to format
 * @returns Array of formatted lines
 */
export declare function formatPgErrorFields(fields: PgErrorFields): string[];
/**
 * Format a PostgreSQL error with full context for debugging.
 * Combines the original error message with extended PostgreSQL fields
 * and optional query context.
 *
 * @param err - The error object
 * @param context - Optional query context (SQL and parameters)
 * @returns Formatted error string with all available information
 */
export declare function formatPgError(err: unknown, context?: PgErrorContext): string;
