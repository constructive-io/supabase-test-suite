import { PgpmModuleAst } from '@pgpmjs/ast/module/types';
import { MigrationBundle } from './types';
/** Executable deploy SQL per change name, as produced at package time. */
export type ExecSqlByChange = Record<string, string>;
/**
 * Digest for a single change: its name plus the digests of its scripts, in a
 * fixed deploy/revert/verify order. A missing script contributes an empty slot
 * so presence/absence changes the digest.
 */
export declare function computeChangeDigest(name: string, scripts: {
    deploy?: string | null;
    revert?: string | null;
    verify?: string | null;
    /**
     * Digest of the pre-computed executable deploy SQL. Only contributes when
     * defined, so digests of bundles without an `exec` slot are unchanged.
     */
    exec?: string | null;
}): string;
/**
 * Top-level bundle digest: the plan, the control content, and the ordered change
 * digests. Deterministic and independent of tool version / provenance.
 */
export declare function computeBundleDigest(plan: string, controlContent: string | null, changeDigests: string[]): string;
export interface CreateBundleOptions {
    /** Tool identifier recorded in the manifest (default `@pgpmjs/core`). */
    createdWith?: string;
    /** Lineage recorded in the manifest (excluded from the digest). */
    provenance?: Record<string, string>;
}
/**
 * Build a content-addressed {@link MigrationBundle} from a module AST.
 *
 * Pure and deterministic: no disk I/O, no clock, no version noise in the digest.
 * The change order follows the module's plan order, which the AST already
 * preserves, so the bundle's `deployOrder` is dependency-safe by construction.
 */
export declare function createBundle(module: PgpmModuleAst, options?: CreateBundleOptions): MigrationBundle;
/**
 * Attach pre-computed executable deploy SQL to a bundle, re-deriving the
 * per-change and top-level digests so the artifact stays content-addressed.
 *
 * The `exec` SQL is the deploy script with transaction / `CREATE EXTENSION`
 * statements stripped — the form the deploy engine actually executes. Computing
 * it requires a SQL parser, which this layer deliberately does not depend on, so
 * the caller (`@pgpmjs/core` at package time) supplies it.
 *
 * Changes with no entry in `execSql` are left untouched.
 */
export declare function withExecutableSql(bundle: MigrationBundle, execSql: ExecSqlByChange): MigrationBundle;
