"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.globPaths = exports.globPattern = exports.toPosixPath = void 0;
const glob_1 = require("glob");
const path_1 = __importDefault(require("path"));
/**
 * Convert a native filesystem path to a posix-style path.
 * Windows path separators are not valid inside glob patterns.
 */
const toPosixPath = (p) => p.replace(/\\/g, '/');
exports.toPosixPath = toPosixPath;
/**
 * Join path segments into a glob pattern.
 *
 * `glob` treats `\` as an escape character on every platform, so a Windows
 * path produced by `path.join` silently matches nothing. Patterns must always
 * use forward slashes, which Windows accepts as a separator.
 */
const globPattern = (...segments) => (0, exports.toPosixPath)(path_1.default.join(...segments));
exports.globPattern = globPattern;
/**
 * Cross-platform `glob.sync` over path segments joined into a pattern.
 */
const globPaths = (...segments) => (0, glob_1.sync)((0, exports.globPattern)(...segments));
exports.globPaths = globPaths;
