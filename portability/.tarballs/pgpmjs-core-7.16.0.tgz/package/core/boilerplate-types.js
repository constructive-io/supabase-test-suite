"use strict";
/**
 * Boilerplate metadata types for the new metadata-driven resolution system.
 * These types support the `.boilerplate.json` and `.boilerplates.json` configuration files.
 */
Object.defineProperty(exports, "__esModule", { value: true });
