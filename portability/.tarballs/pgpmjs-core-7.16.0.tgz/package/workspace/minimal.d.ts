import { Change, Tag } from '@pgpmjs/ast/files/types';
declare const SCRIPT_DIRS: readonly ["deploy", "revert", "verify"];
export type MinimalScriptDir = (typeof SCRIPT_DIRS)[number];
/**
 * A single change's SQL scripts for a minimal module. `verify` is optional.
 */
export interface MinimalChangeScripts {
    deploy: string;
    revert: string;
    verify?: string;
}
export interface WriteMinimalModuleOptions {
    /** Module (extension) name */
    name: string;
    /** Plan changes, in order. Each must have a matching entry in `scripts`. */
    changes: Change[];
    /** SQL scripts keyed by change name */
    scripts: Record<string, MinimalChangeScripts>;
    /** Tags to include in the plan */
    tags?: Tag[];
    /** Extensions/modules this module requires (control `requires`) */
    requires?: string[];
    /** package.json version (default '0.0.1') */
    version?: string;
    /** package.json license (default 'CONSTRUCTIVE') */
    license?: string;
    /** Overwrite an existing directory (default: false) */
    overwrite?: boolean;
    /**
     * Write a minimal `package.json` (default: true). Set `false` to preserve an
     * existing one — e.g. when a richer package.json was already scaffolded by
     * `pgpm init` and only the pgpm files should be written on top.
     */
    writePackageJson?: boolean;
}
/**
 * The minimal set of files pgpm needs to recognize and deploy a module:
 * `pgpm.plan` (module marker + change order), `<name>.control` (extension
 * metadata), `Makefile` (PGXS packaging), `package.json`, and the
 * deploy/revert/verify scripts. Mirrors what `pgpm init` scaffolds, minus the
 * network-fetched boilerplate (README/LICENSE/jest/tests/lint configs).
 */
export declare function writeMinimalModule(moduleDir: string, options: WriteMinimalModuleOptions): void;
export interface WriteMinimalWorkspaceOptions {
    /** Workspace package globs (default: ['packages/*']) */
    packages?: string[];
    /** Overwrite an existing pgpm.json (default: true) */
    overwrite?: boolean;
}
/**
 * Write the minimal workspace marker (`pgpm.json`) so pgpm discovers the
 * directory as a workspace. This is what `getWorkspacePath` walks up to find.
 */
export declare function writeMinimalWorkspace(workspaceDir: string, options?: WriteMinimalWorkspaceOptions): void;
/**
 * Full extension control file, matching the shape `pgpm init` emits (comment,
 * default_version, module_pathname, requires, relocatable, superuser).
 */
export declare function generateModuleControl(name: string, requires?: string[], version?: string): string;
/**
 * PGXS Makefile for `pgpm package`/`make install`.
 */
export declare function generateModuleMakefile(name: string, version?: string): string;
export {};
