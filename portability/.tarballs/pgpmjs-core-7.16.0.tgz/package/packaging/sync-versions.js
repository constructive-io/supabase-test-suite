"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncModuleVersions = exports.getModuleVersionStatus = void 0;
const logger_1 = require("@pgpmjs/logger");
const fs_1 = require("fs");
const path_1 = require("path");
const files_1 = require("@pgpmjs/ast/files");
const package_1 = require("./package");
const log = new logger_1.Logger('sync-versions');
/**
 * Inspect a module directory and report whether its extension metadata
 * (.control default_version + sql bundle) matches the package.json version.
 */
const getModuleVersionStatus = (packageDir) => {
    const { extname, version, controlFile, sqlFile } = (0, files_1.getExtensionInfo)(packageDir);
    const { version: controlVersion } = (0, files_1.parseControlContent)((0, fs_1.readFileSync)(controlFile, 'utf-8'));
    const sqlFileExists = (0, fs_1.existsSync)((0, path_1.join)(packageDir, sqlFile));
    return {
        name: extname,
        packageDir,
        packageVersion: version,
        controlVersion,
        sqlFileExists,
        inSync: version === controlVersion && sqlFileExists
    };
};
exports.getModuleVersionStatus = getModuleVersionStatus;
/**
 * Bring a set of module directories back in sync with their package.json
 * versions by re-running the packaging flow (control file, Makefile, and
 * sql/<name>--<version>.sql regenerate from the package.json version).
 */
const syncModuleVersions = async (packageDirs, { check = false, usePlan = true } = {}) => {
    const result = { synced: [], skewed: [], ok: [] };
    for (const packageDir of packageDirs) {
        const status = (0, exports.getModuleVersionStatus)(packageDir);
        if (status.inSync) {
            result.ok.push(status);
            continue;
        }
        if (check) {
            result.skewed.push(status);
            log.warn(`✗ ${status.name}: package.json ${status.packageVersion} != control ${status.controlVersion}` +
                (status.sqlFileExists ? '' : ` (missing sql/${status.name}--${status.packageVersion}.sql)`));
            continue;
        }
        await (0, package_1.writePackage)({
            version: status.packageVersion,
            extension: true,
            usePlan,
            packageDir
        });
        result.synced.push(status);
        log.success(`✓ ${status.name}: synced to ${status.packageVersion}`);
    }
    return result;
};
exports.syncModuleVersions = syncModuleVersions;
