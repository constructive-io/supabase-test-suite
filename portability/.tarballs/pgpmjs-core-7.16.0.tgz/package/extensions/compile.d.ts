import { ExtensionProvide } from './manifest';
/** Result of compiling one `provides` entry into deployable SQL. */
export interface CompiledExtensionInstall {
    /** Deploy statements, in order (schema, extension, grants). */
    deploy: string[];
    /** Revert statements, in reverse order (drop extension, optionally schema). */
    revert: string[];
    /** Verify statements that error when the install is absent. */
    verify: string[];
}
export interface CompileExtensionInstallOptions {
    /**
     * Optional role-name map applied to grant targets (workspace portability
     * profile). Renames identifiers only — never touches privilege semantics.
     * Special roles (`PUBLIC`, `CURRENT_USER`, `SESSION_USER`) pass through.
     */
    roleMap?: Record<string, string>;
    /**
     * Control-file schema for a fixed-schema (non-relocatable) extension, when
     * known. Used to validate that a `false`-relocatable extension is only
     * "routed" to its own fixed schema.
     */
    fixedSchema?: string | null;
}
/**
 * Compile a single `provides` declaration into deploy / revert / verify SQL.
 *
 * Pure and deterministic: given the same input it returns byte-identical SQL,
 * with no dynamic `EXECUTE`. This is the nuts-and-bolts primitive; wiring it
 * into the deploy path (and eventually into real plan changes exempt from
 * `filterStatements` stripping) composes on top of it.
 */
export declare function compileExtensionInstall(extname: string, provide: ExtensionProvide, options?: CompileExtensionInstallOptions): CompiledExtensionInstall;
/** Compile every `provides` entry in a manifest, keyed by extension name. */
export declare function compileExtensionInstalls(provides: Record<string, ExtensionProvide>, options?: CompileExtensionInstallOptions): Record<string, CompiledExtensionInstall>;
