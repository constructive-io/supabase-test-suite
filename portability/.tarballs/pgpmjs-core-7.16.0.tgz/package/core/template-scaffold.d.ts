import { BoilerplateConfig as GenomicBoilerplateConfig } from 'genomic';
export type { BoilerplateSkill } from 'genomic';
export { SkillInstaller } from 'genomic';
export type { SkillInstallOptions, SkillInstallResult, SkillInstallFailure } from 'genomic';
import type { Inquirerer, Question } from 'inquirerer';
/**
 * Supported workspace types for template requirements.
 * - 'pgpm': Requires pgpm workspace (pgpm.json/pgpm.config.js) and creates pgpm.plan/.control files
 * - 'pnpm': Requires pnpm workspace (pnpm-workspace.yaml)
 * - 'lerna': Requires lerna workspace (lerna.json)
 * - 'npm': Requires npm workspace (package.json with workspaces field)
 * - false: No workspace required, can be scaffolded anywhere
 */
export type WorkspaceType = 'pgpm' | 'pnpm' | 'lerna' | 'npm' | false;
export interface BoilerplateConfig extends GenomicBoilerplateConfig {
    /**
     * Specifies what type of workspace this template requires.
     * - 'pgpm': Requires pgpm workspace AND creates pgpm.plan/.control files
     * - 'pnpm': Requires pnpm workspace (pnpm-workspace.yaml), no pgpm files
     * - 'lerna': Requires lerna workspace (lerna.json), no pgpm files
     * - 'npm': Requires npm workspace (package.json with workspaces), no pgpm files
     * - false: No workspace required, no pgpm files
     *
     * Defaults to 'pgpm' for 'module' type (backward compatibility), false for others.
     */
    requiresWorkspace?: WorkspaceType;
}
export interface InspectTemplateOptions {
    /**
     * The boilerplate path to inspect. When omitted, inspects the template
     * repository root and returns the templateDir for scanning available boilerplates.
     */
    fromPath?: string;
    templateRepo?: string;
    branch?: string;
    cacheTtlMs?: number;
    toolName?: string;
    cwd?: string;
    cacheBaseDir?: string;
    /**
     * Override the base directory for template resolution.
     * When provided, the effective path becomes `join(dir, fromPath)`.
     * When not provided, create-gen-app uses .boilerplates.json's dir as the default.
     */
    dir?: string;
}
export interface InspectTemplateResult {
    /** Path to the cached/cloned template directory (repository root) */
    templateDir: string;
    /** The resolved fromPath after .boilerplates.json resolution */
    resolvedFromPath?: string;
    /** Full path to the resolved template subdirectory */
    resolvedTemplatePath: string;
    /** Whether a cached template was used */
    cacheUsed: boolean;
    /** Whether the cache was expired and refreshed */
    cacheExpired: boolean;
    /** Configuration from .boilerplate.json (includes type, questions, etc.) */
    config: BoilerplateConfig | null;
}
export interface ScaffoldTemplateOptions {
    fromPath: string;
    outputDir: string;
    templateRepo?: string;
    branch?: string;
    answers: Record<string, any>;
    noTty?: boolean;
    cacheTtlMs?: number;
    toolName?: string;
    cwd?: string;
    cacheBaseDir?: string;
    /**
     * Override the base directory for template resolution.
     * When provided, the effective path becomes `join(dir, fromPath)`.
     * When not provided, create-gen-app uses .boilerplates.json's dir as the default.
     */
    dir?: string;
    /**
     * Optional Inquirerer instance to reuse for prompting.
     * If provided, the caller retains ownership and is responsible for closing it.
     * If not provided, a new instance will be created and closed automatically.
     */
    prompter?: Inquirerer;
}
export interface ScaffoldTemplateResult {
    cacheUsed: boolean;
    cacheExpired: boolean;
    cachePath?: string;
    templateDir: string;
    /** Questions loaded from .boilerplate.json, if any */
    questions?: Question[];
}
/**
 * Registry of known boilerplate template repos, keyed by flavor. Add new
 * backends (e.g. `turso`) here rather than sprinkling flavor-specific
 * constants across the codebase.
 */
export declare const TEMPLATE_REPOS: {
    readonly default: "https://github.com/constructive-io/pgpm-boilerplates.git";
    readonly pglite: "https://github.com/constructive-io/pglite-boilerplates.git";
};
export type TemplateRepoFlavor = keyof typeof TEMPLATE_REPOS;
export declare const DEFAULT_TEMPLATE_REPO: "https://github.com/constructive-io/pgpm-boilerplates.git";
export declare const DEFAULT_TEMPLATE_TTL_MS: number;
export declare const DEFAULT_TEMPLATE_TOOL_NAME = "pgpm";
export declare function inspectTemplate(options: InspectTemplateOptions): InspectTemplateResult;
export declare function scaffoldTemplate(options: ScaffoldTemplateOptions): Promise<ScaffoldTemplateResult>;
