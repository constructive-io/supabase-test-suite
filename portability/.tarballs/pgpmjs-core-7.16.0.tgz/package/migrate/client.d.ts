import { PgConfig } from 'pg-env';
import { DeployOptions, DeployResult, RevertOptions, RevertResult, StatusResult, VerifyOptions, VerifyResult } from './types';
export type HashMethod = 'content' | 'ast';
export interface PgpmMigrateOptions {
    /**
     * Hash method for SQL files:
     * - 'content': Hash the raw file content (fast, but sensitive to formatting changes)
     * - 'ast': Hash the parsed AST structure (robust, ignores formatting/comments but slower)
     */
    hashMethod?: HashMethod;
}
export declare class PgpmMigrate {
    private pool;
    private pgConfig;
    private hashMethod;
    private eventLogger;
    private initialized;
    private toUnqualifiedLocal;
    constructor(config: PgConfig, options?: PgpmMigrateOptions);
    /**
     * Calculate script hash using the configured method
     */
    private calculateScriptHash;
    /**
     * Initialize the migration schema
     */
    initialize(): Promise<void>;
    /**
     * Resolve toChange parameter, handling tag resolution if needed
     */
    private resolveToChange;
    /**
     * Deploy changes according to plan file
     */
    deploy(options: DeployOptions): Promise<DeployResult>;
    /**
     * Revert changes according to plan file
     */
    revert(options: RevertOptions): Promise<RevertResult>;
    /**
     * Verify deployed changes
     */
    verify(options: VerifyOptions): Promise<VerifyResult>;
    /**
     * Get deployment status
     */
    status(packageName?: string): Promise<StatusResult[]>;
    /**
     * Check if a change is deployed
     */
    isDeployed(packageName: string, changeName: string): Promise<boolean>;
    /**
     * Check if Sqitch tables exist in the database
     */
    hasSqitchTables(): Promise<boolean>;
    /**
     * Import from existing Sqitch deployment
     */
    importFromSqitch(): Promise<void>;
    /**
     * Get recent changes
     */
    getRecentChanges(targetDatabase: string, limit?: number): Promise<any[]>;
    /**
     * Get pending changes (in plan but not deployed)
     */
    getPendingChanges(planPath: string, targetDatabase: string): Promise<string[]>;
    /**
     * Get all deployed changes for a project
     */
    getDeployedChanges(targetDatabase: string, packageName: string): Promise<any[]>;
    /**
     * Get dependencies for a change
     */
    getDependencies(packageName: string, changeName: string): Promise<string[]>;
    /**
     * Close the database connection pool
     */
    close(): Promise<void>;
}
