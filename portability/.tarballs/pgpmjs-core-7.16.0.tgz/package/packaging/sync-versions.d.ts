export interface ModuleVersionStatus {
    /** Extension name from pgpm.plan */
    name: string;
    packageDir: string;
    /** Version from package.json (source of truth) */
    packageVersion: string;
    /** default_version from the .control file */
    controlVersion: string;
    /** Whether sql/<name>--<packageVersion>.sql exists */
    sqlFileExists: boolean;
    inSync: boolean;
}
export interface SyncVersionsOptions {
    /** Report skew without writing anything */
    check?: boolean;
    usePlan?: boolean;
}
export interface SyncVersionsResult {
    /** Modules that were regenerated (empty in check mode) */
    synced: ModuleVersionStatus[];
    /** Modules found out of sync (populated in check mode) */
    skewed: ModuleVersionStatus[];
    /** Modules already in sync */
    ok: ModuleVersionStatus[];
}
/**
 * Inspect a module directory and report whether its extension metadata
 * (.control default_version + sql bundle) matches the package.json version.
 */
export declare const getModuleVersionStatus: (packageDir: string) => ModuleVersionStatus;
/**
 * Bring a set of module directories back in sync with their package.json
 * versions by re-running the packaging flow (control file, Makefile, and
 * sql/<name>--<version>.sql regenerate from the package.json version).
 */
export declare const syncModuleVersions: (packageDirs: string[], { check, usePlan }?: SyncVersionsOptions) => Promise<SyncVersionsResult>;
