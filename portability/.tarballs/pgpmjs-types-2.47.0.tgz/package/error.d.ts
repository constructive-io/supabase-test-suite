export declare class PgpmError extends Error {
    code: string;
    context?: any;
    httpCode?: number;
    constructor(code: string, message: string, context?: any, httpCode?: number);
    toString(): string;
}
