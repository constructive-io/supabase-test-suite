"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * pgpm migration bundles: the portable, content-addressed artifact layer.
 *
 * A {@link MigrationBundle} is a deterministic snapshot of a pgpm module — plan,
 * control, ordered changes, and per-change/whole-bundle sha256 digests — with an
 * optional provenance manifest. It is the substrate for the `exportMigrationBundle`
 * / `applyMigrationBundle` / `transpileMigrationBundle` cloud functions: build one
 * from a module AST, transport or transform it, verify its digests, then
 * materialize it back into a deployable module.
 */
// Pure artifact layer moved to @pgpmjs/bundle; re-exported here so existing
// `@pgpmjs/core` consumers keep importing the whole bundle surface unchanged.
__exportStar(require("@pgpmjs/bundle"), exports);
// applyBundle stays in core: it drives PgpmMigrate (the deploy engine).
__exportStar(require("./apply"), exports);
// applyEnvelope: schema apply + data/fixtures part replay for a BundleEnvelope.
__exportStar(require("./apply-envelope"), exports);
// The stored `sql/<name>--<version>.bundle.tar.gz` artifact: emit + resolve.
__exportStar(require("./artifact"), exports);
// The bundle-backed deploy fast path (one-shot execute + ledger).
__exportStar(require("./deploy-bundled"), exports);
