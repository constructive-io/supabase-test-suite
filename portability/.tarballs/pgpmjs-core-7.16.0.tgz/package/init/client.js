"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PgpmInit = void 0;
const logger_1 = require("@pgpmjs/logger");
const pg_cache_1 = require("pg-cache");
const roles_1 = require("../roles");
const log = new logger_1.Logger('init');
class PgpmInit {
    pool;
    pgConfig;
    constructor(config) {
        this.pgConfig = config;
        this.pool = (0, pg_cache_1.getPgPool)(this.pgConfig);
    }
    /**
     * Bootstrap standard roles (anonymous, authenticated, administrator).
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param roles - Role mapping from getConnEnvOptions().roles!
     */
    async bootstrapRoles(roles) {
        try {
            log.info('Bootstrapping PGPM roles...');
            const sql = (0, roles_1.generateCreateBaseRolesSQL)(roles);
            await this.pool.query(sql);
            log.success('Successfully bootstrapped PGPM roles');
        }
        catch (error) {
            log.error('Failed to bootstrap roles:', error);
            throw error;
        }
    }
    /**
     * Bootstrap the restricted client role (authenticated_client) for SQL-level
     * proxy clients. Opt-in via `pgpm admin-users bootstrap --client`.
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param roles - Role mapping from getConnEnvOptions().roles!
     */
    async bootstrapClientRole(roles) {
        try {
            log.info('Bootstrapping PGPM client role...');
            const sql = (0, roles_1.generateCreateClientRoleSQL)(roles);
            await this.pool.query(sql);
            log.success('Successfully bootstrapped PGPM client role');
        }
        catch (error) {
            log.error('Failed to bootstrap client role:', error);
            throw error;
        }
    }
    /**
     * Bootstrap test roles (app_user, app_admin with grants to base roles).
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param roles - Role mapping from getConnEnvOptions().roles!
     * @param connections - Test user credentials from getConnEnvOptions().connections!
     */
    async bootstrapTestRoles(roles, connections) {
        try {
            log.warn('WARNING: This command creates test roles and should NEVER be run on a production database!');
            log.info('Bootstrapping PGPM test roles...');
            const sql = (0, roles_1.generateCreateTestUsersSQL)(roles, connections);
            await this.pool.query(sql);
            log.success('Successfully bootstrapped PGPM test roles');
        }
        catch (error) {
            log.error('Failed to bootstrap test roles:', error);
            throw error;
        }
    }
    /**
     * Bootstrap database roles with custom username and password.
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param username - The username to create
     * @param password - The password for the user
     * @param roles - Role mapping from getConnEnvOptions().roles!
     * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
     */
    async bootstrapDbRoles(username, password, roles, useLocksForRoles = false) {
        try {
            log.info(`Bootstrapping PGPM database roles for user: ${username}...`);
            const sql = (0, roles_1.generateCreateUserSQL)(username, password, roles, useLocksForRoles);
            await this.pool.query(sql);
            log.success(`Successfully bootstrapped PGPM database roles for user: ${username}`);
        }
        catch (error) {
            log.error(`Failed to bootstrap database roles for user ${username}:`, error);
            throw error;
        }
    }
    /**
     * Remove database roles and revoke grants.
     * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
     * @param username - The username to remove
     * @param roles - Role mapping from getConnEnvOptions().roles!
     * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
     */
    async removeDbRoles(username, roles, useLocksForRoles = false) {
        try {
            log.info(`Removing PGPM database roles for user: ${username}...`);
            const sql = (0, roles_1.generateRemoveUserSQL)(username, roles, useLocksForRoles);
            await this.pool.query(sql);
            log.success(`Successfully removed PGPM database roles for user: ${username}`);
        }
        catch (error) {
            log.error(`Failed to remove database roles for user ${username}:`, error);
            throw error;
        }
    }
    /**
     * Close the database connection
     */
    async close() {
    }
}
exports.PgpmInit = PgpmInit;
