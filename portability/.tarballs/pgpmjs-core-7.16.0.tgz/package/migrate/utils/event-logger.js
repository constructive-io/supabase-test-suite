"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventLogger = void 0;
const logger_1 = require("@pgpmjs/logger");
const pg_cache_1 = require("pg-cache");
const log = new logger_1.Logger('migrate:event-logger');
class EventLogger {
    pool;
    constructor(config) {
        this.pool = (0, pg_cache_1.getPgPool)(config);
    }
    async logEvent(entry) {
        try {
            await this.pool.query(`
        INSERT INTO pgpm_migrate.events 
        (event_type, change_name, package, error_message, error_code)
        VALUES ($1::TEXT, $2::TEXT, $3::TEXT, $4::TEXT, $5::TEXT)
      `, [
                entry.eventType,
                entry.changeName,
                entry.package,
                entry.errorMessage || null,
                entry.errorCode || null
            ]);
            log.debug(`Logged ${entry.eventType} event for ${entry.package}:${entry.changeName}`);
        }
        catch (error) {
            log.error(`Failed to log event: ${error.message}`);
        }
    }
}
exports.EventLogger = EventLogger;
