import { MigrationBundle } from '@pgpmjs/bundle';
import { ModuleMap } from '../modules/modules';
import { ResolvedApplySpec } from './types';
export interface MaterializeApplyOptions {
    /** Directory of the source module being applied. */
    sourceDir: string;
    /** The apply spec (typically read from the proxy via {@link readApplySpec}). */
    spec: ResolvedApplySpec;
    /** Directory to materialize into (default: a fresh temp dir). */
    outDir?: string;
}
export interface MaterializeApplyResult {
    /** The transpiled, content-addressed bundle that was materialized. */
    bundle: MigrationBundle;
    /** The deployable module directory the bundle was written to. */
    outDir: string;
}
/**
 * Transpile a source module per an apply spec and materialize the result as a
 * deployable module directory carrying the instance's identity.
 *
 * Pure pipeline over existing primitives: `bundleFromModule` →
 * `transpileBundle(makeSchemaTranspiler)` → `verifyBundle` →
 * `materializeBundle`. Deterministic — identical source + spec always produce
 * an identical bundle (and digest), which is what makes verify/revert able to
 * re-derive the exact deployed artifact.
 */
export declare function materializeApplyModule(options: MaterializeApplyOptions): Promise<MaterializeApplyResult>;
/**
 * Deploy-path dispatch seam: given a resolved module's directory, return the
 * directory the migration engine should actually run against.
 *
 * Non-proxy modules pass through unchanged. For proxy modules (directories
 * carrying a `pgpm.apply.json`), the source module is located in the workspace
 * module map, transpiled per the spec, and materialized to a cached temp dir
 * carrying the instance's identity.
 */
export declare function resolveEffectiveModulePath(moduleName: string, modulePath: string, moduleMap: ModuleMap, workspacePath: string): Promise<string>;
/** Test seam: clear the per-process materialization cache. */
export declare function clearApplyMaterializationCache(): void;
