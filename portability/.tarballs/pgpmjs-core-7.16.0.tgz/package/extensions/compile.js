"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.compileExtensionInstall = compileExtensionInstall;
exports.compileExtensionInstalls = compileExtensionInstalls;
const SPECIAL_ROLES = new Set(['public', 'current_user', 'session_user']);
const quoteIdent = (name) => `"${name.replace(/"/g, '""')}"`;
const routeRole = (role, roleMap) => {
    if (!roleMap)
        return role;
    if (SPECIAL_ROLES.has(role.toLowerCase()))
        return role;
    return roleMap[role] ?? role;
};
const grantObjectClause = (on, schema) => {
    const s = quoteIdent(schema);
    switch (on) {
        case 'schema':
            return `SCHEMA ${s}`;
        case 'all-tables':
            return `ALL TABLES IN SCHEMA ${s}`;
        case 'all-sequences':
            return `ALL SEQUENCES IN SCHEMA ${s}`;
        case 'all-functions':
            return `ALL FUNCTIONS IN SCHEMA ${s}`;
    }
};
const grantSql = (verb, grant, schema, roleMap) => {
    const roles = (Array.isArray(grant.to) ? grant.to : [grant.to])
        .map((r) => routeRole(r, roleMap))
        .join(', ');
    const obj = grantObjectClause(grant.on, schema);
    return verb === 'GRANT'
        ? `GRANT ${grant.privileges} ON ${obj} TO ${roles};`
        : `REVOKE ${grant.privileges} ON ${obj} FROM ${roles};`;
};
/**
 * Compile a single `provides` declaration into deploy / revert / verify SQL.
 *
 * Pure and deterministic: given the same input it returns byte-identical SQL,
 * with no dynamic `EXECUTE`. This is the nuts-and-bolts primitive; wiring it
 * into the deploy path (and eventually into real plan changes exempt from
 * `filterStatements` stripping) composes on top of it.
 */
function compileExtensionInstall(extname, provide, options = {}) {
    const { roleMap, fixedSchema } = options;
    const schema = provide.schema === undefined ? null : provide.schema;
    const relocatable = provide.relocatable ?? true;
    const ifNotExists = provide.ifNotExists ?? true;
    const cascade = provide.cascade ?? false;
    const createSchema = provide.createSchema ?? schema !== null;
    const dropSchema = provide.dropSchema ?? false;
    const grants = provide.grants ?? [];
    // A fixed-schema extension can only be placed at its own fixed schema.
    if (!relocatable && schema !== null && fixedSchema != null && schema !== fixedSchema) {
        throw new Error(`Extension "${extname}" is non-relocatable (fixed schema "${fixedSchema}") and cannot be installed into "${schema}".`);
    }
    if (grants.length > 0 && schema === null) {
        throw new Error(`Extension "${extname}" declares grants but no schema; schema-qualified grants require an install schema.`);
    }
    const ext = quoteIdent(extname);
    const deploy = [];
    const revert = [];
    const verify = [];
    if (schema !== null && createSchema) {
        deploy.push(`CREATE SCHEMA IF NOT EXISTS ${quoteIdent(schema)};`);
    }
    const createParts = ['CREATE EXTENSION'];
    if (ifNotExists)
        createParts.push('IF NOT EXISTS');
    createParts.push(ext);
    if (schema !== null)
        createParts.push(`WITH SCHEMA ${quoteIdent(schema)}`);
    if (cascade)
        createParts.push('CASCADE');
    deploy.push(`${createParts.join(' ')};`);
    for (const g of grants) {
        deploy.push(grantSql('GRANT', g, schema, roleMap));
    }
    // Revert: drop grants (best-effort), then extension, then optionally schema.
    for (const g of [...grants].reverse()) {
        revert.push(grantSql('REVOKE', g, schema, roleMap));
    }
    revert.push(`DROP EXTENSION IF EXISTS ${ext};`);
    if (schema !== null && createSchema && dropSchema) {
        revert.push(`DROP SCHEMA IF EXISTS ${quoteIdent(schema)};`);
    }
    // Verify: assert the extension exists in the expected namespace.
    if (schema !== null) {
        verify.push([
            'SELECT 1 / count(*)::int AS ok',
            'FROM pg_catalog.pg_extension e',
            'JOIN pg_catalog.pg_namespace n ON n.oid = e.extnamespace',
            `WHERE e.extname = ${quoteLiteral(extname)} AND n.nspname = ${quoteLiteral(schema)};`
        ].join('\n'));
    }
    else {
        verify.push([
            'SELECT 1 / count(*)::int AS ok',
            'FROM pg_catalog.pg_extension e',
            `WHERE e.extname = ${quoteLiteral(extname)};`
        ].join('\n'));
    }
    return { deploy, revert, verify };
}
const quoteLiteral = (s) => `'${s.replace(/'/g, "''")}'`;
/** Compile every `provides` entry in a manifest, keyed by extension name. */
function compileExtensionInstalls(provides, options = {}) {
    const out = {};
    for (const [extname, provide] of Object.entries(provides)) {
        out[extname] = compileExtensionInstall(extname, provide, options);
    }
    return out;
}
