"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.diffBundles = diffBundles;
const traverse_1 = require("@pgpmjs/traverse");
function scriptDiff(from, to) {
    if (!from && !to)
        return 'unchanged';
    if (!from)
        return 'added';
    if (!to)
        return 'removed';
    return from.digest === to.digest ? 'unchanged' : 'modified';
}
function changeScriptDiffs(from, to) {
    const diffs = {};
    (0, traverse_1.zipScripts)(from, to, (kind, a, b) => {
        diffs[kind] = scriptDiff(a, b);
    });
    return diffs;
}
/**
 * Diff two migration bundles by content digest.
 *
 * Pure and deterministic. `added`/`removed`/`modified` are keyed on change name;
 * a change in both bundles is `modified` when its change digest differs, with
 * per-script detail. `reordered` flags a pure deploy-order change over an
 * otherwise identical change set.
 */
function diffBundles(from, to) {
    const fromByName = new Map(from.changes.map(c => [c.name, c]));
    const toByName = new Map(to.changes.map(c => [c.name, c]));
    const added = [];
    const removed = [];
    const modified = [];
    const changes = [];
    for (const change of to.changes) {
        const prior = fromByName.get(change.name);
        if (!prior) {
            added.push(change.name);
            changes.push({ name: change.name, kind: 'added' });
        }
        else if (prior.digest !== change.digest) {
            const diff = {
                name: change.name,
                kind: 'modified',
                scripts: changeScriptDiffs(prior, change)
            };
            modified.push(diff);
            changes.push(diff);
        }
    }
    for (const change of from.changes) {
        if (!toByName.has(change.name)) {
            removed.push(change.name);
            changes.push({ name: change.name, kind: 'removed' });
        }
    }
    const sameSet = added.length === 0 &&
        removed.length === 0 &&
        from.changes.length === to.changes.length;
    const reordered = sameSet && from.manifest.deployOrder.join('\n') !== to.manifest.deployOrder.join('\n');
    return {
        identical: from.manifest.digest === to.manifest.digest,
        added,
        removed,
        modified,
        reordered,
        changes
    };
}
