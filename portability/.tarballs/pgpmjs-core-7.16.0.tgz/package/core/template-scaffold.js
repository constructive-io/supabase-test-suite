"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_TEMPLATE_TOOL_NAME = exports.DEFAULT_TEMPLATE_TTL_MS = exports.DEFAULT_TEMPLATE_REPO = exports.TEMPLATE_REPOS = exports.SkillInstaller = void 0;
exports.inspectTemplate = inspectTemplate;
exports.scaffoldTemplate = scaffoldTemplate;
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
const genomic_1 = require("genomic");
var genomic_2 = require("genomic");
Object.defineProperty(exports, "SkillInstaller", { enumerable: true, get: function () { return genomic_2.SkillInstaller; } });
/**
 * Registry of known boilerplate template repos, keyed by flavor. Add new
 * backends (e.g. `turso`) here rather than sprinkling flavor-specific
 * constants across the codebase.
 */
exports.TEMPLATE_REPOS = {
    default: 'https://github.com/constructive-io/pgpm-boilerplates.git',
    pglite: 'https://github.com/constructive-io/pglite-boilerplates.git'
};
exports.DEFAULT_TEMPLATE_REPO = exports.TEMPLATE_REPOS.default;
exports.DEFAULT_TEMPLATE_TTL_MS = 1 * 24 * 60 * 60 * 1000; // 1 day
exports.DEFAULT_TEMPLATE_TOOL_NAME = 'pgpm';
function resolveCacheBaseDir(cacheBaseDir) {
    if (cacheBaseDir) {
        return cacheBaseDir;
    }
    if (process.env.PGPM_CACHE_BASE_DIR) {
        return process.env.PGPM_CACHE_BASE_DIR;
    }
    if (process.env.JEST_WORKER_ID) {
        return path_1.default.join(os_1.default.tmpdir(), `pgpm-cache-${process.env.JEST_WORKER_ID}`);
    }
    return undefined;
}
function inspectTemplate(options) {
    const { fromPath, templateRepo = exports.DEFAULT_TEMPLATE_REPO, branch, cacheTtlMs = exports.DEFAULT_TEMPLATE_TTL_MS, toolName = exports.DEFAULT_TEMPLATE_TOOL_NAME, cwd, cacheBaseDir, dir, } = options;
    const scaffolder = new genomic_1.TemplateScaffolder({
        toolName,
        ttlMs: cacheTtlMs,
        cacheBaseDir: resolveCacheBaseDir(cacheBaseDir),
    });
    // Compute effective fromPath:
    // - If dir is provided, join it with fromPath and bypass .boilerplates.json
    // - If dir is NOT provided, let create-gen-app use .boilerplates.json
    const effectiveFromPath = dir
        ? fromPath
            ? path_1.default.join(dir, fromPath)
            : dir
        : fromPath;
    const template = templateRepo.startsWith('.') ||
        templateRepo.startsWith('/') ||
        templateRepo.startsWith('~')
        ? path_1.default.resolve(cwd ?? process.cwd(), templateRepo)
        : templateRepo;
    const result = scaffolder.inspect({
        template,
        branch,
        fromPath: effectiveFromPath,
        // When dir is specified, bypass .boilerplates.json resolution entirely
        useBoilerplatesConfig: !dir,
    });
    return {
        templateDir: result.templateDir,
        resolvedFromPath: result.resolvedFromPath,
        resolvedTemplatePath: result.resolvedTemplatePath,
        cacheUsed: result.cacheUsed,
        cacheExpired: result.cacheExpired,
        config: result.config,
    };
}
async function scaffoldTemplate(options) {
    const { fromPath, outputDir, templateRepo = exports.DEFAULT_TEMPLATE_REPO, branch, answers, noTty = false, cacheTtlMs = exports.DEFAULT_TEMPLATE_TTL_MS, toolName = exports.DEFAULT_TEMPLATE_TOOL_NAME, cwd, cacheBaseDir, dir, prompter, } = options;
    const scaffolder = new genomic_1.TemplateScaffolder({
        toolName,
        ttlMs: cacheTtlMs,
        cacheBaseDir: resolveCacheBaseDir(cacheBaseDir),
    });
    // If dir is provided, join it with fromPath and bypass .boilerplates.json
    // Otherwise, let create-gen-app resolve via .boilerplates.json
    const effectiveFromPath = dir ? path_1.default.join(dir, fromPath) : fromPath;
    const template = templateRepo.startsWith('.') ||
        templateRepo.startsWith('/') ||
        templateRepo.startsWith('~')
        ? path_1.default.resolve(cwd ?? process.cwd(), templateRepo)
        : templateRepo;
    const result = await scaffolder.scaffold({
        template,
        outputDir,
        branch,
        fromPath: effectiveFromPath,
        answers,
        noTty,
        // In noTty mode, never reuse a caller prompter: it may have been created
        // in interactive mode (or already closed), which would route template
        // questions through the TTY prompt path. Letting the templatizer build
        // its own prompter guarantees the noTty flag cascades.
        prompter: noTty ? undefined : prompter,
        // When dir is specified, bypass .boilerplates.json resolution entirely
        useBoilerplatesConfig: !dir,
    });
    return {
        cacheUsed: result.cacheUsed,
        cacheExpired: result.cacheExpired,
        cachePath: result.templateDir,
        templateDir: result.templateDir,
        questions: result.questions,
    };
}
