import { RoleMapping, TestUserCredentials } from '@pgpmjs/types';
/**
 * Generate SQL to create base roles (anonymous, authenticated, administrator).
 * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
 * @param roles - Role mapping from getConnEnvOptions().roles!
 * @throws Error if roles is undefined or missing required properties
 */
export declare function generateCreateBaseRolesSQL(roles: RoleMapping): string;
/**
 * Generate SQL to create the restricted `authenticated_client` role used by
 * SQL-level proxy clients (opt-in via `admin-users bootstrap --client`).
 *
 * The role inherits table/schema grants from `authenticated` and gets a
 * server-enforced statement_timeout baseline. Grant-level hardening such as
 * revoking set_config()/pg_notify() from PUBLIC is intentionally left to the
 * proxy deployment config, since those revokes affect every non-superuser
 * role in the database (the app server and job workers depend on both).
 *
 * @param roles - Role mapping from getConnEnvOptions().roles!
 * @param statementTimeout - Baseline statement_timeout for the role (default '15s')
 */
export declare function generateCreateClientRoleSQL(roles: RoleMapping, statementTimeout?: string): string;
/**
 * Generate SQL to create a user with password and grant base roles.
 * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
 * @param roles - Role mapping from getConnEnvOptions().roles!
 * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
 */
export declare function generateCreateUserSQL(username: string, password: string, roles: RoleMapping, useLocksForRoles?: boolean): string;
/**
 * Generate SQL to create test users with grants to base roles.
 * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
 * @param roles - Role mapping from getConnEnvOptions().roles!
 * @param connections - Test user credentials from getConnEnvOptions().connections!
 */
export declare function generateCreateTestUsersSQL(roles: RoleMapping, connections: TestUserCredentials): string;
/**
 * Generate SQL to grant a role to a user
 */
export declare function generateGrantRoleSQL(role: string, user: string): string;
/**
 * Generate SQL to remove a user and revoke grants.
 * Callers should use getConnEnvOptions() from @pgpmjs/env to get merged values.
 * @param roles - Role mapping from getConnEnvOptions().roles!
 * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
 */
export declare function generateRemoveUserSQL(username: string, roles: RoleMapping, useLocksForRoles?: boolean): string;
/**
 * Generate SQL to create a user with grants to specified roles (for test harness)
 * @param useLocksForRoles - Whether to use advisory locks (from getConnEnvOptions().useLocksForRoles)
 */
export declare function generateCreateUserWithGrantsSQL(username: string, password: string, rolesToGrant: string[], useLocksForRoles?: boolean): string;
