"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transpileBundle = transpileBundle;
const header_1 = require("@pgpmjs/ast/files/sql/header");
const ast_1 = require("@pgpmjs/ast");
const ast_2 = require("@pgpmjs/ast");
const traverse_1 = require("@pgpmjs/traverse");
const create_1 = require("./create");
/**
 * Drop excluded changes from a plan's text and prune references to them from
 * the surviving changes' dependency brackets, re-serializing the plan. Tags on
 * excluded changes are dropped with them.
 */
function removeChangesFromPlan(plan, excluded) {
    const parsed = (0, ast_2.parsePlanContent)(plan);
    if (!parsed.data)
        return plan;
    const changes = parsed.data.changes
        .filter(change => !excluded.has(change.name))
        .map(change => ({
        ...change,
        dependencies: change.dependencies.filter(dep => !excluded.has(dep))
    }));
    const tags = (parsed.data.tags ?? []).filter(tag => !excluded.has(tag.change));
    return (0, ast_2.generatePlanFileContent)({ ...parsed.data, changes, tags });
}
function renameProjectInPlan(plan, from, to) {
    return plan
        .split('\n')
        .map(line => {
        const trimmed = line.trim();
        if (trimmed === `%project=${from}`)
            return line.replace(`%project=${from}`, `%project=${to}`);
        if (trimmed === `%uri=${from}`)
            return line.replace(`%uri=${from}`, `%uri=${to}`);
        return line;
    })
        .join('\n');
}
/**
 * Build the source→target change rename map, validating that the rename is a
 * well-formed bijection over the changes it touches (no two changes collapse to
 * the same name, no rename onto an untouched existing change).
 */
function buildRenames(order, renameChange) {
    const renames = new Map();
    const targets = new Map();
    const originals = new Set(order);
    for (const name of order) {
        const to = renameChange(name);
        if (to === name)
            continue;
        const prior = targets.get(to);
        if (prior !== undefined) {
            throw new Error(`Transpile renames both "${prior}" and "${name}" to "${to}"`);
        }
        if (originals.has(to) && renameChange(to) === to) {
            throw new Error(`Transpile renames "${name}" onto existing change "${to}"`);
        }
        targets.set(to, name);
        renames.set(name, to);
    }
    return renames;
}
function transpileScriptSql(script, changeName, renames, options) {
    let sql = script.sql;
    if (renames.size > 0) {
        const parsed = (0, header_1.parsePgpmHeader)(sql);
        if ((0, header_1.renameInHeader)(parsed, renames) > 0) {
            sql = (0, header_1.writePgpmScript)(parsed);
        }
    }
    if (options.transformScript) {
        sql = options.transformScript(sql, { change: changeName, kind: script.kind });
    }
    return { kind: script.kind, sql, digest: (0, ast_1.hashString)(sql) };
}
/**
 * Transpile a {@link MigrationBundle} into a new namespace, producing a fresh
 * content-addressed bundle.
 *
 * Pure and deterministic (no I/O). Composes the existing rename primitives
 * (`renameInHeader`, `renameInPlanContent`) for the mechanical change-name/plan
 * rewrite and defers SQL-body rewriting to the caller-supplied
 * {@link TranspileBundleOptions.transformScript}. Digests are recomputed from
 * the transformed SQL so the result is independently verifiable, and the source
 * bundle's digest is recorded in `provenance.sourceBundleDigest` for lineage.
 */
function transpileBundle(bundle, options = {}) {
    const renameChange = options.renameChange ?? ((name) => name);
    const excludeChange = options.excludeChange ?? (() => false);
    const renames = buildRenames(bundle.manifest.deployOrder, renameChange);
    const changes = bundle.changes
        .filter(change => !excludeChange(change.name))
        .map(change => {
        const name = renames.get(change.name) ?? change.name;
        const dependencies = change.dependencies
            .filter(dep => !excludeChange(dep))
            .map(dep => renames.get(dep) ?? dep);
        const { deploy, revert, verify } = (0, traverse_1.mapScripts)(change, script => transpileScriptSql(script, change.name, renames, options));
        const digest = (0, create_1.computeChangeDigest)(name, {
            deploy: deploy?.digest,
            revert: revert?.digest,
            verify: verify?.digest
        });
        return { name, dependencies, deploy, revert, verify, digest };
    });
    let plan = renames.size > 0 ? (0, ast_2.renameInPlanContent)(bundle.plan, renames) : bundle.plan;
    // Excluded changes are matched by source name; they are never renamed (the
    // caller leaves excluded changes' identity intact), so prune the plan by the
    // source names, after any survivor renames have been applied above.
    const excluded = new Set(bundle.manifest.deployOrder.filter(excludeChange));
    if (excluded.size > 0) {
        plan = removeChangesFromPlan(plan, excluded);
    }
    const moduleName = options.renameModule ?? bundle.manifest.name;
    if (options.renameModule && options.renameModule !== bundle.manifest.name) {
        plan = renameProjectInPlan(plan, bundle.manifest.name, options.renameModule);
    }
    let control = bundle.control;
    if (control && options.transformControl) {
        control = {
            fileName: control.fileName,
            content: options.transformControl(control.content, control.fileName)
        };
    }
    if (control && options.renameModule && options.renameModule !== bundle.manifest.name) {
        control = {
            fileName: `${options.renameModule}.control`,
            content: control.content
        };
    }
    const deployOrder = changes.map(c => c.name);
    const digest = (0, create_1.computeBundleDigest)(plan, control?.content ?? null, changes.map(c => c.digest));
    const provenance = {
        ...(bundle.manifest.provenance ?? {}),
        ...(options.provenance ?? {}),
        sourceBundleDigest: bundle.manifest.digest
    };
    return {
        manifest: {
            formatVersion: bundle.manifest.formatVersion,
            name: moduleName,
            createdWith: options.createdWith ?? '@pgpmjs/core',
            changeCount: changes.length,
            deployOrder,
            digest,
            provenance
        },
        plan,
        control,
        changes
    };
}
