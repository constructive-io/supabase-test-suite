export interface MigrateChange {
    name: string;
    dependencies: string[];
    timestamp?: string;
    planner?: string;
    email?: string;
    comment?: string;
}
export interface MigratePlanFile {
    package: string;
    uri?: string;
    changes: MigrateChange[];
}
export interface DeployOptions {
    modulePath: string;
    /**
     * Target change name or tag (e.g., "changeName" or "@tagName").
     * Note: Project name is already resolved upstream by PgpmPackage.
     */
    toChange?: string;
    useTransaction?: boolean;
    debug?: boolean;
    logOnly?: boolean;
    /**
     * When true, construct dependency resolution purely from plan files
     * rather than scanning deploy/*.sql files.
     */
    usePlan?: boolean;
}
export interface RevertOptions {
    modulePath: string;
    /**
     * Target change name or tag (e.g., "changeName" or "@tagName").
     * Note: Project name is already resolved upstream by PgpmPackage.
     */
    toChange?: string;
    useTransaction?: boolean;
    debug?: boolean;
}
export interface VerifyOptions {
    modulePath: string;
    /**
     * Target change name or tag (e.g., "changeName" or "@tagName").
     * Note: Project name is already resolved upstream by PgpmPackage.
     */
    toChange?: string;
}
export interface DeployResult {
    deployed: string[];
    skipped: string[];
    failed?: string;
}
export interface RevertResult {
    reverted: string[];
    skipped: string[];
    failed?: string;
}
export interface VerifyResult {
    verified: string[];
    failed: string[];
}
export interface StatusResult {
    package: string;
    totalDeployed: number;
    lastChange: string;
    lastDeployed: Date;
}
