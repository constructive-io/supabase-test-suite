"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyProject = void 0;
const logger_1 = require("@pgpmjs/logger");
const types_1 = require("@pgpmjs/types");
const path_1 = require("path");
const path = __importStar(require("path"));
const pg_cache_1 = require("pg-cache");
const materialize_1 = require("../apply/materialize");
const apply_spec_1 = require("../apply/apply-spec");
const pgpm_1 = require("../core/class/pgpm");
const client_1 = require("../migrate/client");
const deps_1 = require("../resolution/deps");
const log = new logger_1.Logger('verify');
const verifyProject = async (opts, name, database, pkg, options) => {
    log.info(`🔍 Gathering modules from ${pkg.workspacePath}...`);
    const modules = pkg.getModuleMap();
    if (!modules[name]) {
        log.error(`❌ Module "${name}" not found in modules list.`);
        throw types_1.errors.MODULE_NOT_FOUND({ name });
    }
    const modulePath = path.resolve(pkg.workspacePath, modules[name].path);
    log.info(`📦 Resolving dependencies for ${name}...`);
    // Proxy (apply-spec) modules have no pgpm.plan, so resolve straight off the
    // workspace module map instead of instantiating a module-rooted package.
    const extensions = (0, apply_spec_1.hasApplySpec)(modulePath)
        ? (0, deps_1.resolveExtensionDependencies)(name, modules)
        : new pgpm_1.PgpmPackage(modulePath, { extensionsDir: pkg.extensionsDir }).getModuleExtensions();
    const pgPool = (0, pg_cache_1.getPgPool)({
        ...opts.pg,
        database
    });
    log.success(`🔎 Verifying deployment of ${name} on database ${database}...`);
    for (const extension of extensions.resolved) {
        try {
            if (extensions.external.includes(extension)) {
                const query = `SELECT 1/count(*) FROM pg_available_extensions WHERE name = $1`;
                log.info(`🔍 Verifying external extension: ${extension}`);
                log.debug(`> ${query}`);
                await pgPool.query(query, [extension]);
            }
            else {
                const sourcePath = (0, path_1.resolve)(pkg.workspacePath, modules[extension].path);
                const modulePath = await (0, materialize_1.resolveEffectiveModulePath)(extension, sourcePath, modules, pkg.workspacePath);
                log.info(`📂 Verifying local module: ${extension}`);
                log.debug(`→ Path: ${modulePath}`);
                log.debug(`→ Command: constructive migrate verify db:pg:${database}`);
                try {
                    const client = new client_1.PgpmMigrate(opts.pg);
                    const result = await client.verify({
                        modulePath
                    });
                    if (result.failed.length > 0) {
                        throw types_1.errors.OPERATION_FAILED({ operation: 'Verification', reason: `${result.failed.length} changes: ${result.failed.join(', ')}` });
                    }
                }
                catch (verifyError) {
                    log.error(`❌ Verification failed for module ${extension}`);
                    throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Verify', module: extension });
                }
            }
        }
        catch (e) {
            log.error(`🛑 Error during verification: ${e instanceof Error ? e.message : e}`);
            console.error(e);
            throw types_1.errors.DEPLOYMENT_FAILED({ type: 'Verify', module: extension });
        }
    }
    log.success(`✅ Verification complete for ${name}.`);
    return extensions;
};
exports.verifyProject = verifyProject;
