"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.computeChangeDigest = computeChangeDigest;
exports.computeBundleDigest = computeBundleDigest;
exports.createBundle = createBundle;
exports.withExecutableSql = withExecutableSql;
const ast_1 = require("@pgpmjs/ast");
const traverse_1 = require("@pgpmjs/traverse");
const types_1 = require("./types");
/**
 * Digest for a single change: its name plus the digests of its scripts, in a
 * fixed deploy/revert/verify order. A missing script contributes an empty slot
 * so presence/absence changes the digest.
 */
function computeChangeDigest(name, scripts) {
    const parts = [name, scripts.deploy ?? '', scripts.revert ?? '', scripts.verify ?? ''];
    if (scripts.exec != null)
        parts.push(scripts.exec);
    return (0, ast_1.hashString)(parts.join('\n'));
}
/**
 * Top-level bundle digest: the plan, the control content, and the ordered change
 * digests. Deterministic and independent of tool version / provenance.
 */
function computeBundleDigest(plan, controlContent, changeDigests) {
    return (0, ast_1.hashString)([plan, controlContent ?? '', ...changeDigests].join('\n'));
}
function toBundleScript(script) {
    if (!script)
        return null;
    return { kind: script.kind, sql: script.raw, digest: (0, ast_1.hashString)(script.raw) };
}
/**
 * Build a content-addressed {@link MigrationBundle} from a module AST.
 *
 * Pure and deterministic: no disk I/O, no clock, no version noise in the digest.
 * The change order follows the module's plan order, which the AST already
 * preserves, so the bundle's `deployOrder` is dependency-safe by construction.
 */
function createBundle(module, options = {}) {
    const changes = module.changes.map(change => {
        const { deploy, revert, verify } = (0, traverse_1.mapScripts)(change, toBundleScript);
        const digest = computeChangeDigest(change.name, {
            deploy: deploy?.digest,
            revert: revert?.digest,
            verify: verify?.digest
        });
        return {
            name: change.name,
            dependencies: change.plan.dependencies ?? [],
            deploy,
            revert,
            verify,
            digest
        };
    });
    const controlContent = module.control?.raw ?? null;
    const deployOrder = changes.map(c => c.name);
    const digest = computeBundleDigest(module.planRaw, controlContent, changes.map(c => c.digest));
    return {
        manifest: {
            formatVersion: types_1.BUNDLE_FORMAT_VERSION,
            name: module.name,
            createdWith: options.createdWith ?? '@pgpmjs/core',
            changeCount: changes.length,
            deployOrder,
            digest,
            ...(options.provenance ? { provenance: options.provenance } : {})
        },
        plan: module.planRaw,
        control: module.control
            ? { fileName: module.control.fileName, content: module.control.raw }
            : null,
        changes
    };
}
/**
 * Attach pre-computed executable deploy SQL to a bundle, re-deriving the
 * per-change and top-level digests so the artifact stays content-addressed.
 *
 * The `exec` SQL is the deploy script with transaction / `CREATE EXTENSION`
 * statements stripped — the form the deploy engine actually executes. Computing
 * it requires a SQL parser, which this layer deliberately does not depend on, so
 * the caller (`@pgpmjs/core` at package time) supplies it.
 *
 * Changes with no entry in `execSql` are left untouched.
 */
function withExecutableSql(bundle, execSql) {
    const changes = bundle.changes.map(change => {
        const sql = execSql[change.name];
        if (sql === undefined)
            return change;
        const exec = { sql, digest: (0, ast_1.hashString)(sql) };
        return {
            ...change,
            exec,
            digest: computeChangeDigest(change.name, {
                deploy: change.deploy?.digest,
                revert: change.revert?.digest,
                verify: change.verify?.digest,
                exec: exec.digest
            })
        };
    });
    return {
        ...bundle,
        manifest: {
            ...bundle.manifest,
            digest: computeBundleDigest(bundle.plan, bundle.control?.content ?? null, changes.map(c => c.digest))
        },
        changes
    };
}
