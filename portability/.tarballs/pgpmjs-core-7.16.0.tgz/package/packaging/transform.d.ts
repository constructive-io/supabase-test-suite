type TransformProps = {
    [key: string]: ((value: any) => any) | {
        [key: string]: any;
    };
};
/**
 * Recursively transforms the properties of an object based on a transformation map.
 *
 * @param obj - The object to transform.
 * @param props - A map of properties and their transformation rules.
 * @returns A new object with transformed properties.
 */
export declare const transformProps: (obj: any, props: TransformProps) => any;
/**
 * Parses a SQL statement, transforms its properties, and regenerates the SQL.
 *
 * @param statement - The SQL statement to transform.
 * @param props - A map of properties and their transformation rules.
 * @returns The transformed SQL statement.
 */
export declare const transform: (statement: string, props: TransformProps) => Promise<string>;
export {};
