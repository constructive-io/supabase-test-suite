"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @pgpmjs/bundle: the portable, content-addressed migration artifact layer.
 *
 * A {@link MigrationBundle} is a deterministic snapshot of a pgpm module — plan,
 * control, ordered changes, and per-change/whole-bundle sha256 digests — with an
 * optional provenance manifest. It is the substrate for the `exportMigrationBundle`
 * / `applyMigrationBundle` / `transpileMigrationBundle` cloud functions: build one
 * from a module AST, transport or transform it, verify its digests, then
 * materialize it back into a deployable module.
 *
 * Pure layer (no database, no deploy engine). The deployment glue — `applyBundle`,
 * which drives `PgpmMigrate` — lives in `@pgpmjs/core`.
 */
__exportStar(require("./create"), exports);
__exportStar(require("./diff"), exports);
__exportStar(require("./envelope"), exports);
__exportStar(require("./io"), exports);
__exportStar(require("./reconcile"), exports);
__exportStar(require("./split"), exports);
__exportStar(require("./tar"), exports);
__exportStar(require("./transpile"), exports);
__exportStar(require("./types"), exports);
__exportStar(require("./verify"), exports);
