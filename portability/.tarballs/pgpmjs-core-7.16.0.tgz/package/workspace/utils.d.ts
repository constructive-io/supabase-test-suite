/**
 * Recursively walks up directories to find a specific file (sync version).
 * @param startDir - Starting directory.
 * @param filename - The target file to search for.
 * @returns The directory path containing the file.
 */
export declare const walkUp: (startDir: string, filename: string) => string;
export declare const sluggify: (text: string) => string;
