"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getExtensionsAndModulesChanges = exports.getExtensionsAndModules = exports.latestChangeAndVersion = exports.latestChange = exports.getMissingInstallableModules = exports.PGPM_MODULE_MAP = void 0;
const files_1 = require("@pgpmjs/ast/files");
const types_1 = require("@pgpmjs/types");
/**
 * Mapping from control file names (used in extensions list) to npm package names.
 * Only includes modules that can be installed via pgpm install from @pgpm/* packages.
 * Native PostgreSQL extensions (plpgsql, uuid-ossp, etc.) are not included.
 */
exports.PGPM_MODULE_MAP = {
    'pgpm-app-scope': '@pgpm/app-scope',
    'pgpm-base32': '@pgpm/base32',
    'pgpm-database-jobs': '@pgpm/database-jobs',
    'pgpm-function-resolution': '@pgpm/function-resolution',
    'metaschema-modules': '@pgpm/metaschema-modules',
    'metaschema-schema': '@pgpm/metaschema-schema',
    'pgpm-inflection': '@pgpm/inflection',
    'pgpm-jwt-claims': '@pgpm/jwt-claims',
    'pgpm-stamps': '@pgpm/stamps',
    'pgpm-totp': '@pgpm/totp',
    'pgpm-types': '@pgpm/types',
    'pgpm-utils': '@pgpm/utils',
    'pgpm-ltree-helpers': '@pgpm/ltree-helpers',
    'pgpm-partman': '@pgpm/partman'
};
/**
 * Determines which pgpm modules from an extensions list are missing from the installed modules.
 * Only checks modules that are in PGPM_MODULE_MAP (installable via pgpm install).
 *
 * @param extensions - List of extension/control file names to check
 * @param installedModules - List of installed npm package names (e.g., '@pgpm/base32')
 * @returns Array of missing modules with their control names and npm package names
 */
const getMissingInstallableModules = (extensions, installedModules) => {
    const missingModules = [];
    for (const ext of extensions) {
        const npmName = exports.PGPM_MODULE_MAP[ext];
        if (npmName && !installedModules.includes(npmName)) {
            missingModules.push({
                controlName: ext,
                npmName
            });
        }
    }
    return missingModules;
};
exports.getMissingInstallableModules = getMissingInstallableModules;
/**
 * Get the latest change from the pgpm.plan file for a specific module.
 */
const latestChange = (sqlmodule, modules, basePath) => {
    const module = modules[sqlmodule];
    if (!module) {
        throw types_1.errors.MODULE_NOT_FOUND({ name: sqlmodule });
    }
    const planPath = `${basePath}/${module.path}/pgpm.plan`;
    return (0, files_1.getLatestChange)(planPath);
};
exports.latestChange = latestChange;
/**
 * Get the latest change and version for a specific module.
 */
const latestChangeAndVersion = (sqlmodule, modules, basePath) => {
    const module = modules[sqlmodule];
    if (!module) {
        throw types_1.errors.MODULE_NOT_FOUND({ name: sqlmodule });
    }
    const planPath = `${basePath}/${module.path}/pgpm.plan`;
    const change = (0, files_1.getLatestChange)(planPath);
    const pkg = require(`${basePath}/${module.path}/package.json`);
    return { change, version: pkg.version };
};
exports.latestChangeAndVersion = latestChangeAndVersion;
/**
 * Get extensions and modules required by a specific module.
 */
const getExtensionsAndModules = (sqlmodule, modules) => {
    const module = modules[sqlmodule];
    if (!module) {
        throw types_1.errors.MODULE_NOT_FOUND({ name: sqlmodule });
    }
    const native = module.requires.filter((req) => !Object.keys(modules).includes(req));
    const sqitch = module.requires.filter((req) => Object.keys(modules).includes(req));
    return { native, sqitch };
};
exports.getExtensionsAndModules = getExtensionsAndModules;
/**
 * Get extensions and modules with their latest changes and versions.
 */
const getExtensionsAndModulesChanges = (sqlmodule, modules, basePath) => {
    const { native, sqitch } = (0, exports.getExtensionsAndModules)(sqlmodule, modules);
    const sqitchWithDetails = sqitch.map((mod) => {
        const { change, version } = (0, exports.latestChangeAndVersion)(mod, modules, basePath);
        return { name: mod, latest: change, version };
    });
    return { native, sqitch: sqitchWithDetails };
};
exports.getExtensionsAndModulesChanges = getExtensionsAndModulesChanges;
