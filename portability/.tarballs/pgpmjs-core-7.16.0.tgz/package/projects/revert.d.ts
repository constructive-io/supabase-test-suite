import { PgpmOptions } from '@pgpmjs/types';
import { PgpmPackage } from '../core/class/pgpm';
interface Extensions {
    resolved: string[];
    external: string[];
}
export declare const revertProject: (opts: PgpmOptions, name: string, database: string, pkg: PgpmPackage, options?: {
    useTransaction?: boolean;
    /**
     * Revert to a specific change (exclusive - this change will NOT be reverted)
     * Can be a change name or a tag reference (e.g., '@v1.0.0')
     */
    toChange?: string;
}) => Promise<Extensions>;
export {};
